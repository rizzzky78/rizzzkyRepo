			//starts from here is modificated case	Js 1671
							 //experimental
							 //replace if error to /* */			
			case 'botstat':
				{                    
				const loadedMsg = await nayla.getAmountOfLoadedMessages()
				const chatIds = await nayla.getAllChatIds()
				const groups = await nayla.getAllGroups()
				nayla.sendText(from, `Status :\n- *${loadedMsg}* Loaded Messages\n- *${groups.length}* Group Chats\n- *${chatIds.length - groups.length}* Personal Chats\n- *${chatIds.length}* Total Chats \n\n _Shirogane Kei Bot_`)
				break		
				}					
	case 'nhentai-pdf':  
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return						
				await limitAdd(sender)
				if (!isPrem) return reply(nyz.prem1(command)) 
				if (args.length == 0) return reply(`Contoh: ${prefix + command}<spasi>12345 Tunggu sebentar \nMaksimal 5-10menit/req, diluar itu berarti error atau size file doujinnya besar`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				henid = args[0]
				get_result = await fetchJson(`http://api.lolhuman.xyz/api/nhentaipdf/${henid}?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_buffer = await getBuffer(get_result)
				nayla.sendMessage(from, ini_buffer, document, { quoted: nay, mimetype: Mimetype.pdf, filename: `Nhentai - ${henid}.pdf -KeiBot` })							
				break
	case 'nhentai-info':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				if (args.length == 0) return reply(`Contoh: ${prefix + command} 344253`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				jds = []
				henid = args[0]
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nhentai/${henid}?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Title Romaji : ${get_result.title_romaji}\n`
				ini_txt += `Title Native : ${get_result.title_native}\n`
				ini_txt += `Read Online : ${get_result.read}\n`
				get_info = get_result.info
				ini_txt += `Parodies : ${get_info.parodies}\n`
				ini_txt += `Character : ${get_info.characters.join(", ")}\n`
				ini_txt += `Tags : ${get_info.tags.join(", ")}\n`
				ini_txt += `Artist : ${get_info.artists}\n`
				ini_txt += `Group : ${get_info.groups}\n`
				ini_txt += `Languager : ${get_info.languages.join(", ")}\n`
				ini_txt += `Categories : ${get_info.categories}\n`
				ini_txt += `Pages : ${get_info.pages}\n`
				ini_txt += `Uploaded : ${get_info.uploaded}\n`
				mentions(ini_txt, jds, true)
				break	
	case 'nhentai-cari':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)				
				jds = []				
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Gotoubun No Hanayome`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nhentaisearch?apikey=${l0lhuman}&query=${query}`)
				get_result = get_result.result
				ini_txt = "Nih hasilnya senpai! : \n"
				for (var x of get_result) {
					ini_txt += `Id : ${x.id}\n`
					ini_txt += `Title English : ${x.title_english}\n`
					ini_txt += `Title Japanese : ${x.title_japanese}\n`
					ini_txt += `Native : ${x.title_native}\n`
					ini_txt += `Upload : ${x.date_upload}\n`
					ini_txt += `Page : ${x.page}\n`
					ini_txt += `Favourite : ${x.favourite}\n\n`
					ini_txt += `- - - \n`
					ini_txt += `_Shirogane Kei Bot_\n`
				}
				mentions(ini_txt, jds, true)
				break		
	case 'nekopoi':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)	 
				if (args.length == 0) return reply(`Contoh: ${prefix + command} https://nekopoi.care/isekai-harem-monogatari-episode-4-subtitle-indonesia/`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				ini_url = args[0]
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nekopoi?apikey=${l0lhuman}&url=${ini_url}`)
				get_result = get_result.result
				ini_txt = `Title : ${get_result.anime}\n`
				ini_txt += `Porducers : ${get_result.producers}\n`
				ini_txt += `Duration : ${get_result.duration}\n`
				ini_txt += `Size : ${get_result.size}\n`
				ini_txt += `Sinopsis : ${get_result.sinopsis}\n`
				ini_txt += `- - - \n`
				ini_txt += `_Shirogane Kei Bot_\n`
				link = get_result.link
				for (var x in link) {
					ini_txt += `\n${link[x].name}\n`
					link_dl = link[x].link
					for (var y in link_dl) {
						ini_txt += `${y} - ${link_dl[y]}\n`
					}		
				}
				ini_buffer = await getBuffer(get_result.thumb)
				await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: ini_txt })
				break	
	case 'nekopoi-cari':
					jds = []
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)					
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Isekai Harem`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nekopoisearch?apikey=${l0lhuman}&query=${query}`)
				get_result = get_result.result
				ini_txt = ""
				for (var x of get_result) {
					ini_txt += `Title : ${x.title}\n`
					ini_txt += `Link : ${x.link}\n`
					ini_txt += `Thumbnail : ${x.thumbnail}\n\n`
					ini_txt += `- - - \n`
					ini_txt += `_Shirogane Kei Bot_\n`
				}
				mentions(ini_txt, jds, true)
				break
	case 'cari-anime':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
					if (args.length == 0) return reply(`Contoh: ${prefix + command} Gotoubun No Hanayome`)
					//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
					query = args.join(" ")
					get_result = await fetchJson(`https://api.lolhuman.xyz/api/anime?apikey=${l0lhuman}&query=${query}`)
					get_result = get_result.result
					ini_txt = `Id : ${get_result.id}\n`
					ini_txt += `Id MAL : ${get_result.idMal}\n`
					ini_txt += `Title : ${get_result.title.romaji}\n`
					ini_txt += `English : ${get_result.title.english}\n`
					ini_txt += `Native : ${get_result.title.native}\n`
					ini_txt += `Format : ${get_result.format}\n`
					ini_txt += `Episodes : ${get_result.episodes}\n`
					ini_txt += `Duration : ${get_result.duration} mins.\n`
					ini_txt += `Status : ${get_result.status}\n`
					ini_txt += `Season : ${get_result.season}\n`
					ini_txt += `Season Year : ${get_result.seasonYear}\n`
					ini_txt += `Source : ${get_result.source}\n`
					ini_txt += `Start Date : ${get_result.startDate.day} - ${get_result.startDate.month} - ${get_result.startDate.year}\n`
					ini_txt += `End Date : ${get_result.endDate.day} - ${get_result.endDate.month} - ${get_result.endDate.year}\n`
					ini_txt += `Genre : ${get_result.genres.join(", ")}\n`
					ini_txt += `Synonyms : ${get_result.synonyms.join(", ")}\n`
					ini_txt += `Score : ${get_result.averageScore}%\n`
					ini_txt += `Characters : \n`
					ini_txt += `- - - \n`
					ini_txt += `_Shirogane Kei Bot_\n`
					ini_character = get_result.characters.nodes
					for (var x of ini_character) {
						ini_txt += `- ${x.name.full} (${x.name.native})\n`
					}
					ini_txt += `\nDescription : ${get_result.description}`
					thumbnail = await getBuffer(get_result.coverImage.large)
					await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
			break
			case 'pixiv':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				if (!isPrem) return reply(nyz.prem1(command))
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)				
					if (args.length == 0) return reply(`Contoh: ${prefix + command} loli kawaii \nUntuk hasilnya bisa saja tidak akurat ya senpai, mohon dimengerti`)
					query = args.join(" ")
					ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/pixiv?apikey=${l0lhuman}&query=${query}`)
					capt = `Nih senpai, jangan lupa bilang makasih...`
					await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: capt })
			break
			case 'pixivdl':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
					if (args.length == 0) return reply(`Contoh: ${prefix + command} 63456028`)
					//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
					query = args[0]
					ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/pixivdl/${pixivid}?apikey=${l0lhuman}`)
					capt = `Nih senpai, jangan lupa bilang makasih...`
					await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: capt })
			break
				// Information //	
			case 'randomhentai':
			case 'chiisaihentai':
			case 'trap':
			case 'blowjob':
			case 'yaoi':
			case 'ecchi':
			case 'hentai':
			case 'ahegao':
			case 'hololewd':
			case 'sideoppai':
			case 'animefeets':
			case 'animebooty':
			case 'animethighss':
			case 'hentaiparadise':
			case 'animearmpits':
			case 'hentaifemdom':
			case 'lewdanimegirls':
			case 'biganimetiddies':
			case 'animebellybutton':
			case 'hentai4everyone':				
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				anu1 = `Nih senpai, jangan lupa bilang makasih...`		
				await getBuffer(`https://api.lolhuman.xyz/api/random/nsfw/${command}?apikey=${l0lhuman}`).then((gambar) => {
					nayla.sendMessage(from, gambar, image, { quoted: nay, caption: anu1 })
				})
				break	
			case 'randomhentai2':
			case 'bj':
			case 'ero':
			case 'cum':
			case 'feet':
			case 'yuri':
			case 'trap':
			case 'lewd':
			case 'feed':
			case 'eron':
			case 'solo':
			case 'gasm':
			case 'poke':
			case 'anal':
			case 'holo':
			case 'tits':
			case 'kuni':
			case 'kiss':
			case 'erok':
			case 'smug':
			case 'baka':
			case 'solog':
			case 'feetg':
			case 'lewdk':
			case 'waifu':
			case 'pussy':
			case 'femdom':
			case 'cuddle':
			case 'hentai':
			case 'eroyuri':
			case 'cum_jpg':
			case 'blowjob':
			case 'erofeet':
			case 'holoero':
			case 'classic':
			case 'erokemo':
			case 'fox_girl':
			case 'futanari':
			case 'lewdkemo':
			case 'wallpaper':
			case 'pussy_jpg':
			case 'kemonomimi':
			case 'nsfw_avatar':				
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				anu1 = `Nih senpai, jangan lupa bilang makasih...`		
				getBuffer(`https://api.lolhuman.xyz/api/random2/${command}?apikey=${l0lhuman}`).then((gambar) => {
					nayla.sendMessage(from, gambar, image, { quoted: nay, caption: anu1 })
				})
				break
			case 'waifuu':
			case 'art':
			case 'bts':
			case 'exo':
			case 'elf':
			case 'loli':
			case 'neko':
			case 'shota':
			case 'husbu':
			case 'sagiri':
			case 'shinobu':
			case 'megumin':
			case 'wallnime':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				anu1 = `Nih senpai, jangan lupa bilang makasih...`					
				getBuffer(`https://api.lolhuman.xyz/api/random/${command}?apikey=${l0lhuman}`).then((gambar) => {
					nayla.sendMessage(from, gambar, image, { quoted: nay, caption: anu1 })
				})
				break							 
	//halal menu
		case 'listsurah':				    
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/quran?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = 'List Surah:\n'
			for (var x in get_result) {
				ini_txt += `${x}. ${get_result[x]}\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'alquran':			    
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length < 1) return reply(`Nih ya senpai aku contohin: ${prefix + command} 18 or ${prefix + command} 18/10 or ${prefix + command} 18/1-10`)
			urls = `https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${l0lhuman}`
			quran = await fetchJson(urls)
			result = quran.result
			ayat = result.ayat
			ini_txt = `QS. ${result.surah} : 1-${ayat.length}\n\n`
			for (var x of ayat) {
				arab = x.arab
				nomor = x.ayat
				latin = x.latin
				indo = x.indonesia
				ini_txt += `${arab}\n${nomor}. ${latin}\n${indo}\n\n`
			}
			ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
			ini_txt = ini_txt.replace(/<strong>/g, "").replace(/<\/strong>/g, "")
			ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
			mentions(ini_txt, jds, true)
			break
		case 'alquranaudio':			    
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} 18 or ${prefix + command} 18/10`)
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			surah = args[0]
			ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/quran/audio/${surah}?apikey=${l0lhuman}`)
			await nayla.sendMessage(from, ini_buffer, audio, { quoted: nay, mimetype: Mimetype.mp4Audio })
			break
		case 'asmaulhusna':			
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)    
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/asmaulhusna?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `No : ${get_result.index}\n`
			ini_txt += `Latin: ${get_result.latin}\n`
			ini_txt += `Arab : ${get_result.ar}\n`
			ini_txt += `Indonesia : ${get_result.id}\n`
			ini_txt += `English : ${get_result.en}`
			mentions(ini_txt, jds, true)
			break
		case 'kisahnabi':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)			    
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Muhammad`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/kisahnabi/${query}?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Name : ${get_result.name}\n`
			ini_txt += `Lahir : ${get_result.thn_kelahiran}\n`
			ini_txt += `Umur : ${get_result.age}\n`
			ini_txt += `Tempat : ${get_result.place}\n`
			ini_txt += `Story : \n${get_result.story}`
			mentions(ini_txt, jds, true)
			break
		case 'jadwalsholat':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)    
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Yogyakarta`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			daerah = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/sholat/${daerah}?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Wilayah : ${get_result.wilayah}\n`
			ini_txt += `Tanggal : ${get_result.tanggal}\n`
			ini_txt += `Sahur : ${get_result.sahur}\n`
			ini_txt += `Imsak : ${get_result.imsak}\n`
			ini_txt += `Subuh : ${get_result.subuh}\n`
			ini_txt += `Terbit : ${get_result.terbit}\n`
			ini_txt += `Dhuha : ${get_result.dhuha}\n`
			ini_txt += `Dzuhur : ${get_result.dzuhur}\n`
			ini_txt += `Ashar : ${get_result.ashar}\n`
			ini_txt += `Maghrib : ${get_result.imsak}\n`
			ini_txt += `Isya : ${get_result.isya}`
			mentions(ini_txt, jds, true)
			break		
	//halal menu ends here

		//haram menu
		case 'xhamstersearch':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Japanese`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xhamstersearch?apikey=${l0lhuman}&query=${query}`)
			get_result = get_result.result
			ini_txt = ""
			for (var x of get_result) {
				ini_txt += `Title : ${x.title}\n`
				ini_txt += `Views : ${x.views}\n`
				ini_txt += `Duration : ${x.duration}\n`
				ini_txt += `Link : ${x.link}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'xhamster':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} https://xhamster.com/videos/party-with-friends-end-in-awesome-fucking-5798407`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xhamster?apikey=${l0lhuman}&url=${query}`)
			get_result = get_result.result
			ini_txt = `Title : ${get_result.title}\n`
			ini_txt += `Duration : ${get_result.duration}\n`
			ini_txt += `Uploader : ${get_result.author}\n`
			ini_txt += `Upload : ${get_result.upload}\n`
			ini_txt += `View : ${get_result.views}\n`
			ini_txt += `Rating : ${get_result.rating}\n`
			ini_txt += `Like : ${get_result.likes}\n`
			ini_txt += `Dislike : ${get_result.dislikes}\n`
			ini_txt += `Comment : ${get_result.comments}\n`
			ini_txt += "Link : \n"
			link = get_result.link
			for (var x of link) {
				ini_txt += `${x.type} - ${x.link}\n\n`
			}
			thumbnail = await getBuffer(get_result.thumbnail)
			await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
			break
		case 'xnxxsearch':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Japanese`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xnxxsearch?apikey=${l0lhuman}&query=${query}`)
			get_result = get_result.result
			ini_txt = ""
			for (var x of get_result) {
				ini_txt += `Title : ${x.title}\n`
				ini_txt += `Views : ${x.views}\n`
				ini_txt += `Duration : ${x.duration}\n`
				ini_txt += `Uploader : ${x.uploader}\n`
				ini_txt += `Link : ${x.link}\n`
				ini_txt += `Thumbnail : ${x.thumbnail}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'xnxx':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} https://www.xnxx.com/video-uy5a73b/mom_is_horny_-_brooklyn`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xnxx?apikey=${l0lhuman}&url=${query}`)
			get_result = get_result.result
			ini_txt = `Title : ${get_result.title}\n`
			ini_txt += `Duration : ${get_result.duration}\n`
			ini_txt += `View : ${get_result.view}\n`
			ini_txt += `Rating : ${get_result.rating}\n`
			ini_txt += `Like : ${get_result.like}\n`
			ini_txt += `Dislike : ${get_result.dislike}\n`
			ini_txt += `Comment : ${get_result.comment}\n`
			ini_txt += `Tag : ${get_result.tag.join(", ")}\n`
			ini_txt += `Description : ${get_result.description}\n`
			ini_txt += "Link : \n"
			ini_link = get_result.link
			for (var x of ini_link) {
				ini_txt += `${x.type} - ${x.link}\n\n`
			}
			thumbnail = await getBuffer(get_result.thumbnail)
			await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
			break
	//haram menu ends here

	//What anime is this (experimental)
	case 'wait':
		//experimental
		await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
		if ((isMedia && !nay.message.videoMessage || isQuotedImage) && args.length == 0) {
			const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : nay
			const filePath = await nayla.downloadAndSaveMediaMessage(encmedia, filename = getRandom());
			const form = new FormData();
			const stats = fs.statSync(filePath);
			const fileSizeInBytes = stats.size;
			const fileStream = fs.createReadStream(filePath);
			form.append('img', fileStream, { knownLength: fileSizeInBytes });
			const options = {
				method: 'POST',
				credentials: 'include',
				body: form
			}
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/wait?apikey=${l0lhuman}`, {...options })
			fs.unlinkSync(filePath)
			get_result = get_result.result
			ini_video = await getBuffer(get_result.video)
			ini_txt = `Anilist id : ${get_result.anilist_id}\n`
			ini_txt += `MAL id : ${get_result.mal_id}\n`
			ini_txt += `Title Romaji : ${get_result.title_romaji}\n`
			ini_txt += `Title Native : ${get_result.title_native}\n`
			ini_txt += `Title English : ${get_result.title_english}\n`
			ini_txt += `at : ${get_result.at}\n`
			ini_txt += `Episode : ${get_result.episode}\n`
			ini_txt += `Similarity : ${get_result.similarity}`
			await nayla.sendMessage(from, ini_video, video, { quoted: nay, caption: ini_txt })
		} else {
			reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
		}
		break

		case 'genshin':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} jean`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			hero = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/genshin/${hero}?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Name : ${get_result.title}\n`
			ini_txt += `Intro : ${get_result.intro}\n`
			ini_txt += `Icon : ${get_result.icon}\n`
			ini_icon = await getBuffer(get_result.cover1)
			await nayla.sendMessage(from, ini_icon, image, { quoted: nay, caption: ini_txt })
			ini_voice = await getBuffer(get_result.cv[0].audio[0])
			await nayla.sendMessage(from, ini_voice, audio, { quoted: nay, mimetype: Mimetype.mp4Audio })
			break
			case 'otakudesu-cari':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Gotoubun No Hanayome`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/otakudesusearch?apikey=${l0lhuman}&query=${query}`)
				get_result = get_result.result
				ini_txt = `Title : ${get_result.title}\n`
				ini_txt += `Japanese : ${get_result.japanese}\n`
				ini_txt += `Judul : ${get_result.judul}\n`
				ini_txt += `Type : ${get_result.type}\n`
				ini_txt += `Episode : ${get_result.episodes}\n`
				ini_txt += `Aired : ${get_result.aired}\n`
				ini_txt += `Producers : ${get_result.producers}\n`
				ini_txt += `Genre : ${get_result.genres}\n`
				ini_txt += `Duration : ${get_result.duration}\n`
				ini_txt += `Studios : ${get_result.status}\n`
				ini_txt += `Rating : ${get_result.rating}\n`
				ini_txt += `Credit : ${get_result.credit}\n`
				get_link = get_result.link_dl
				for (var x in get_link) {
					ini_txt += `\n\n*${get_link[x].title}*\n`
					for (var y in get_link[x].link_dl) {
						ini_info = get_link[x].link_dl[y]
						ini_txt += `\n\`\`\`Reso : \`\`\`${ini_info.reso}\n`
						ini_txt += `\`\`\`Size : \`\`\`${ini_info.size}\n`
						ini_txt += `\`\`\`Link : \`\`\`\n`
						down_link = ini_info.link_dl
						for (var z in down_link) {
							ini_txt += `${z} - ${down_link[z]}\n`
						}
					}
				}
				mentions(ini_txt, jds, true)
				break
                case 'otakudesu':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://otakudesu.tv/lengkap/pslcns-sub-indo/`)
					//experimental
					await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
                    ini_url = args[0]
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/otakudesu?apikey=${l0lhuman}&url=${ini_url}`)
                    get_result = get_result.result
                    ini_txt = `Title : ${get_result.title}\n`
                    ini_txt += `Japanese : ${get_result.japanese}\n`
                    ini_txt += `Judul : ${get_result.judul}\n`
                    ini_txt += `Type : ${get_result.type}\n`
                    ini_txt += `Episode : ${get_result.episodes}\n`
                    ini_txt += `Aired : ${get_result.aired}\n`
                    ini_txt += `Producers : ${get_result.producers}\n`
                    ini_txt += `Genre : ${get_result.genres}\n`
                    ini_txt += `Duration : ${get_result.duration}\n`
                    ini_txt += `Studios : ${get_result.status}\n`
                    ini_txt += `Rating : ${get_result.rating}\n`
                    ini_txt += `Credit : ${get_result.credit}\n`
                    get_link = get_result.link_dl
                    for (var x in get_link) {
                        ini_txt += `\n\n*${get_link[x].title}*\n`
                        for (var y in get_link[x].link_dl) {
                            ini_info = get_link[x].link_dl[y]
                            ini_txt += `\n\`\`\`Reso : \`\`\`${ini_info.reso}\n`
                            ini_txt += `\`\`\`Size : \`\`\`${ini_info.size}\n`
                            ini_txt += `\`\`\`Link : \`\`\`\n`
                            down_link = ini_info.link_dl
                            for (var z in down_link) {
                                ini_txt += `${z} - ${down_link[z]}\n`
                            }
                        }
                    }
                    mentions(ini_txt, jds, true)
                    break				
				case 'character':  
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return
				await limitAdd(sender) 
				if (args.length == 0) return reply(`Example: ${prefix + command} Miku Nakano`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				anu1 = await fetchJson(`http://api.lolhuman.xyz/api/character?apikey=${l0lhuman}&query=${query}`)
				anu = anu1.result
				anu2 = `Id : ${anu.id}\n`
				anu2 += `Name : ${anu.name.full}\n`
				anu2 += `Native : ${anu.name.native}\n`
				anu2 += `Favorites : ${anu.favourites}\n`
				anu2 += `Media : \n`
				ini_media = anu.media.nodes
				for (var x of ini_media) {
					anu2 += `- ${x.title.romaji} (${x.title.native})\n`
				}
				anu2 += `\nDescription : \n${anu.description.replace(/__/g, "_")}`
				thumbnail = await getBuffer(anu.image.large)
				nayla.sendMessage(from, thumbnail, image, { caption: anu2 })
				break
				case 'cari-manga':  
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return
				await limitAdd(sender) 
				if (args.length == 0) return reply(`Example: ${prefix + command} Gotoubun No Hanayome`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				anu1 = await fetchJson(`http://api.lolhuman.xyz/api/manga?apikey=${l0lhuman}&query=${query}`)
				anu = anu1.result
				anu2 = `➻ Id : ${anu.id}\n`
				anu2 += `➻ Id MAL : ${anu.idMal}\n`
				anu2 += `➻ Title : ${anu.title.romaji}\n`
				anu2 += `➻ English : ${anu.title.english}\n`
				anu2 += `➻ Native : ${anu.title.native}\n`
				anu2 += `➻ Format : ${anu.format}\n`
				anu2 += `➻ Chapters : ${anu.chapters}\n`
				anu2 += `➻ Volume : ${anu.volumes}\n`
				anu2 += `➻ Status : ${anu.status}\n`
				anu2 += `➻ Source : ${anu.source}\n`
				anu2 += `➻ Start Date : ${anu.startDate.day} - ${anu.startDate.month} - ${anu.startDate.year}\n`
				anu2 += `➻ end Date : ${anu.endDate.day} - ${anu.endDate.month} - ${anu.endDate.year}\n`
				anu2 += `➻ Genre : ${anu.genres.join(", ")}\n`
				anu2 += `➻ Synonyms : ${anu.synonyms.join(", ")}\n`
				anu2 += `➻ Score : ${anu.averageScore}%\n`
				anu2 += `➻ Characters : \n`
				ini_character = anu.characters.nodes
				for (var x of ini_character) {
					anu2 += `- ${x.name.full} (${x.name.native})\n`
				}
				anu2 += `\nDescription : ${anu.description}`
				thumbnail = await getBuffer(anu.coverImage.large)
				nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: anu2 })
				break         				
		//guna menu											
				case 'cuaca':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)		
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Yogyakarta`)
				daerah = args[0]
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/cuaca/${daerah}?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Tempat : ${get_result.tempat}\n`
				ini_txt += `Cuaca : ${get_result.cuaca}\n`
				ini_txt += `Angin : ${get_result.angin}\n`
				ini_txt += `Description : ${get_result.description}\n`
				ini_txt += `Kelembapan : ${get_result.kelembapan}\n`
				ini_txt += `Suhu : ${get_result.suhu}\n`
				ini_txt += `Udara : ${get_result.udara}\n`
				ini_txt += `Permukaan laut : ${get_result.permukaan_laut}\n`
				await nayla.sendMessage(from, { degreesLatitude: get_result.latitude, degreesLongitude: get_result.longitude }, location, { quoted: nay })
				reply(ini_txt)
				break
				case 'covidindo':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)		
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/corona/indonesia?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Positif : ${get_result.positif}\n`
				ini_txt += `Sembuh : ${get_result.sembuh}\n`
				ini_txt += `Dirawat : ${get_result.dirawat}\n`
				ini_txt += `Meninggal : ${get_result.meninggal}`
				reply(ini_txt)
				break
				case 'covidglobal':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)		
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/corona/global?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Positif : ${get_result.positif}\n`
				ini_txt += `Sembuh : ${get_result.sembuh}\n`
				ini_txt += `Dirawat : ${get_result.dirawat}\n`
				ini_txt += `Meninggal : ${get_result.meninggal}`
				reply(ini_txt)
				break		
		case 'wikipedia':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			if (args.length == 0) return reply(`Example: ${prefix + command} Tahu`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/wiki?apikey=${l0lhuman}&query=${query}`)
			get_result = get_result.result
			mentions(get_result, jds, true)
		break
        //catch err mod - ends here Js 2506