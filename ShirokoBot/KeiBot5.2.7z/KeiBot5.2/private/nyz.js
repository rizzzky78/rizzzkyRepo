
const xxx = '```'

xports.error404 = (pushname, prefix) => { 
    return`${xxx}Yahh maaf ${pushname} senpai, sepertinya terjadi error :(${xxx}
${xxx}Silahkan coba beberapa saat lagi atau ganti request link/konten lainnya${xxx}
${xxx}Atau senpai bisa melapor bug ke owner dengan cara ketik ${prefix}bug${xxx}

${tz}${xxx}Shirogane Kei${xxx}${tz}
${xxx}Revisi terosss....${xxx}`
} 
exports.grupmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}Grup Menu${xxx}⧉ ❳  
│${tz} ${xxx}${prefix}rate${xxx}
│${tz} ${xxx}${prefix}kapankah${xxx}
│${tz} ${xxx}${prefix}apakah${xxx}
│${tz} ${xxx}${prefix}jadian${xxx}
│${tz} ${xxx}${prefix}afk${xxx}
│${tz} ${xxx}${prefix}otakudesu${xxx}
│${tz} ${xxx}${prefix}add${xxx}
│${tz} ${xxx}${prefix}kick${xxx}
│${tz} ${xxx}${prefix}promote${xxx}
│${tz} ${xxx}${prefix}demote${xxx}
│${tz} ${xxx}${prefix}antilink${xxx}
│${tz} ${xxx}${prefix}welcome${xxx}
│${tz} ${xxx}${prefix}hidetag10${xxx}
│${tz} ${xxx}${prefix}group${xxx}
│${tz} ${xxx}${prefix}antigay${xxx}
│${tz} ${xxx}${prefix}antibocil${xxx}
│${tz} ${xxx}${prefix}antiwibu${xxx}
│${tz} ${xxx}${prefix}antikasar${xxx}
│${tz} ${xxx}${prefix}antitag${xxx}
│${tz} ${xxx}${prefix}level${xxx}
│${tz} ${xxx}${prefix}limit${xxx}
│${tz} ${xxx}${prefix}leveling${xxx}
│${tz} ${xxx}${prefix}antijawa${xxx} 
│${tz} ${xxx}${prefix}linkgc${xxx}
│${tz} ${xxx}${prefix}tagall${xxx}
│${tz} ${xxx}${prefix}delete${xxx}
╰──❲ ${xxx}Revision ver: theta${xxx} ❳`
}

exports.internalmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}- Internal Menu -${xxx}⧉ ❳
│${tz} ${xxx}${prefix}readmore${xxx}
│${tz} ${xxx}${prefix}chatlist${xxx}
│${tz} ${xxx}${prefix}addsticker${xxx}
│${tz} ${xxx}${prefix}addvn${xxx}
│${tz} ${xxx}${prefix}getvn${xxx}
│${tz} ${xxx}${prefix}getsticker${xxx}
│${tz} ${xxx}${prefix}liststicker${xxx}
│${tz} ${xxx}${prefix}listvn${xxx}
│${tz} ${xxx}${prefix}addimage${xxx}
│${tz} ${xxx}${prefix}getimage${xxx}
│${tz} ${xxx}${prefix}imagelist${xxx}
│${tz} ${xxx}${prefix}addvideo${xxx}
│${tz} ${xxx}${prefix}getvideo${xxx}
│${tz} ${xxx}${prefix}listvideo${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}

exports.cekmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}- Cek Menu -${xxx}⧉ ❳
│${tz} ${xxx}${prefix}badutcek${xxx}
│${tz} ${xxx}${prefix}ampascek${xxx}
│${tz} ${xxx}${prefix}hokicek${xxx}
│${tz} ${xxx}${prefix}pedocek${xxx}
│${tz} ${xxx}${prefix}silitcek${xxx}
│${tz} ${xxx}${prefix}gaycek${xxx}
│${tz} ${xxx}${prefix}hodecek${xxx}
│${tz} ${xxx}${prefix}gantengcek${xxx}
│${tz} ${xxx}${prefix}cantikcek${xxx}
│${tz} ${xxx}${prefix}jelekcek${xxx}
│${tz} ${xxx}${prefix}goblokcek${xxx}
│${tz} ${xxx}${prefix}begocek${xxx}
│${tz} ${xxx}${prefix}pintercek${xxx}
│${tz} ${xxx}${prefix}jagocek${xxx}
│${tz} ${xxx}${prefix}nolepcek${xxx}
│${tz} ${xxx}${prefix}babicek${xxx}
│${tz} ${xxx}${prefix}bebancek${xxx}
│${tz} ${xxx}${prefix}baikcek${xxx}
│${tz} ${xxx}${prefix}jahatcek${xxx}
│${tz} ${xxx}${prefix}anjingcek${xxx}
│${tz} ${xxx}${prefix}haramcek${xxx}
│${tz} ${xxx}${prefix}kontolcek${xxx}
│${tz} ${xxx}${prefix}pakboycek${xxx}
│${tz} ${xxx}${prefix}pakgirlcek${xxx}
│${tz} ${xxx}${prefix}sangecek${xxx}
│${tz} ${xxx}${prefix}bapercek${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
exports.tagmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}- Tag Menu -${xxx}⧉ ❳
│${tz} ${xxx}${prefix}comly${xxx}
│${tz} ${xxx}${prefix}ngegay${xxx}
│${tz} ${xxx}${prefix}nyilit${xxx}
│${tz} ${xxx}${prefix}ganteng${xxx}
│${tz} ${xxx}${prefix}cantik${xxx}
│${tz} ${xxx}${prefix}jelek${xxx}
│${tz} ${xxx}${prefix}goblok${xxx}
│${tz} ${xxx}${prefix}bego${xxx}
│${tz} ${xxx}${prefix}pinter${xxx}
│${tz} ${xxx}${prefix}jago${xxx}
│${tz} ${xxx}${prefix}babi${xxx}
│${tz} ${xxx}${prefix}beban${xxx}
│${tz} ${xxx}${prefix}baik${xxx}
│${tz} ${xxx}${prefix}jahat${xxx}
│${tz} ${xxx}${prefix}anjing${xxx}
│${tz} ${xxx}${prefix}monyet${xxx}
│${tz} ${xxx}${prefix}haram${xxx}
│${tz} ${xxx}${prefix}kontol${xxx}
│${tz} ${xxx}${prefix}pakboy${xxx}
│${tz} ${xxx}${prefix}pakgirl${xxx}
│${tz} ${xxx}${prefix}sadboy${xxx}
│${tz} ${xxx}${prefix}sadgirl${xxx}
│${tz} ${xxx}${prefix}wibu${xxx}
│${tz} ${xxx}${prefix}nolep${xxx}
│${tz} ${xxx}${prefix}hebat${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}

exports.ownermenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}Owner Menu${xxx}⧉ ❳
│${xxx}*FYI: hanya khusus utk Owner Bot!${xxx}	
│${tz} ${xxx}${prefix}dellprem${xxx} 
│${tz} ${xxx}${prefix}addprem${xxx}
│${tz} ${xxx}${prefix}clearall${xxx}
│${tz} ${xxx}${prefix}bc${xxx}
│${tz} ${xxx}${prefix}owner${xxx}
│${tz} ${xxx}${prefix}author${xxx}
│${tz} ${xxx}${prefix}bugtroli${xxx}
│${tz} ${xxx}${prefix}setout${xxx}
│${tz} ${xxx}${prefix}setwelcome${xxx}
│${tz} ${xxx}${prefix}settz${xxx}
│${tz} ${xxx}${prefix}setthum${xxx}
│${tz} ${xxx}${prefix}setpp${xxx}
│${tz} ${xxx}${prefix}setprefix${xxx}
│${tz} ${xxx}${prefix}setreply${xxx}
│${tz} ${xxx}${prefix}setplugin-leveling${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}

	//Modifications starts from here
//NSFW Menu!
exports.nsfwMenu = (tz, prefix) => {
return`╔══════════════════════════╗
║        ⧉ ${xxx}NSFW Menu${xxx} ⧉
║      ⧉ ${xxx}NotSafeForWork Menu${xxx} ⧉
╚══════════════════════════╝

╔══════════════════════════╗
║   ⧉ ${xxx}Hentai & Doujinshi${xxx} ⧉ 
╠══════════════════════════╝
║${tz} ${xxx}${prefix}nekopoi${xxx}
║${tz} ${xxx}${prefix}nekopoi-cari${xxx}
║${tz} ${xxx}${prefix}nhentai-cari${xxx}					
║${tz} ${xxx}${prefix}nhentai-info${xxx}
║${tz} ${xxx}${prefix}nhentai-pdf${xxx}
╚═══════════════════════════

╔══════════════════════════╗
║      ⧉ ${xxx}Lewd Pictures${xxx} ⧉ 
╠══════════════════════════╝
╠════⟢ ${xxx}Lewd I${xxx}
║${tz} ${xxx}${prefix}randomhentai${xxx}
║${tz} ${xxx}${prefix}chiisaihentai${xxx}
║${tz} ${xxx}${prefix}trap${xxx}
║${tz} ${xxx}${prefix}blowjob${xxx}
║${tz} ${xxx}${prefix}yaoi${xxx}
║${tz} ${xxx}${prefix}ecchi${xxx}
║${tz} ${xxx}${prefix}hentai${xxx}
║${tz} ${xxx}${prefix}ahegao${xxx}
║${tz} ${xxx}${prefix}hololewd${xxx}            
║${tz} ${xxx}${prefix}sideoppai${xxx}
║${tz} ${xxx}${prefix}animefeets${xxx}
║${tz} ${xxx}${prefix}animebooty${xxx}
║${tz} ${xxx}${prefix}animethighss${xxx}
║${tz} ${xxx}${prefix}hentaiparadise${xxx}
║${tz} ${xxx}${prefix}animearmpits${xxx}
║${tz} ${xxx}${prefix}hentaifemdom${xxx}
║${tz} ${xxx}${prefix}lewdanimegirls${xxx}
║${tz} ${xxx}${prefix}biganimetiddies${xxx}
║${tz} ${xxx}${prefix}animebellybutton${xxx}
║${tz} ${xxx}${prefix}hentai4everyone${xxx}
╠══════════════════════════╣
╠════⟢ Lewd II
║${tz} ${xxx}${prefix}bj${xxx}
║${tz} ${xxx}${prefix}ero${xxx}
║${tz} ${xxx}${prefix}cum${xxx}
║${tz} ${xxx}${prefix}feet${xxx}
║${tz} ${xxx}${prefix}yuri${xxx}
║${tz} ${xxx}${prefix}trap${xxx}
║${tz} ${xxx}${prefix}lewd${xxx}
║${tz} ${xxx}${prefix}eron${xxx}
║${tz} ${xxx}${prefix}solo${xxx}
║${tz} ${xxx}${prefix}gasm${xxx}
║${tz} ${xxx}${prefix}poke${xxx}
║${tz} ${xxx}${prefix}anal${xxx}
║${tz} ${xxx}${prefix}holo${xxx}
║${tz} ${xxx}${prefix}tits${xxx}
║${tz} ${xxx}${prefix}kuni${xxx}
║${tz} ${xxx}${prefix}kiss${xxx}
║${tz} ${xxx}${prefix}erok${xxx}
║${tz} ${xxx}${prefix}smug${xxx}
║${tz} ${xxx}${prefix}baka${xxx}
║${tz} ${xxx}${prefix}solog${xxx}
║${tz} ${xxx}${prefix}feetg${xxx}
║${tz} ${xxx}${prefix}lewdk${xxx}
║${tz} ${xxx}${prefix}waifu${xxx}
║${tz} ${xxx}${prefix}pussy${xxx}
║${tz} ${xxx}${prefix}femdom${xxx}
║${tz} ${xxx}${prefix}cuddle${xxx}
║${tz} ${xxx}${prefix}hentai${xxx}
║${tz} ${xxx}${prefix}eroyuri${xxx}
║${tz} ${xxx}${prefix}cum_jpg${xxx}
║${tz} ${xxx}${prefix}erofeet${xxx}
║${tz} ${xxx}${prefix}holoero${xxx}
║${tz} ${xxx}${prefix}classic${xxx}
║${tz} ${xxx}${prefix}erokemo${xxx}
║${tz} ${xxx}${prefix}fox_girl${xxx}
║${tz} ${xxx}${prefix}futanari${xxx}
║${tz} ${xxx}${prefix}lewdkemo${xxx}
║${tz} ${xxx}${prefix}wallpaper${xxx}
║${tz} ${xxx}${prefix}pussy_jpg${xxx}
║${tz} ${xxx}${prefix}kemonomimi${xxx}
║${tz} ${xxx}${prefix}nsfw_avatar${xxx}
╠══════════════════════════╗
║ ${xxx}Get Features${xxx}
║ ${xxx}API's By: LoLHuman${xxx}
║ ${xxx}Shirogane Kei Bot${xxx}
╚══════════════════════════╝`
}

exports.halalMenu = (tz, prefix) => {
	return`╭────────❲ ⧉ ${xxx}Halal Menu${xxx} ⧉ ❳────────────
│${tz} ${xxx}${prefix}listsurah${xxx}
│${tz} ${xxx}${prefix}alquran${xxx}
│${tz} ${xxx}${prefix}alquranaudio${xxx}
│${tz} ${xxx}${prefix}asmaulhusna${xxx}
│${tz} ${xxx}${prefix}kisahnabi${xxx}
│${tz} ${xxx}${prefix}jadwalsholat${xxx}
│
│${xxx}- - Stay halal Brother :) - -${xxx}
│${xxx}- - Shirogane Kei Bot - -${xxx}
╰─────────────────────────────────────`
}	

exports.haramMenu = (tz, prefix) => {
	return`╭────────❲ ⧉ ${xxx}Haram Menu${xxx} ⧉ ❳────────────
│${tz} ${xxx}${prefix}xhamstersearch${xxx}
│${tz} ${xxx}${prefix}xhamster${xxx}
│${tz} ${xxx}${prefix}xnxxsearch${xxx}
│${tz} ${xxx}${prefix}xnxx${xxx}
│
│${xxx}- - Secukupnya saja ya nak :) - -${xxx}
│${xxx}- - Shirogane Kei Bot - -${xxx}
╰─────────────────────────────────────`
}

exports.gunaMenu = (tz, prefix) => {
	return`╭────────❲ ⧉ ${xxx}Guna Menu${xxx} ⧉ ❳────────────
│${tz} ${xxx}${prefix}wikipedia${xxx}
│${tz} ${xxx}${prefix}translate${xxx}
│${tz} ${xxx}${prefix}brainly${xxx}
│${tz} ${xxx}${prefix}kbbi${xxx}
│${tz} ${xxx}${prefix}hoax${xxx}
│${tz} ${xxx}${prefix}jarak${xxx}
│${tz} ${xxx}${prefix}translate${xxx}
│${tz} ${xxx}${prefix}urbandictionary${xxx}
│${tz} ${xxx}${prefix}jadwaltv${xxx}
│${tz} ${xxx}${prefix}jadwaltvnow${xxx}
│${tz} ${xxx}${prefix}newsinfo${xxx}
│${tz} ${xxx}${prefix}cnnindonesia${xxx}
│${tz} ${xxx}${prefix}cnnnasional${xxx}
│${tz} ${xxx}${prefix}cnninternasional${xxx}
│${tz} ${xxx}${prefix}infogempa${xxx}
│${tz} ${xxx}${prefix}google${xxx}
│${tz} ${xxx}${prefix}shortlink${xxx}
│
│${xxx}- - Best Regards! - -${xxx}
│${xxx}- - Shirogane Kei Bot - -${xxx}
╰─────────────────────────────────────`
}

exports.newmakerMenu = (tz, prefix) => {
	return`╭────────❲ ⧉ ${xxx}Maker Menu${xxx} ⧉ ❳────────────
│${tz} ${xxx}${prefix}ttp${xxx}
│${tz} ${xxx}${prefix}ttp2${xxx}
│${tz} ${xxx}${prefix}ttp3${xxx}
│${tz} ${xxx}${prefix}ttp4${xxx}
│${tz} ${xxx}${prefix}attp${xxx}
│${tz} ${xxx}${prefix}attpz${xxx}
│${tz} ${xxx}${prefix}triggered${xxx}
│${tz} ${xxx}${prefix}pornhub${xxx}
│${tz} ${xxx}${prefix}glitch${xxx}
│${tz} ${xxx}${prefix}avenger${xxx}
│${tz} ${xxx}${prefix}space${xxx}
│${tz} ${xxx}${prefix}ninjalogo${xxx}
│${tz} ${xxx}${prefix}marvelstudio${xxx}
│${tz} ${xxx}${prefix}lionlogo${xxx}
│${tz} ${xxx}${prefix}wolflogo${xxx}
│${tz} ${xxx}${prefix}steel3d${xxx}
│${tz} ${xxx}${prefix}wallgravity${xxx}
│
│${xxx}- - Best Regards! - -${xxx}
│${xxx}- - Shirogane Kei Bot - -${xxx}
╰─────────────────────────────────────`
}

exports.newmakerMenu2 = (tz, prefix) => {
	return`╭────────❲ ⧉ ${xxx}FunText Menu${xxx} ⧉ ❳────────────	
│${tz} ${xxx}${prefix}cerpen${xxx}
│${tz} ${xxx}${prefix}ceritahoror${xxx}
│${tz} ${xxx}${prefix}wancak${xxx}
│${tz} ${xxx}${prefix}quotes${xxx}
│${tz} ${xxx}${prefix}quotesanime${xxx}
│${tz} ${xxx}${prefix}quotesdilan${xxx}
│${tz} ${xxx}${prefix}quotesimage${xxx}
│${tz} ${xxx}${prefix}faktaunik${xxx}
│${tz} ${xxx}${prefix}katabijak${xxx}
│${tz} ${xxx}${prefix}bucin${xxx}
│${tz} ${xxx}${prefix}pantun${xxx}
│${tz} ${xxx}${prefix}randomnama${xxx}
│
│${xxx}*gunakan seperlunya..${xxx}
│${xxx}- - Best Regards! - -${xxx}
│${xxx}- - Shirogane Kei Bot - -${xxx}
╰─────────────────────────────────────`
}

exports.mediaMenu = (tz, prefix) => {
	return`╭────────❲ ⧉ ${xxx}Media Menu${xxx} ⧉ ❳────────────	
│${tz} ${xxx}${prefix}lk21${xxx}
│${tz} ${xxx}${prefix}drakorongoing${xxx}			
│${tz} ${xxx}${prefix}ytplay${xxx}
│${tz} ${xxx}${prefix}ytsearch${xxx}
│${tz} ${xxx}${prefix}ytmp3${xxx}
│${tz} ${xxx}${prefix}ytmp4${xxx}
│${tz} ${xxx}${prefix}telesticker${xxx}
│${tz} ${xxx}${prefix}tiktoknowm${xxx}
│${tz} ${xxx}${prefix}tiktokmusic${xxx}
│${tz} ${xxx}${prefix}spotify${xxx}
│${tz} ${xxx}${prefix}spotifysearch${xxx}
│${tz} ${xxx}${prefix}jooxplay${xxx}
│${tz} ${xxx}${prefix}igdl${xxx}
│${tz} ${xxx}${prefix}igdl2${xxx}
│${tz} ${xxx}${prefix}twtdl${xxx}
│${tz} ${xxx}${prefix}fbdl${xxx}
│${tz} ${xxx}${prefix}zippyshare${xxx}
│${tz} ${xxx}${prefix}pinterest${xxx}
│${tz} ${xxx}${prefix}pinterest2${xxx}
│${tz} ${xxx}${prefix}pinterestdl${xxx}
│
│${xxx}- - Best Regards! - -${xxx}
│${xxx}- - Shirogane Kei Bot - -${xxx}
╰─────────────────────────────────────`
}		

exports.menuZ = (ownername, auth0r, bulan, tchat, tz, prefix) => {
	return`${xxx}- ⟣ - - - - - - Main Menu - - - - - - ⟢ -${xxx}

╭──❲${xxx}- - - -⧉ Exclusive Menu ⧉- - - -${xxx}❳──────
│${tz} ${xxx}${prefix}grupmenu${xxx}
│${tz} ${xxx}${prefix}tagmenu${xxx}
│${tz} ${xxx}${prefix}cekmenu${xxx}
│${tz} ${xxx}${prefix}mediamenu${xxx}
│${tz} ${xxx}${prefix}funtextmenu${xxx}
│${tz} ${xxx}${prefix}makermenu${xxx}
│${tz} ${xxx}${prefix}gunamenu${xxx}
│${tz} ${xxx}${prefix}nsfwmenu${xxx}
│${tz} ${xxx}${prefix}halalmenu${xxx}
│${tz} ${xxx}${prefix}harammenu${xxx}
╰─────────────────────────────────────

╭─────❲ ⧉ ${xxx}Random Features${xxx} ⧉ ❳────────
│${tz} ${xxx}${prefix}ktpmaker${xxx}
│${tz} ${xxx}${prefix}rate${xxx}
│${tz} ${xxx}${prefix}tebakgambar${xxx}
│${tz} ${xxx}${prefix}sambungkata${xxx}
│${tz} ${xxx}${prefix}afk${xxx}
│${tz} ${xxx}${prefix}otakudesu${xxx}
│${tz} ${xxx}${prefix}otakudesu-cari${xxx}
│${tz} ${xxx}${prefix}cari-anime${xxx}
│${tz} ${xxx}${prefix}pixiv${xxx}
│${tz} ${xxx}${prefix}pixivdl${xxx}
│${tz} ${xxx}${prefix}wait${xxx}
│${tz} ${xxx}${prefix}wikipedia${xxx}
│${tz} ${xxx}${prefix}translate${xxx}
│${tz} ${xxx}${prefix}brainly${xxx}
│${tz} ${xxx}${prefix}rate${xxx}
│${tz} ${xxx}${prefix}tebakgambar${xxx}
│${tz} ${xxx}${prefix}canceltebakgambar${xxx}
│${tz} ${xxx}${prefix}sambungkata${xxx}
│${tz} ${xxx}${prefix}cancelsambungkata${xxx}
│${tz} ${xxx}${prefix}afk${xxx}
│${tz} ${xxx}${prefix}waifuu${xxx}
│${tz} ${xxx}${prefix}art${xxx}
│${tz} ${xxx}${prefix}genshin${xxx}
│${tz} ${xxx}${prefix}elf${xxx}
│${tz} ${xxx}${prefix}loli${xxx}
│${tz} ${xxx}${prefix}neko${xxx}
│${tz} ${xxx}${prefix}shota${xxx}
│${tz} ${xxx}${prefix}husbu${xxx}
│${tz} ${xxx}${prefix}sagiri${xxx}
│${tz} ${xxx}${prefix}shinobu${xxx}
│${tz} ${xxx}${prefix}megumin${xxx}
│${tz} ${xxx}${prefix}wallnime${xxx}
│${tz} ${xxx}${prefix}covidindo${xxx}
│${tz} ${xxx}${prefix}covidglobal${xxx}
╰─────────────────────────────────────

╭────────❲ ⧉ ${xxx}Sub Menu${xxx} ⧉ ❳────────────
│${tz} ${xxx}${prefix}internalmenu${xxx}
│${tz} ${xxx}${prefix}nsfwmenu${xxx}
│${tz} ${xxx}${prefix}ownermenu${xxx}
│${tz} ${xxx}${prefix}mygrub${xxx}
│${tz} ${xxx}${prefix}request${xxx}
│${tz} ${xxx}${prefix}infobot${xxx}
│${tz} ${xxx}${prefix}aboutbot${xxx}
╰─────────────────────────────────────

╭──❲${xxx}- -  ⧉ Shirogane Kei Bot ⧉  - -${xxx}❳
│${tz} ${xxx}Owner : ${ownername}${xxx}
│${tz} ${xxx}Author : ${auth0r}${xxx}
│${tz} ${xxx}Bulan: ${bulan}${xxx}
│${tz} ${xxx}Total Chat : ${tchat}${xxx}
╰──────────────────────────────────────

╭───────❲ ⛶ ${xxx}Thx To Donations${xxx} ⛶ ❳───────
│ ⟣─ ${xxx}List Donations${xxx} ─⟢
│ ⟐ ${xxx}Allen${xxx}
│ ⟐ ${xxx}Faiz R.A${xxx}
│ ⟐ ${xxx}Dwi Kurniawan${xxx}
│ ⟐ ${xxx}.......(?)${xxx}
│ ⟐ ${xxx}.......(?)${xxx}
╰─────────────────────────────────────

╭───────────❲ ${xxx}Supported By:${xxx} ❳──────────
│${xxx}────────GitHub──────────────${xxx}
│${tz} ${xxx}Mhank Barbar//github${xxx}
│${tz} ${xxx}LolHuman//github${xxx}
│${tz} ${xxx}Piyo//github${xxx}
│${xxx}─────── API's───────────────${xxx}
│${tz} ${xxx}XteamApi${xxx}
│${tz} ${xxx}ApiZeks${xxx}
│${tz} ${xxx}LoL Human Rests Api${xxx}
│${xxx}───────Forums───────────────${xxx}
│${tz} ${xxx}Hentai.Impact 3${xxx}
│${tz} ${xxx}Nhentai.net${xxx}
│${tz} ${xxx}Nekopoi,care${xxx}
│${tz} ${xxx}Hitomi.la${xxx}
│${tz} ${xxx}Doujindesu.id${xxx}
╰────────❲ ${xxx}Revision ver: theta${xxx} ❳────────`
}
exports.botx = (prefix) => {
	return`[❗] -> MODE LEVELING TIDAK AKTIF\nKETIK *${prefix}leveling*\nUNTUK MENGAKTIFKAN <-`
	}
exports.prem1 = (command) => { 
    return`Emmm... maaf ya kak, tapi fitur: *${command}* Hanya untuk member premium :( \n Mau daftar premium?, silahkan hubungi owner`
    }
exports.error = (prefix, command) => {
    return`[❗] ERROR SILAHKAN LAPORKAN KE OWNER. KETIK *${prefix}bug ${command}*\n[ *APIKEY UNFALID* ]`
    }
exports.info1 = () => { 
    return`🐳 = $200
🦈 = $121
🐬 = $104
🐋 = $94
🐟 = $87
🐠 = $79
🦐 = $62
🦑 = $34
🦀 = $17
🐚 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
  }
exports.info2 = () => { 
    return`🐔 = $200
🦃 = $121
🐿 = $104
🐐 = $94
🐏 = $87
🐖 = $79
🐑 = $62
🐎 = $34
🐺 = $17
🦩 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
}
exports.info3 = () => { 
    return`🦋 = $200
🕷 = $121
🐝 = $104
🐉 = $94
🦆 = $87
🦅 = $79
🕊 = $62
🐧 = $34
🐦 = $17
🦇 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
} 
exports.lvlnul = () => {
	return`Yahhh maaf ya senpai, tapi level mu masih kosong...\n Level bisa ditingkatkan dengan sering nimbrung chat di grup(jangan jadi sider yaa senpai :)), semakin tinggi level semakin banyak Limit yang bisa senpai dapatkan\n\nArigathanks\n_Shirogane Kei Bot_`
}
exports.nayzelite = (pushname, prefix) => { 
    return`╭──❲ ${xxx}Senpai Belum Terdaftar :(${xxx} ❳ 
│${tz} ${xxx}Nama : ${pushname}${xxx}
│${tz} ${xxx}Senpai belum terdaftar di database Bot!${xxx}
│${tz} ${xxx}Silahkan ketik ${prefix}daftar${xxx}
│${tz} ${xxx}Agar Senpai bisa menggunakan bot${xxx}
╰──❲ ${xxx}Shirogane Kei${xxx} ❳`
}
exports.elitenay = (pushname, prefix) => { 
    return`╭──❲ ${xxx}Sukses Terdaftar Senpai! :)${xxx} ❳
│${tz} ${xxx}Nama : ${pushname}${xxx}
│${tz} ${xxx}Main Menu : ${prefix}menu${xxx}
│${tz} ${xxx}Info Bot?, ketik ${prefix}infobot${xxx}
│${tz} ${xxx}Update Changelog Bot, ketik ${prefix}aboutbot${xxx}
│${tz} ${xxx}Mau Donasi?? Ketik ${prefix}donasi${xxx}
│${tz} ${xxx}Ingin tahu siapa Ownernya?? ketik ${prefix}owner${xxx}
╰──❲ ${xxx}Shirogane Kei${xxx} ❳`	
}
exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`╭──❲ ${xxx}Selamat Senpai Naik Level!!${xxx} ❳
│${tz} ${xxx}Nama : ${pushname}${xxx}
│${tz} ${xxx}UID: wa.me/${sender.split("@")[0]}${xxx}
│${tz} ${xxx}Xp : ${getLevelingXp(sender)}${xxx}
│${tz} ${xxx}Limit : +3${xxx} 
│${tz} ${xxx}Level : ${getLevel} ⊱ ${getLevelingLevel(sender)}${xxx}
╰──❲ ${xxx}Shirogane Kei${xxx} ❳`	
}

		//Has already deprecated below
/*
exports.makerfoto = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}Kei-Chan BOT${xxx} ❳
│${tz} ${xxx}${prefix}crossgun${xxx} 
│${tz} ${xxx}${prefix}bakar${xxx}
│${tz} ${xxx}${prefix}pensil${xxx}
│${tz} ${xxx}${prefix}pantaimalam${xxx}
│${tz} ${xxx}${prefix}costumwp${xxx}
│${tz} ${xxx}${prefix}facebookpage${xxx}
│${tz} ${xxx}${prefix}gtav${xxx}
│${tz} ${xxx}${prefix}deteksiumur${xxx}
│${tz} ${xxx}${prefix}removebg${xxx}
│${tz} ${xxx}${prefix}deteksiwajah${xxx}
│${tz} ${xxx}${prefix}wanted${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
exports.spesialmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}Spesial Menu${xxx}⧉ ❳
│${tz} ${xxx}${prefix}randomhentai${xxx}	
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}phkomen${xxx}
│${tz} ${xxx}${prefix}semoji${xxx}
│${tz} ${xxx}${prefix}jadian${xxx}
│${tz} ${xxx}${prefix}citacita${xxx}
│${tz} ${xxx}${prefix}laut${xxx}
│${tz} ${xxx}${prefix}darat${xxx}
│${tz} ${xxx}${prefix}udara${xxx}
│${tz} ${xxx}${prefix}fakta${xxx}
│${tz} ${xxx}${prefix}gcard${xxx}
│${tz} ${xxx}${prefix}ssweb${xxx}
│${tz} ${xxx}${prefix}katailham${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
*/

/*
exports.gamemenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}- Game Menu -${xxx}⧉ ❳
│${tz} ${xxx}${prefix}slot${xxx}
│${tz} ${xxx}${prefix}simi${xxx}
│${tz} ${xxx}${prefix}jumlah${xxx}
│${tz} ${xxx}${prefix}hurufkebalik${xxx}
│${tz} ${xxx}${prefix}tebakgambar${xxx}
│${tz} ${xxx}${prefix}nickff${xxx}
│${tz} ${xxx}${prefix}kapankah${xxx}
│${tz} ${xxx}${prefix}apakah${xxx}
│${tz} ${xxx}${prefix}ramalnomer${xxx} 
│${tz} ${xxx}${prefix}ramalcinta${xxx} 
│${tz} ${xxx}${prefix}jodohbali${xxx} 
│${tz} ${xxx}${prefix}ramalnikah${xxx} 
│${tz} ${xxx}${prefix}taksirmimpi${xxx} 
│${tz} ${xxx}${prefix}suit${xxx}                   
│${tz} ${xxx}${prefix}boomtext${xxx}
│${tz} ${xxx}${prefix}holoh${xxx}
│${tz} ${xxx}${prefix}heleh${xxx}
│${tz} ${xxx}${prefix}huluh${xxx}
│${tz} ${xxx}${prefix}hilih${xxx}
│${tz} ${xxx}${prefix}halah${xxx} 
│${tz} ${xxx}${prefix}kapital${xxx}
│${tz} ${xxx}${prefix}textfont${xxx}
│${tz} ${xxx}${prefix}tebak${xxx}
│${tz} ${xxx}${prefix}oxo${xxx}
│${tz} ${xxx}${prefix}pesan${xxx}
│${tz} ${xxx}${prefix}tebakkimia${xxx}
│${tz} ${xxx}${prefix}tebaklirik${xxx}
│${tz} ${xxx}${prefix}tebakin1${xxx}
│${tz} ${xxx}${prefix}tebakin2${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
exports.randomtext = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}- Random Text Menu -${xxx}⧉ ❳
│${tz} ${xxx}${prefix}quotes2${xxx}
│${tz} ${xxx}${prefix}grubwa${xxx}
│${tz} ${xxx}${prefix}brainly${xxx}
│${tz} ${xxx}${prefix}quotes1${xxx}
│${tz} ${xxx}${prefix}kusonime${xxx}
│${tz} ${xxx}${prefix}renungan${xxx}
│${tz} ${xxx}${prefix}samehadaku${xxx}
│${tz} ${xxx}${prefix}infonomer${xxx}
│${tz} ${xxx}${prefix}jadwaltv${xxx}
│${tz} ${xxx}${prefix}tvjadwal${xxx}
│${tz} ${xxx}${prefix}fml${xxx}
│${tz} ${xxx}${prefix}cinta${xxx}
│${tz} ${xxx}${prefix}resepmasakan${xxx}
│${tz} ${xxx}${prefix}cersex${xxx}
│${tz} ${xxx}${prefix}cerpen${xxx}
│${tz} ${xxx}${prefix}jadwalsholat${xxx}
│${tz} ${xxx}${prefix}pantun${xxx}
│${tz} ${xxx}${prefix}cuaca${xxx}
│${tz} ${xxx}${prefix}namaninja${xxx}
│${tz} ${xxx}${prefix}fake${xxx}
│${tz} ${xxx}${prefix}spamcall${xxx}
│${tz} ${xxx}${prefix}spamemail${xxx}
│${tz} ${xxx}${prefix}quotes${xxx}
│${tz} ${xxx}${prefix}quotesnime${xxx}
│${tz} ${xxx}${prefix}kbbilazimedia${xxx}
│${tz} ${xxx}${prefix}covid${xxx}
│${tz} ${xxx}${prefix}wikiid${xxx}
│${tz} ${xxx}${prefix}wikien${xxx}
│${tz} ${xxx}${prefix}covidid${xxx}
│${tz} ${xxx}${prefix}kbbi${xxx}
│${tz} ${xxx}${prefix}infogempa${xxx}
│${tz} ${xxx}${prefix}randomquran${xxx}
│${tz} ${xxx}${prefix}kisanabi${xxx}
│${tz} ${xxx}${prefix}artinama${xxx}
│${tz} ${xxx}${prefix}artimimpi${xxx}
│${tz} ${xxx}${prefix}artijadian${xxx}
│${tz} ${xxx}${prefix}chord${xxx}
│${tz} ${xxx}${prefix}lirik${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx})
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
exports.fastmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}- Fast Menu -${xxx}⧉ ❳
│${tz} ${xxx}${prefix}fb${xxx}
│${tz} ${xxx}${prefix}tts${xxx}
│${tz} ${xxx}${prefix}steam${xxx}
│${tz} ${xxx}${prefix}stalktwit${xxx}
│${tz} ${xxx}${prefix}stalkgithub${xxx} 
│${tz} ${xxx}${prefix}randomhusbu${xxx}
│${tz} ${xxx}${prefix}pinterest${xxx}
│${tz} ${xxx}${prefix}randomwaifu${xxx}
│${tz} ${xxx}${prefix}randomwaifu1${xxx}
│${tz} ${xxx}${prefix}stalkig${xxx}
│${tz} ${xxx}${prefix}estetikpic${xxx}
│${tz} ${xxx}${prefix}memeindo${xxx}
│${tz} ${xxx}${prefix}darkjokes${xxx}
│${tz} ${xxx}${prefix}urlshort${xxx}
│${tz} ${xxx}${prefix}shortener${xxx}
│${tz} ${xxx}${prefix}fox${xxx}
│${tz} ${xxx}${prefix}dog${xxx}
│${tz} ${xxx}${prefix}cat${xxx}
│${tz} ${xxx}${prefix}panda${xxx}
│${tz} ${xxx}${prefix}panda1${xxx}
│${tz} ${xxx}${prefix}bird${xxx}
│${tz} ${xxx}${prefix}koala${xxx}
│${tz} ${xxx}${prefix}meme${xxx}  
│${tz} ${xxx}${prefix}asupan${xxx}
│${tz} ${xxx}${prefix}asupan1${xxx}
│${tz} ${xxx}${prefix}asupan2${xxx}
│${tz} ${xxx}${prefix}ngakak${xxx}
│${tz} ${xxx}${prefix}pin${xxx} 
│${tz} ${xxx}${prefix}foto${xxx} 
│${tz} ${xxx}${prefix}bts${xxx}
│${tz} ${xxx}${prefix}exo${xxx}
│${tz} ${xxx}${prefix}blackpink${xxx}
│${tz} ${xxx}${prefix}attp${xxx}
│${tz} ${xxx}${prefix}manga1${xxx}
│${tz} ${xxx}${prefix}character${xxx}
│${tz} ${xxx}${prefix}ttp4${xxx}
│${tz} ${xxx}${prefix}ttp3${xxx}
│${tz} ${xxx}${prefix}ttp2${xxx}
│${tz} ${xxx}${prefix}ttp1${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
│${tz} ${xxx}${prefix}stickergif${xxx}
│${tz} ${xxx}${prefix}bug${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx})
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
exports.sertifikat = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}Sertifikat Menu${xxx}⧉ ❳
│${tz} ${xxx}${prefix}ffserti${xxx} 
│${tz} ${xxx}${prefix}ffserti2${xxx}
│${tz} ${xxx}${prefix}ffserti3${xxx}
│${tz} ${xxx}${prefix}ffserti4${xxx}
│${tz} ${xxx}${prefix}ffserti5${xxx}
│${tz} ${xxx}${prefix}pubgserti${xxx}
│${tz} ${xxx}${prefix}pubgserti2${xxx}
│${tz} ${xxx}${prefix}pubgserti3${xxx}
│${tz} ${xxx}${prefix}pubgserti4${xxx}
│${tz} ${xxx}${prefix}pubgserti5${xxx}
│${tz} ${xxx}${prefix}mlserti${xxx}
│${tz} ${xxx}${prefix}mlserti2${xxx}
│${tz} ${xxx}${prefix}mlserti3${xxx}
│${tz} ${xxx}${prefix}mlserti4${xxx}
│${tz} ${xxx}${prefix}mlserti5${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
*/

/*
exports.stickmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}StickMenu${xxx}⧉ ❳  
│${tz} ${xxx}${prefix}stickbucin${xxx}
│${tz} ${xxx}${prefix}stickanjing${xxx}
│${tz} ${xxx}${prefix}gawrgura${xxx}
│${tz} ${xxx}${prefix}umongus${xxx}
│${tz} ${xxx}${prefix}dadu${xxx}
│${tz} ${xxx}${prefix}randompatrick${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
╰──❲ ${xxx}Revision ver: theta${xxx} ❳`
}
exports.promenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}Pro Menu${xxx}⧉ ❳
│${tz} ${xxx}${prefix}nulis1${xxx}
│${tz} ${xxx}${prefix}nulis2${xxx}
│${tz} ${xxx}${prefix}nulis3${xxx}
│${tz} ${xxx}${prefix}nulis4${xxx}
│${tz} ${xxx}${prefix}nulis5${xxx}
│${tz} ${xxx}${prefix}nulis6${xxx}
│${tz} ${xxx}${prefix}video1${xxx}
│${tz} ${xxx}${prefix}video2${xxx}
│${tz} ${xxx}${prefix}video3${xxx}
│${tz} ${xxx}${prefix}video4${xxx}
│${tz} ${xxx}${prefix}video5${xxx}
│${tz} ${xxx}${prefix}video6${xxx}
╰──❲ ${xxx}Revision ver: theta${xxx} ❳`
}
exports.downloadmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}Download Menu${xxx}⧉ ❳
│${tz} ${xxx}${prefix}telesticker${xxx}
│${tz} ${xxx}${prefix}tiktokmusic${xxx}
│${tz} ${xxx}${prefix}tiktoknowm${xxx}
│${tz} ${xxx}${prefix}igfoto${xxx}
│${tz} ${xxx}${prefix}igvideo${xxx}
│${tz} ${xxx}${prefix}ytsearch${xxx}
│${tz} ${xxx}${prefix}ytmp3${xxx}
│${tz} ${xxx}${prefix}ytmp4${xxx}
│${tz} ${xxx}${prefix}play${xxx}
╰──❲ ${xxx}Revision ver: theta${xxx} ❳`
}
exports.soundmenu = (prefix, ownername, tz) => {
	return`╭──❲ ⧉${xxx}Sound Menu${xxx}⧉ ❳
│${tz} ${xxx}${prefix}tomp3${xxx}
│${tz} ${xxx}${prefix}sound1${xxx}
│${tz} ${xxx}${prefix}sound2${xxx}
│${tz} ${xxx}${prefix}sound3${xxx}
│${tz} ${xxx}${prefix}sound4${xxx}
│${tz} ${xxx}${prefix}sound5${xxx}
│${tz} ${xxx}${prefix}sound6${xxx}
│${tz} ${xxx}${prefix}sound7${xxx}
│${tz} ${xxx}${prefix}sound8${xxx}
│${tz} ${xxx}${prefix}sound9${xxx}
│${tz} ${xxx}${prefix}sound10${xxx}
│${tz} ${xxx}${prefix}sound11${xxx}
│${tz} ${xxx}${prefix}sound12${xxx}
│${tz} ${xxx}${prefix}sound13${xxx}
│${tz} ${xxx}${prefix}sound14${xxx}
│${tz} ${xxx}${prefix}sound15${xxx}
│${tz} ${xxx}${prefix}sound16${xxx}
│${tz} ${xxx}${prefix}sound17${xxx}
│${tz} ${xxx}${prefix}sound18${xxx}
│${tz} ${xxx}${prefix}sound19${xxx}
│${tz} ${xxx}${prefix}sound20${xxx}
│${tz} ${xxx}${prefix}sound21${xxx}
│${tz} ${xxx}${prefix}sound22${xxx}
│${tz} ${xxx}${prefix}sound23${xxx}
│${tz} ${xxx}${prefix}sound24${xxx}
│${tz} ${xxx}${prefix}sound25${xxx}
╰──❲ ${xxx}Revision ver: theta${xxx} ❳`
}
exports.pornmenu = (prefix, ownername, tz) => {
	return`╭──❲ ${xxx}- ⧉ Bokep Menu ⧉ -${xxx} ❳
│${tz} ${xxx}${prefix}bokep1${xxx} 
│${tz} ${xxx}${prefix}bokep2${xxx} 
│${tz} ${xxx}${prefix}bokep3${xxx} 
│${tz} ${xxx}${prefix}bokep4${xxx} 
│${tz} ${xxx}${prefix}bokep5${xxx} 
│${tz} ${xxx}${prefix}bokep6${xxx} 
│${tz} ${xxx}${prefix}bokep7${xxx} 
│${tz} ${xxx}${prefix}bokep8${xxx} 
│${tz} ${xxx}${prefix}bokep9${xxx} 
│${tz} ${xxx}${prefix}bokep10${xxx} 
│${tz} ${xxx}${prefix}bokep11${xxx} 
│${tz} ${xxx}${prefix}bokep12${xxx} 
│${tz} ${xxx}${prefix}bokep13${xxx} 
│${tz} ${xxx}${prefix}bokep14${xxx} 
│${tz} ${xxx}${prefix}bokep15${xxx} 
│${tz} ${xxx}${prefix}bokep16${xxx} 
│${tz} ${xxx}${prefix}bokep17${xxx} 
│${tz} ${xxx}${prefix}bokep18${xxx} 
│${tz} ${xxx}${prefix}bokep19${xxx} 
│${tz} ${xxx}${prefix}bokep20${xxx} 
│${tz} ${xxx}${prefix}bokep21${xxx} 
│${tz} ${xxx}${prefix}bokep22${xxx} 
│${tz} ${xxx}${prefix}bokep23${xxx} 
│${tz} ${xxx}${prefix}bokep24${xxx} 
│${tz} ${xxx}${prefix}bokep25${xxx}
│
│──❲ ${xxx} Shirogane Kei Bot ${xxx}
╰──❲ ${xxx} Revision ver: theta ${xxx}❳`
}
*/

/*exports.allmenu = (ownername, auth0r, bulan, tchat, tz, prefix) => {
	return`╭──❲ ${xxx}All Menu${xxx} ❳
│${tz} ${xxx}OWNER : ${ownername}${xxx}
│${tz} ${xxx}AUTHOR : ${auth0r}${xxx}
│${tz} ${xxx}BULAN : ${bulan}${xxx}
│${tz} ${xxx}CHAT : ${tchat}${xxx}
╰──❲ 2021 ❳
╭──❲ ${xxx}ALL MENU BOT${xxx} ❳
│${tz} ${xxx}${prefix}hidetag${xxx}
│${tz} ${xxx}${prefix}add${xxx}
│${tz} ${xxx}${prefix}kick${xxx}
│${tz} ${xxx}${prefix}promote${xxx}
│${tz} ${xxx}${prefix}demote${xxx}
│${tz} ${xxx}${prefix}antilink${xxx}
│${tz} ${xxx}${prefix}welcome${xxx}
│${tz} ${xxx}${prefix}level${xxx}
│${tz} ${xxx}${prefix}limit${xxx}
│${tz} ${xxx}${prefix}leveling${xxx}
│${tz} ${xxx}${prefix}hidetag10${xxx}
│${tz} ${xxx}${prefix}group${xxx}
│${tz} ${xxx}${prefix}antigay${xxx}
│${tz} ${xxx}${prefix}antibocil${xxx}
│${tz} ${xxx}${prefix}antiwibu${xxx}
│${tz} ${xxx}${prefix}antikasar${xxx}
│${tz} ${xxx}${prefix}antitag${xxx}
│${tz} ${xxx}${prefix}antijawa${xxx} 
│${tz} ${xxx}${prefix}katajago${xxx}
│${tz} ${xxx}${prefix}linkgc${xxx}
│${tz} ${xxx}${prefix}tagall${xxx}
│${tz} ${xxx}${prefix}delete${xxx}
│${tz} ${xxx}${prefix}stickbucin${xxx}
│${tz} ${xxx}${prefix}stickanjing${xxx}
│${tz} ${xxx}${prefix}gawrgura${xxx}
│${tz} ${xxx}${prefix}umongus${xxx}
│${tz} ${xxx}${prefix}dadu${xxx}
│${tz} ${xxx}${prefix}randompatrick${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
│${tz} ${xxx}${prefix}wallteknologi${xxx}
│${tz} ${xxx}${prefix}wallhacker${xxx}
│${tz} ${xxx}${prefix}wallcyber${xxx}
│${tz} ${xxx}${prefix}wallmuslim${xxx}
│${tz} ${xxx}${prefix}wallpegunungan${xxx}
│${tz} ${xxx}${prefix}caklontong${xxx}
│${tz} ${xxx}${prefix}robot${xxx}
│${tz} ${xxx}${prefix}3dwhite${xxx}
│${tz} ${xxx}${prefix}daun${xxx}
│${tz} ${xxx}${prefix}metal1${xxx}
│${tz} ${xxx}${prefix}metal${xxx}
│${tz} ${xxx}${prefix}scary${xxx}
│${tz} ${xxx}${prefix}imo${xxx}
│${tz} ${xxx}${prefix}wallpaper${xxx}
│${tz} ${xxx}${prefix}tahta${xxx}
│${tz} ${xxx}${prefix}neon2${xxx}
│${tz} ${xxx}${prefix}wall${xxx}
│${tz} ${xxx}${prefix}wolf${xxx}
│${tz} ${xxx}${prefix}tfire${xxx}
│${tz} ${xxx}${prefix}ytgold${xxx}
│${tz} ${xxx}${prefix}ytsilver${xxx}
│${tz} ${xxx}${prefix}t3d${xxx}
│${tz} ${xxx}${prefix}logoa${xxx}
│${tz} ${xxx}${prefix}pornhub${xxx}
│${tz} ${xxx}${prefix}marvel${xxx}
│${tz} ${xxx}${prefix}leavest${xxx}
│${tz} ${xxx}${prefix}phcoment${xxx}
│${tz} ${xxx}${prefix}nulis${xxx}
│${tz} ${xxx}${prefix}neon1${xxx}
│${tz} ${xxx}${prefix}text3d${xxx}
│${tz} ${xxx}${prefix}galaxy${xxx}
│${tz} ${xxx}${prefix}gaming${xxx}
│${tz} ${xxx}${prefix}colors${xxx}
│${tz} ${xxx}${prefix}kling${xxx}
│${tz} ${xxx}${prefix}barcode${xxx}
│${tz} ${xxx}${prefix}qrcode${xxx}
│${tz} ${xxx}${prefix}8bit${xxx}
│${tz} ${xxx}${prefix}burn${xxx}
│${tz} ${xxx}${prefix}fire${xxx}
│${tz} ${xxx}${prefix}google${xxx}
│${tz} ${xxx}${prefix}battle${xxx}
│${tz} ${xxx}${prefix}block${xxx}
│${tz} ${xxx}${prefix}candy${xxx}
│${tz} ${xxx}${prefix}potter${xxx}
│${tz} ${xxx}${prefix}silk${xxx}
│${tz} ${xxx}${prefix}water${xxx}
│${tz} ${xxx}${prefix}pubg${xxx}
│${tz} ${xxx}${prefix}neon${xxx}
│${tz} ${xxx}${prefix}coffe1${xxx}
│${tz} ${xxx}${prefix}coffe${xxx}
│${tz} ${xxx}${prefix}tiktok${xxx}
│${tz} ${xxx}${prefix}shadow${xxx}
│${tz} ${xxx}${prefix}romance${xxx}
│${tz} ${xxx}${prefix}glass${xxx}
│${tz} ${xxx}${prefix}naruto${xxx}
│${tz} ${xxx}${prefix}mug1${xxx}
│${tz} ${xxx}${prefix}love${xxx}
│${tz} ${xxx}${prefix}mug${xxx}
│${tz} ${xxx}${prefix}neon1${xxx}
│${tz} ${xxx}${prefix}smoke${xxx}
│${tz} ${xxx}${prefix}rainbow${xxx}
│${tz} ${xxx}${prefix}nulis1${xxx}
│${tz} ${xxx}${prefix}nulis2${xxx}
│${tz} ${xxx}${prefix}nulis3${xxx}
│${tz} ${xxx}${prefix}nulis4${xxx}
│${tz} ${xxx}${prefix}nulis5${xxx}
│${tz} ${xxx}${prefix}nulis6${xxx}
│${tz} ${xxx}${prefix}video1${xxx}
│${tz} ${xxx}${prefix}video2${xxx}
│${tz} ${xxx}${prefix}video3${xxx}
│${tz} ${xxx}${prefix}video4${xxx}
│${tz} ${xxx}${prefix}video5${xxx}
│${tz} ${xxx}${prefix}video6${xxx}
│${tz} ${xxx}${prefix}telesticker${xxx}
│${tz} ${xxx}${prefix}tiktokmusic${xxx}
│${tz} ${xxx}${prefix}tiktoknowm${xxx}
│${tz} ${xxx}${prefix}igfoto${xxx}
│${tz} ${xxx}${prefix}igvideo${xxx}
│${tz} ${xxx}${prefix}ytsearch${xxx}
│${tz} ${xxx}${prefix}ytmp3${xxx}
│${tz} ${xxx}${prefix}ytmp4${xxx}
│${tz} ${xxx}${prefix}play${xxx}
│${tz} ${xxx}${prefix}sound1${xxx}
│${tz} ${xxx}${prefix}sound2${xxx}
│${tz} ${xxx}${prefix}sound3${xxx}
│${tz} ${xxx}${prefix}sound4${xxx}
│${tz} ${xxx}${prefix}sound5${xxx}
│${tz} ${xxx}${prefix}sound6${xxx}
│${tz} ${xxx}${prefix}sound7${xxx}
│${tz} ${xxx}${prefix}sound8${xxx}
│${tz} ${xxx}${prefix}sound9${xxx}
│${tz} ${xxx}${prefix}sound10${xxx}
│${tz} ${xxx}${prefix}sound11${xxx}
│${tz} ${xxx}${prefix}sound12${xxx}
│${tz} ${xxx}${prefix}sound13${xxx}
│${tz} ${xxx}${prefix}sound14${xxx}
│${tz} ${xxx}${prefix}sound15${xxx}
│${tz} ${xxx}${prefix}sound16${xxx}
│${tz} ${xxx}${prefix}sound17${xxx}
│${tz} ${xxx}${prefix}sound18${xxx}
│${tz} ${xxx}${prefix}sound19${xxx}
│${tz} ${xxx}${prefix}sound20${xxx}
│${tz} ${xxx}${prefix}sound21${xxx}
│${tz} ${xxx}${prefix}sound22${xxx}
│${tz} ${xxx}${prefix}sound23${xxx}
│${tz} ${xxx}${prefix}sound24${xxx}
│${tz} ${xxx}${prefix}sound25${xxx}
│${tz} ${xxx}${prefix}indo1${xxx} 
│${tz} ${xxx}${prefix}indo2${xxx} 
│${tz} ${xxx}${prefix}indo3${xxx} 
│${tz} ${xxx}${prefix}indo4${xxx} 
│${tz} ${xxx}${prefix}indo5${xxx} 
│${tz} ${xxx}${prefix}indo6${xxx} 
│${tz} ${xxx}${prefix}indo7${xxx} 
│${tz} ${xxx}${prefix}indo8${xxx} 
│${tz} ${xxx}${prefix}indo9${xxx} 
│${tz} ${xxx}${prefix}indo10${xxx} 
│${tz} ${xxx}${prefix}indo11${xxx} 
│${tz} ${xxx}${prefix}indo12${xxx} 
│${tz} ${xxx}${prefix}indo13${xxx} 
│${tz} ${xxx}${prefix}indo14${xxx} 
│${tz} ${xxx}${prefix}indo15${xxx} 
│${tz} ${xxx}${prefix}indo16${xxx} 
│${tz} ${xxx}${prefix}indo17${xxx} 
│${tz} ${xxx}${prefix}indo18${xxx} 
│${tz} ${xxx}${prefix}indo19${xxx} 
│${tz} ${xxx}${prefix}indo20${xxx} 
│${tz} ${xxx}${prefix}indo21${xxx} 
│${tz} ${xxx}${prefix}indo22${xxx} 
│${tz} ${xxx}${prefix}indo23${xxx} 
│${tz} ${xxx}${prefix}indo24${xxx} 
│${tz} ${xxx}${prefix}indo25${xxx}
│${tz} ${xxx}${prefix}readmore${xxx}
│${tz} ${xxx}${prefix}chatlist${xxx}
│${tz} ${xxx}${prefix}addsticker${xxx}
│${tz} ${xxx}${prefix}addvn${xxx}
│${tz} ${xxx}${prefix}getvn${xxx}
│${tz} ${xxx}${prefix}getsticker${xxx}
│${tz} ${xxx}${prefix}liststicker${xxx}
│${tz} ${xxx}${prefix}listvn${xxx}
│${tz} ${xxx}${prefix}addimage${xxx}
│${tz} ${xxx}${prefix}getimage${xxx}
│${tz} ${xxx}${prefix}imagelist${xxx}
│${tz} ${xxx}${prefix}addvideo${xxx}
│${tz} ${xxx}${prefix}getvideo${xxx}
│${tz} ${xxx}${prefix}listvideo${xxx}
│${tz} ${xxx}${prefix}gaycek${xxx}
│${tz} ${xxx}${prefix}hodecek${xxx}
│${tz} ${xxx}${prefix}gantengcek${xxx}
│${tz} ${xxx}${prefix}cantikcek${xxx}
│${tz} ${xxx}${prefix}jelekcek${xxx}
│${tz} ${xxx}${prefix}goblokcek${xxx}
│${tz} ${xxx}${prefix}begocek${xxx}
│${tz} ${xxx}${prefix}pintercek${xxx}
│${tz} ${xxx}${prefix}jagocek${xxx}
│${tz} ${xxx}${prefix}nolepcek${xxx}
│${tz} ${xxx}${prefix}babicek${xxx}
│${tz} ${xxx}${prefix}bebancek${xxx}
│${tz} ${xxx}${prefix}baikcek${xxx}
│${tz} ${xxx}${prefix}jahatcek${xxx}
│${tz} ${xxx}${prefix}anjingcek${xxx}
│${tz} ${xxx}${prefix}haramcek${xxx}
│${tz} ${xxx}${prefix}kontolcek${xxx}
│${tz} ${xxx}${prefix}pakboycek${xxx}
│${tz} ${xxx}${prefix}pakgirlcek${xxx}
│${tz} ${xxx}${prefix}sangecek${xxx}
│${tz} ${xxx}${prefix}bapercek${xxx}
│${tz} ${xxx}${prefix}ganteng${xxx}
│${tz} ${xxx}${prefix}cantik${xxx}
│${tz} ${xxx}${prefix}jelek${xxx}
│${tz} ${xxx}${prefix}goblok${xxx}
│${tz} ${xxx}${prefix}bego${xxx}
│${tz} ${xxx}${prefix}pinter${xxx}
│${tz} ${xxx}${prefix}jago${xxx}
│${tz} ${xxx}${prefix}babi${xxx}
│${tz} ${xxx}${prefix}beban${xxx}
│${tz} ${xxx}${prefix}baik${xxx}
│${tz} ${xxx}${prefix}jahat${xxx}
│${tz} ${xxx}${prefix}anjing${xxx}
│${tz} ${xxx}${prefix}monyet${xxx}
│${tz} ${xxx}${prefix}haram${xxx}
│${tz} ${xxx}${prefix}kontol${xxx}
│${tz} ${xxx}${prefix}pakboy${xxx}
│${tz} ${xxx}${prefix}pakgirl${xxx}
│${tz} ${xxx}${prefix}sadboy${xxx}
│${tz} ${xxx}${prefix}sadgirl${xxx}
│${tz} ${xxx}${prefix}wibu${xxx}
│${tz} ${xxx}${prefix}nolep${xxx}
│${tz} ${xxx}${prefix}hebat${xxx}
│${tz} ${xxx}${prefix}slot${xxx}
│${tz} ${xxx}${prefix}simi${xxx}
│${tz} ${xxx}${prefix}jumlah${xxx}
│${tz} ${xxx}${prefix}hurufkebalik${xxx}
│${tz} ${xxx}${prefix}tebakgambar${xxx}
│${tz} ${xxx}${prefix}nickff${xxx}
│${tz} ${xxx}${prefix}kapankah${xxx}
│${tz} ${xxx}${prefix}apakah${xxx}
│${tz} ${xxx}${prefix}ramalnomer${xxx} 
│${tz} ${xxx}${prefix}ramalcinta${xxx} 
│${tz} ${xxx}${prefix}jodohbali${xxx} 
│${tz} ${xxx}${prefix}ramalnikah${xxx} 
│${tz} ${xxx}${prefix}taksirmimpi${xxx} 
│${tz} ${xxx}${prefix}suit${xxx}                   
│${tz} ${xxx}${prefix}boomtext${xxx}
│${tz} ${xxx}${prefix}holoh${xxx}
│${tz} ${xxx}${prefix}heleh${xxx}
│${tz} ${xxx}${prefix}huluh${xxx}
│${tz} ${xxx}${prefix}hilih${xxx}
│${tz} ${xxx}${prefix}halah${xxx} 
│${tz} ${xxx}${prefix}kapital${xxx}
│${tz} ${xxx}${prefix}textfont${xxx}
│${tz} ${xxx}${prefix}tebak${xxx}
│${tz} ${xxx}${prefix}oxo${xxx}
│${tz} ${xxx}${prefix}pesan${xxx}
│${tz} ${xxx}${prefix}tebakkimia${xxx}
│${tz} ${xxx}${prefix}tebaklirik${xxx}
│${tz} ${xxx}${prefix}tebakin1${xxx}
│${tz} ${xxx}${prefix}tebakin2${xxx}
│${tz} ${xxx}${prefix}quotes2${xxx}
│${tz} ${xxx}${prefix}quotes1${xxx}
│${tz} ${xxx}${prefix}kusonime${xxx}
│${tz} ${xxx}${prefix}renungan${xxx}
│${tz} ${xxx}${prefix}samehadaku${xxx}
│${tz} ${xxx}${prefix}infonomer${xxx}
│${tz} ${xxx}${prefix}jadwaltv${xxx}
│${tz} ${xxx}${prefix}tvjadwal${xxx}
│${tz} ${xxx}${prefix}fml${xxx}
│${tz} ${xxx}${prefix}cinta${xxx}
│${tz} ${xxx}${prefix}resepmasakan${xxx}
│${tz} ${xxx}${prefix}cersex${xxx}
│${tz} ${xxx}${prefix}cerpen${xxx}
│${tz} ${xxx}${prefix}jadwalsholat${xxx}
│${tz} ${xxx}${prefix}pantun${xxx}
│${tz} ${xxx}${prefix}cuaca${xxx}
│${tz} ${xxx}${prefix}namaninja${xxx}
│${tz} ${xxx}${prefix}fake${xxx}
│${tz} ${xxx}${prefix}spamcall${xxx}
│${tz} ${xxx}${prefix}spamemail${xxx}
│${tz} ${xxx}${prefix}quotes${xxx}
│${tz} ${xxx}${prefix}quotesnime${xxx}
│${tz} ${xxx}${prefix}kbbilazimedia${xxx}
│${tz} ${xxx}${prefix}covid${xxx}
│${tz} ${xxx}${prefix}wikiid${xxx}
│${tz} ${xxx}${prefix}wikien${xxx}
│${tz} ${xxx}${prefix}covidid${xxx}
│${tz} ${xxx}${prefix}kbbi${xxx}
│${tz} ${xxx}${prefix}infogempa${xxx}
│${tz} ${xxx}${prefix}randomquran${xxx}
│${tz} ${xxx}${prefix}kisanabi${xxx}
│${tz} ${xxx}${prefix}artinama${xxx}
│${tz} ${xxx}${prefix}artimimpi${xxx}
│${tz} ${xxx}${prefix}artijadian${xxx}
│${tz} ${xxx}${prefix}chord${xxx}
│${tz} ${xxx}${prefix}lirik${xxx}
│${tz} ${xxx}${prefix}fb${xxx}
│${tz} ${xxx}${prefix}tts${xxx}
│${tz} ${xxx}${prefix}steam${xxx}
│${tz} ${xxx}${prefix}stalktwit${xxx}
│${tz} ${xxx}${prefix}stalkgithub${xxx} 
│${tz} ${xxx}${prefix}randomhusbu${xxx}
│${tz} ${xxx}${prefix}pinterest${xxx}
│${tz} ${xxx}${prefix}randomwaifu${xxx}
│${tz} ${xxx}${prefix}randomwaifu1${xxx}
│${tz} ${xxx}${prefix}stalkig${xxx}
│${tz} ${xxx}${prefix}estetikpic${xxx}
│${tz} ${xxx}${prefix}memeindo${xxx}
│${tz} ${xxx}${prefix}darkjokes${xxx}
│${tz} ${xxx}${prefix}urlshort${xxx}
│${tz} ${xxx}${prefix}shortener${xxx}
│${tz} ${xxx}${prefix}fox${xxx}
│${tz} ${xxx}${prefix}dog${xxx}
│${tz} ${xxx}${prefix}cat${xxx}
│${tz} ${xxx}${prefix}panda${xxx}
│${tz} ${xxx}${prefix}panda1${xxx}
│${tz} ${xxx}${prefix}bird${xxx}
│${tz} ${xxx}${prefix}koala${xxx}
│${tz} ${xxx}${prefix}meme${xxx}  
│${tz} ${xxx}${prefix}asupan${xxx}
│${tz} ${xxx}${prefix}asupan1${xxx}
│${tz} ${xxx}${prefix}asupan2${xxx}
│${tz} ${xxx}${prefix}ngakak${xxx}
│${tz} ${xxx}${prefix}pin${xxx} 
│${tz} ${xxx}${prefix}foto${xxx} 
│${tz} ${xxx}${prefix}bts${xxx}
│${tz} ${xxx}${prefix}exo${xxx}
│${tz} ${xxx}${prefix}blackpink${xxx}
│${tz} ${xxx}${prefix}attp${xxx}
│${tz} ${xxx}${prefix}manga1${xxx}
│${tz} ${xxx}${prefix}character${xxx}
│${tz} ${xxx}${prefix}ttp4${xxx}
│${tz} ${xxx}${prefix}ttp3${xxx}
│${tz} ${xxx}${prefix}ttp2${xxx}
│${tz} ${xxx}${prefix}ttp1${xxx}
│${tz} ${xxx}${prefix}sticker${xxx}
│${tz} ${xxx}${prefix}stickergif${xxx}
│${tz} ${xxx}${prefix}bug${xxx}
│${tz} ${xxx}${prefix}ffserti${xxx} 
│${tz} ${xxx}${prefix}ffserti2${xxx}
│${tz} ${xxx}${prefix}ffserti3${xxx}
│${tz} ${xxx}${prefix}ffserti4${xxx}
│${tz} ${xxx}${prefix}ffserti5${xxx}
│${tz} ${xxx}${prefix}pubgserti${xxx}
│${tz} ${xxx}${prefix}pubgserti2${xxx}
│${tz} ${xxx}${prefix}pubgserti3${xxx}
│${tz} ${xxx}${prefix}pubgserti4${xxx}
│${tz} ${xxx}${prefix}pubgserti5${xxx}
│${tz} ${xxx}${prefix}mlserti${xxx}
│${tz} ${xxx}${prefix}mlserti2${xxx}
│${tz} ${xxx}${prefix}mlserti3${xxx}
│${tz} ${xxx}${prefix}mlserti4${xxx}
│${tz} ${xxx}${prefix}mlserti5${xxx}
│${tz} ${xxx}${prefix}dellprem${xxx} 
│${tz} ${xxx}${prefix}addprem${xxx}
│${tz} ${xxx}${prefix}clearall${xxx}
│${tz} ${xxx}${prefix}bc${xxx}
│${tz} ${xxx}${prefix}owner${xxx}
│${tz} ${xxx}${prefix}author${xxx}
│${tz} ${xxx}${prefix}bugtroli${xxx}
│${tz} ${xxx}${prefix}setout${xxx}
│${tz} ${xxx}${prefix}setwelcome${xxx}
│${tz} ${xxx}${prefix}settz${xxx}
│${tz} ${xxx}${prefix}setthum${xxx}
│${tz} ${xxx}${prefix}setpp${xxx}
│${tz} ${xxx}${prefix}setprefix${xxx}
│${tz} ${xxx}${prefix}setreply${xxx}
│${tz} ${xxx}${prefix}crossgun${xxx} 
│${tz} ${xxx}${prefix}bakar${xxx}
│${tz} ${xxx}${prefix}pensil${xxx}
│${tz} ${xxx}${prefix}pantaimalam${xxx}
│${tz} ${xxx}${prefix}costumwp${xxx}
│${tz} ${xxx}${prefix}facebookpage${xxx}
│${tz} ${xxx}${prefix}gtav${xxx}
│${tz} ${xxx}${prefix}deteksiumur${xxx}
│${tz} ${xxx}${prefix}removebg${xxx}
│${tz} ${xxx}${prefix}deteksiwajah${xxx}
│${tz} ${xxx}${prefix}wanted${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
│${tz} ${xxx}${prefix}phkomen${xxx}
│${tz} ${xxx}${prefix}semoji${xxx}
│${tz} ${xxx}${prefix}jadian${xxx}
│${tz} ${xxx}${prefix}citacita${xxx}
│${tz} ${xxx}${prefix}laut${xxx}
│${tz} ${xxx}${prefix}darat${xxx}
│${tz} ${xxx}${prefix}udara${xxx}
│${tz} ${xxx}${prefix}fakta${xxx}
│${tz} ${xxx}${prefix}gcard${xxx}
│${tz} ${xxx}${prefix}ssweb${xxx}
│${tz} ${xxx}${prefix}katailham${xxx}
│${tz} ${xxx}${prefix}randomwibu${xxx}
╰──❲ ${xxx}2021${xxx} ❳

╭──❲ ${xxx}⧉ Sub Menu ⧉${xxx} ❳──────
│${tz} ${xxx}${prefix}ownermenu${xxx}
│${tz} ${xxx}${prefix}allmenu${xxx}
│${tz} ${xxx}${prefix}mygrub${xxx}
│${tz} ${xxx}${prefix}request${xxx}
│${tz} ${xxx}${prefix}menubaru${xxx}
│${tz} ${xxx}${prefix}nsfwmenu${xxx}
╰─────────────────────────────────────

╭─❲ ${xxx}⛶ Thx To Donations ⛶${xxx} ❳─
│    ⟣─❲ ${xxx}Donations${xxx} ❳─⟢
│${tz} ${xxx}Allen${xxx}
│${tz} ${xxx}Faiz R.A${xxx}
│${tz} ${xxx}.......(?)${xxx}
│${tz} ${xxx}.......(?)${xxx}
│${tz} ${xxx}.......(?)${xxx}
╰─────────────────────────────────────

╭───────❲ ⛶ Thx To Donations ⛶ ❳───────
│ ⟣─ List Donations ─⟢
│ ⟐ ${xxx}Allen${xxx}
│ ⟐ ${xxx}Faiz R.A${xxx}
│ ⟐ ${xxx}.......(?)${xxx}
│ ⟐ ${xxx}.......(?)${xxx}
│ ⟐ ${xxx}.......(?)${xxx}
╰─────────────────────────────────────

╭──❲ ${xxx}Supported By:${xxx} ❳───────
│${xxx}────────GitHub──────────────${xxx}
│${tz} ${xxx}Mhank Barbar//github${xxx}
│${tz} ${xxx}LolHuman//github${xxx}
│${tz} ${xxx}Piyo//github${xxx}
│${xxx}─────── API's───────────────${xxx}
│${tz} ${xxx}XteamApi${xxx}
│${tz} ${xxx}ApiZeks${xxx}
│${tz} ${xxx}LoL Human Rests Api${xxx}
│${xxx}───────Forums───────────────${xxx}
│${tz} ${xxx}Hentai Impact 3${xxx}
│${tz} ${xxx}Nhentai.net${xxx}
│${tz} ${xxx}Nekopoi,care${xxx}
│${tz} ${xxx}Hitomi.La${xxx}
│${tz} ${xxx}Doujindesu.site${xxx}
╰────────❲ Revision ver: theta ❳────────`
}
*/