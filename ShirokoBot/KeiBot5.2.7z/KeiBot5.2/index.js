//================================
//============[ Shirogane Kei Bot ]============
//Real case from : naylachan
//Revision ver 5.2
//================================
const {
		WAConnection,
		MessageType,
		Presence,
		MessageOptions,
		Mimetype,
		WALocationMessage,
		WA_MESSAGE_STUB_TYPES,
		WA_DEFAULT_EPHEMERAL,
		ReconnectMode,
		ProxyAgent,
		GroupSettingChange,
		waChatKey,
		mentionedJid,
		processTime,
} = require('@adiwajshing/baileys')
const { color, bgcolor } = require('./lib/color')
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const { fetchJson, fetchText } = require('./lib/fetcher')
const request = require('request')
const { recognize } = require('./lib/ocr')
const fs = require('fs')
const crypto = require('crypto')  
const moment = require('moment-timezone')
const { exec, spawn, execSync } = require("child_process")  
const ffmpeg = require('fluent-ffmpeg') 
const { nyz } = require('./private')
const imgbb = require('imgbb-uploader')  
const setting = JSON.parse(fs.readFileSync('./src/settings.json'))
const nayz = JSON.parse(fs.readFileSync('./lib/tes.json'))


/* ===================================================[  CHANGELOG BOT  ]==============================================================

		Modification case [LoLHman] --> js 1671 ~ 2506 (last updated on patch 5.2)

   ===================================================[ BOT WHATSAPP ]==============================================================*/
             	   
const { 
	bayarLimit, 
	limitAdd
} = require('./lib/limitatm.js') 
const {
	getLevelingXp,
	getLevelingLevel,
	getLevelingId,
	addLevelingXp,
	addLevelingLevel,
	addLevelingId
} = require('./lib/level.js')

grub1 = setting.grub1
grub2 = setting.grub2
grub3 = setting.grub3
apikey = nayz.apikey
elitrespon = nayz.elitrespon
connet = nayz.connet
auth0r = nayz.auth0r
replytroli = nayz.replytroli
prefix = setting.prefix
limitawal = 20
blocked = []
apixteam = setting.apixteam
cr = setting.cr
ownerrf = setting.ownerrf
ownerrz = setting.ownerrz
lort = setting.lort
tz = setting.tz 
cr1 = setting.cr1
cr2 = setting.cr2
numberbot = setting.numberbot
apivhtear = setting.apivhtear
fake1 = setting.fake1
fake2 = setting.fake2
author = setting.author
naylachan = setting.naylachan
namebot = setting.namebot
ownername = setting.ownername
donasi = setting.donasi
l0lhuman = setting.l0lhuman
pulsa = setting.pulsa
gopay = setting.gopay
ovo = setting.ovo
dana = setting.dana
 
// NOTE MAU UBAH??? SILAHKAN UBAH DI SRC + SETTINGS.JSON
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ ROOM TO FILE ]==============================================================*/                  	                         	 

const _Elite = JSON.parse(fs.readFileSync('./nayla/Elite.json')) 
const setiker = JSON.parse(fs.readFileSync('./src/stik.json'))
const videonye = JSON.parse(fs.readFileSync('./src/video.json'))
const audionye = JSON.parse(fs.readFileSync('./src/audio.json'))
const imagenye = JSON.parse(fs.readFileSync('./src/image.json')) 
const antilink = JSON.parse(fs.readFileSync('./nayla/antilink.json'))
const event = JSON.parse(fs.readFileSync('./nayla/event.json'))
const antiwibu = JSON.parse(fs.readFileSync('./nayla/antiwibu.json'))
const antijawa = JSON.parse(fs.readFileSync('./nayla/antijawa.json'))
const prem = JSON.parse(fs.readFileSync('./nayla/prem.json'))
const welkom = JSON.parse(fs.readFileSync('./nayla/welkom.json'))
const antigay = JSON.parse(fs.readFileSync('./nayla/antigay.json'))
const antibocil = JSON.parse(fs.readFileSync('./nayla/antibocil.json'))
const _limit = JSON.parse(fs.readFileSync('./nayla/limit.json'))
const botx = JSON.parse(fs.readFileSync('./nayla/botx.json')) 
const nayXi = JSON.parse(fs.readFileSync('./nayla/nayXi.json')) 
const _leveling = JSON.parse(fs.readFileSync('./nayla/leveling.json'))
const _level = JSON.parse(fs.readFileSync('./nayla/level.json'))
const nayXix = JSON.parse(fs.readFileSync('./nayla/nayXix.json')) 
// Database
const tebakgambar = JSON.parse(fs.readFileSync('./nayla/tebakgambar.json'))
const sambungkata = JSON.parse(fs.readFileSync('./nayla/sambungkata.json'))
const afk = JSON.parse(fs.readFileSync('./nayla/afk.json'))
 
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*======================================================[ TIME BOTZ ]==============================================================*/                  	                    	              
            function kyun(seconds){
            function pad(s){
            return (s < 10 ? '0' : '') + s;
            }
            var hours = Math.floor(seconds / (60*60));
            var minutes = Math.floor(seconds % (60*60) / 60);
            var seconds = Math.floor(seconds % 60);
            return `${pad(hours)} Jam ~ ${pad(minutes)} Menit ~ ${pad(seconds)} Detik`
            }

/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ CONNECTING  ]==============================================================*/                  	    
                	 
            async function starts() {
        	const nayla = new WAConnection()
	        nayla.logger.level = 'warn'
	        console.log(banner.string)
        	nayla.on('qr', () => {
     		console.log(color('[','white'), color('!','red'), color(']','white'), color('Shirogane Kei-BOT'))
	        })
	        fs.existsSync('./self-bot.json') && nayla.loadAuthInfo('./self-bot.json')
	        nayla.on('connecting', () => {
		    start('2', 'Connecting...')		   
        	})
	        nayla.on('open', () => {
	    	success('2', 'BY Shirogane Kei BOT')
	    	setTimeout( () => {
	    	console.log(color(`Starting to initiate Bot`, 'pink'))
	    	}, 1000)
	    	setTimeout( () => {
	    	console.log(color(`Prepare for node js`, 'pink'))
	    	}, 2000)
	    	setTimeout( () => {
	    	console.log(color(`Node  index.js are starting...`, 'pink'))
	    	}, 3000)
	    	setTimeout( () => {
	    	console.log(color(`Succesfull to execute, preparing to connect...`, 'pink'))
	    	}, 4000)
	    	setTimeout( () => {
	    	console.log(color(`Connecting.... checking network`, 'pink'))
	    	}, 5000)
	    	setTimeout( () => {
	    	console.log(color(`Success to connect Bot, please enjoy :)`, 'pink'))
	    	}, 6000)	    	     	
         	})         	
         	nayla.sendMessage(`${setting.ownerNumber}@s.whatsapp.net`, `Bot sukses connect pak, siap dipakai!`, MessageType.text)
        	await nayla.connect({timeoutMs: 30*1000})
            fs.writeFileSync('./self-bot.json', JSON.stringify(nayla.base64EncodedAuthInfo(), null, '\t'))
	        nayla.on('CB:Blocklist', json => {
            if (blocked.length > 2) return
	        for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))     	
	        }
        	})
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=======================================================[ WELCOME ]==============================================================*/                  	    
            nayla.on('group-participants-update', async (anu) => {
	    	if (!welkom.includes(anu.jid)) return
		    try {
			const mdata = await nayla.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
		    num = anu.participants[0]
		    try { //make an alternate
			ppimg = await nayla.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`) //ambil pp yg br masuk grub
		    } catch {
			ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
		    }
			teks = `▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱\n`
			teks += `*Halo kak @${num.split('@')[0]}*\n` //member
			teks += `*Selamat Datang di Grub*\n`
			teks += `*${mdata.subject}*\n`			
			teks += `▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱\n`
			teks += `Selamat Datang Member Baru!\n`
			teks += `╭───────[ *Intro* ]──────────\n`
			teks += `│➻ *Nama* :\n`
			teks += `│➻ *Umur* :\n`
			teks += `│➻ *Gender* :\n`
			teks += `│➻ *AsKot* :\n`
			teks += `│➻ *Alasan Bergabung* :\n`
			teks += `│➻ *Supremacy: Loli/Teen/Milf* :\n` //dimas gay
			teks += `│➻ *Flag : Yuri/Yaoi/normal*   :\n`
			teks += `│   *pilih salah satu~ \n`
			teks += `╰────────────────────────\n`			
			teks += `_Gunakan fitur #intro_ \n`
			teks += `_utk menyalin pesan ini!_ \n`
			teks += `                              \n`
			teks += `                              \n`
			teks += `_Semoga Betah disini Yaaa_ 😊 \n`
			teks += `_jangan sungkan kalo mau ngobrol"_ 🤗 \n`
			teks += `▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱\n`
			teks += ` ⎾ _Shirogane Kei BOT_ ⏌\n`
			teks += ` ⎾ _Armada BOT ⏌_\n`
			teks += `▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱`			
			let buff = await getBuffer(ppimg)
		    nayla.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
			num = anu.participants[0] //out dari grub
			try {
			ppimg = await nayla.getProfilePicture(`${num.split('@')[0]}@c.us`) //ini kalo pp nya kosonk
			} catch {
			ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
			}
			teks = `Selamat tinggal senpai!,bye bye~ 🥳 @${num.split('@')[0]} jasamu akan Kei-chan kubur dalam² \nSemoga tenang disana yaaa 😘`
			let buff = await getBuffer(ppimg)
			nayla.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		    } catch (e) {
			console.log('Error : %s', color(e, 'red'))
		    }
	        })	        
             
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ API VIDEFIKRI ]==============================================================*/                  	                 
	        
	        nayla.on('chat-update', async (nay) => {
      		try {
            if (!nay.hasNewMessage) return
            nay = nay.messages.all()[0]
			if (!nay.message) return
			if (nay.key && nay.key.remoteJid == 'status@broadcast') return
			if (nay.key.fromMe) return
			global.prefix
			global.blocked				 
			const content = JSON.stringify(nay.message)
			const from = nay.key.remoteJid
	        const type = Object.keys(nay.message)[0]
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			body = (type === 'conversation' && nay.message.conversation.startsWith(prefix)) ? nay.message.conversation : (type == 'imageMessage') && nay.message.imageMessage.caption.startsWith(prefix) ? nay.message.imageMessage.caption : (type == 'videoMessage') && nay.message.videoMessage.caption.startsWith(prefix) ? nay.message.videoMessage.caption : (type == 'extendedTextMessage') && nay.message.extendedTextMessage.text.startsWith(prefix) ? nay.message.extendedTextMessage.text : ''
			var pes = (type === 'conversation' && nay.message.conversation) ? nay.message.conversation : (type == 'imageMessage') && nay.message.imageMessage.caption ? nay.message.imageMessage.caption : (type == 'videoMessage') && nay.message.videoMessage.caption ? nay.message.videoMessage.caption : (type == 'extendedTextMessage') && nay.message.extendedTextMessage.text ? nay.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? nay.message.conversation : (type === 'extendedTextMessage') ? nay.message.extendedTextMessage.text : ''
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const q = args.join(' ')
	      	runtime = process.uptime()   
	      	const fake3 = `- *${namebot}* -\nWaktu Aktif: ${kyun(runtime)}` 	
	      	const nay1 = {
		    key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": fake3} } } 
			const isCmd = body.startsWith(prefix)             
            const tescuk = ["0@s.whatsapp.net"]
			const botNumber = nayla.user.jid
			const ownerNumber = [`${setting.ownerNumber}@s.whatsapp.net`] 
			const isGroup = from.endsWith('@g.us')
			const totalchat = await nayla.chats.all()
			const sender = isGroup ? nay.participant : nay.key.remoteJid
			const groupMetadata = isGroup ? await nayla.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isOwner = ownerNumber.includes(sender)
			const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
			const isAntiLink = isGroup ? antilink.includes(from) : false
			const isEventon = isGroup ? event.includes(from) : false
			const isAntigay = isGroup ? antigay.includes(from) : false
			const isAntibocil = isGroup ? antibocil.includes(from) : false
			const isAntiwibu = isGroup ? antiwibu.includes(from) : false
			const isWelkom = isGroup ? welkom.includes(from) : false			 
			const isAntijawa = isGroup ? antijawa.includes(from) : false
			const isNayXi = isGroup ? nayXi.includes(from) : false			     
			const isNayXix = isGroup ? nayXix.includes(from) : false			 		 
			const isPrem = prem.includes(sender) || isOwner				
			const isLevelingOn = isGroup ? _leveling.includes(from) : false
			const isBotx = isGroup ? botx.includes(from) : false
			//const istebakgambar = isGroup ? tebakgambar.includes(from) : false
			pushname = nayla.contacts[sender] != undefined ? nayla.contacts[sender].vname || nayla.contacts[sender].notify : undefined									            
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? nayla.sendMessage(from, teks.trim(), extendedText, { contextInfo: { "mentionedJid": memberr } }) : nayla.sendMessage(from, teks.trim(), extendedText, { quoted: nay, contextInfo: { "mentionedJid": memberr } })
			}
		    const nay2 = {
		    key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `MAAF FITUR ${command} TIDAK TERDAFTAR DIDALAM MENU`} } }
		    const nay3 = {
            key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `SIMI-SIMI CHAT\nCHAT OTOMATIS`} } }            			
		    const costum = (pesan, tipe, target, target2) => {
			nayla.sendMessage(from, pesan, tipe, {quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target2}` }}})
			}
	//COBA COBA MODIF MENTIONS!	
		//CASE ASLI:
			const reply = (teks) => {
			nayla.sendMessage(from, teks, text)
			}				
			/*const reply = (teks) => {
				jds = []
				mentions(teks, jds, true(from, teks, text))
			}*/
			const nayz = (teks) => {
				nayla.sendMessage(from, teks, text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `ERROR FITUR. LAPORKAN SEGERA!!!!` }}})
			}			
			const sendMess = (hehe, teks) => {
				nayla.sendMessage(hehe, teks, text)
			}
			const createSerial = (size) => {
        	return crypto.randomBytes(size).toString('hex').slice(0, size)
            }            
            const addEliteUser = (userid, sender, time, serials) => {
	        const obj = { id: userid, name: sender, time: time, serial: serials }
	        _Elite.push(obj)
          	fs.writeFileSync('./nayla/Elite.json', JSON.stringify(_Elite))
            }	
            const checkEliteUser = (sender) => {
	        let status = false
	        Object.keys(_Elite).forEach((i) => {
		    if (_Elite[i].id === sender) {
			status = true
		    }
	        })
	        return status
            }       
            const bayarLimit = (sender, amount) => {
        	let position = false
            Object.keys(_limit).forEach((i) => {
            if (_limit[i].id === sender) {
            position = i
            }
            })
            if (position !== false) {
            _limit[position].limit -= amount
            fs.writeFileSync('./nayla/limit.json', JSON.stringify(_limit))
            }
            }
        	       
            const nayBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
            const bulan = nayBulan[moment().format('MM') - 1]
			const isElite = checkEliteUser(sender)
            const buruh1 = ['🐳','🦈','🐬','🐋','🐟','🐠','🦐','🦑','🦀','🐚']
            const buruh2 = ['🐔','🦃','🐿','🐐','🐏','🐖','🐑','🐎','🐺','🦩']
            const buruh3 = ['🦋','🕷','🐝','🐉','🦆','🦅','🕊','🐧','🐦','🦇']
            const slot1 = ['🍋','🍐','🍓','🍇','🍒']
            const slot2 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot3 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot4 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot5 = ['🍋','🍐','🍓','🍇','🍒']
            const slot6 = ['🍋','🍐','🍓','🍇','🍒'] 
            const slot7 = ['🍋','🍐','🍓','🍇','🍒']
            const slot8 = ['🍋','🍐','🍓','🍇','🍒']   
            const slot9 = ['🍋','🍐','🍓','🍇','🍒']
            const notc = ['😊','😃','😗','🙂','😶','😣','🙁','😞','😬']
            const oxo1 = ['X : X : O','O : X : O','X : O : O','O : X : X','O : X : O','X : O : O','X : X : O','X : X : X','O : O : O']
            const oxo2 = ['X : X : O','O : X : O','X : O : O','O : X : X','O : X : O','X : O : O','X : X : O','X : X : X','O : O : O']  
            const oxo3 = ['X : X : O','O : X : O','X : O : O','O : X : X','O : X : O','X : O : O','X : X : O','X : X : X','O : O : O']
            const nayla1 = ['1','2','3','4','5','6','7','8','9']
            const nayla2 = ['1','2','3','4','5','6','7','8','9'] 
            const oxo11 = oxo1[Math.floor(Math.random() * (oxo1.length))]
            const notc1 = notc[Math.floor(Math.random() * (notc.length))]
            const oxo22 = oxo2[Math.floor(Math.random() * (oxo2.length))]
            const oxo33 = oxo3[Math.floor(Math.random() * (oxo3.length))]
            const nayla3 = nayla1[Math.floor(Math.random() * (nayla1.length))]
            const nayla4 = nayla2[Math.floor(Math.random() * (nayla2.length))] 
            const buruh11 = buruh1[Math.floor(Math.random() * (buruh1.length))]
		    const buruh22 = buruh2[Math.floor(Math.random() * (buruh2.length))]
		    const buruh33 = buruh3[Math.floor(Math.random() * (buruh3.length))]
            const slot11 = slot1[Math.floor(Math.random() * (slot1.length))]
		    const slot22 = slot2[Math.floor(Math.random() * (slot2.length))]
		    const slot33 = slot3[Math.floor(Math.random() * (slot3.length))]
		    const slot44 = slot4[Math.floor(Math.random() * (slot4.length))]
			const slot55 = slot5[Math.floor(Math.random() * (slot5.length))]
			const slot66 = slot6[Math.floor(Math.random() * (slot6.length))]	
		    const slot77 = slot4[Math.floor(Math.random() * (slot7.length))]
		    const slot88 = slot5[Math.floor(Math.random() * (slot8.length))]
			const slot99 = slot6[Math.floor(Math.random() * (slot9.length))]	                       
            const kapan2 = ['Hari ini','Mungkin besok','1 Minggu lagi','Masih lama','3 Bulan lagi','7 Bulan lagi','3 Tahun lagi','4 Bulan lagi','2 Bulan lagi','1 Tahun lagi','1 Bulan lagi','Coba ulangi']
            const tomxic = ["ajg","asu","Ajg","Asu","anjg","Anjg","olol","antek","elaso","Babi","babi","ontol","kntl","kintil","emek","entod"]
			const apa = ['Ya','Mungkin','Tidak','Coba Ulangi','Bisa jadi','Kayaknya iya deh','Mustahil yhahahaha','coba tanya lort','tentu saja']
			var chat1 = `0@s.whatsapp.net`
		    var split = `Shirogane Kei BOT`
		    var chat2 =         {
			contextInfo:   {
			participant: chat1,
			quotedMessage: {
			extendedTextMessage: {
	    	text: split,
	     	}
     		}
	    	}
		 	}
   	        tchat = `Total : ${totalchat.length}`   	            	                   
            const vcard = 'BEGIN:VCARD\n' 
            + 'VERSION:3.0\n' 
            + `FN:${ownername}\n` 
            + `ORG: Pengembang bot;\n`
            + `TEL;type=CELL;type=VOICE;waid=${ownerrf}:${ownerrz}\n`
            + 'END:VCARD' /*
            ____________________________
                
            */
// MODIFICATION CASE!!! EXPERIMENTAL!!!
			 //REPLACE WHEN ERROR
            // AFK
            for (let x of mentionUser) {
                if (afk.hasOwnProperty(x.split('@')[0])) {
                    ini_txt = "Maaf user yang anda reply atau tag sedang afk. "
                    if (afk[x.split('@')[0]] != "") {
                        ini_txt += "Dengan alasan " + afk[x.split('@')[0]]
                    }
                    reply(ini_txt)
                }
            }
            if (afk.hasOwnProperty(sender.split('@')[0])) {
                reply("Senpai telah keluar dari mode afk.")
                delete afk[sender.split('@')[0]]
                fs.writeFileSync("./nayla/afk.json", JSON.stringify(afk))
            }

            // Tebak Gambar
            if (tebakgambar.hasOwnProperty(sender.split('@')[0]) && !isCmd && budy.match(/[1-9]{1}/)) {
                kuis = true
                jawaban = tebakgambar[sender.split('@')[0]]
                if (budy.toLowerCase() == jawaban) {
                    reply("Jawaban senpai Benar!")
                    delete tebakgambar[sender.split('@')[0]]
                    fs.writeFileSync("./nayla/tebakgambar.json", JSON.stringify(tebakgambar))
                } else {
                    reply("Jawaban senpai Salah!")
                }
            }

            // Sambung Kata
            if (sambungkata.hasOwnProperty(sender.split('@')[0]) && !isCmd) {
                kuis = true
                jawaban = sambungkata[sender.split('@')[0]]
                userAnswer = budy.toLowerCase()
                if (userAnswer.startsWith(jawaban[jawaban.length - 1])) {
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/sambungkata?apikey=${l0lhuman}&text=${userAnswer}`)
                    await nayla.sendMessage(from, get_result.result, text, { quoted: nay }).then(() => {
                        sambungkata[sender.split('@')[0]] = get_result.result.toLowerCase()
                        fs.writeFileSync("./nayla/sambungkata.json", JSON.stringify(sambungkata))
                    })
                } else {
                    reply("Silahkan jawab dengan kata yang dimulai huruf " + jawaban[jawaban.length - 1])
                }
            }
				
//ENDS HERE		   
			 
		   const vnayla = 'BEGIN:VCARD\n' 
            + 'VERSION:3.0\n' 
            + `FN: KEI BOTv7\n` 
            + `ORG: AUTHOR;\n`
            + `TEL;type=CELL;type=VOICE;waid=6281329585825:+62 813-2958-5825\n`
            + 'END:VCARD' 
            colors = ['red', 'pink', 'white', 'black', 'blue', 'yellow', 'green']
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')			 			  
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			const isQuotedText = type === 'extendedTextMessage' && content.includes('extendedTextMessage')
			if (!isGroup && isCmd) console.log('\x1b[1;31m=\x1b[1;37m>', '[\x1b[1;32m➻\x1b[1;37m]', color('NAMA', 'red'), color(pushname, 'yellow'), color('SEDANG', 'white'), color('MENGGUNAKAN', 'yellow'), color('FITUR', 'red'), color('➻', 'yellow'), color(command), 'DI :', color('PESAN PRIBADI', 'yellow')) 
			if (isCmd && isGroup) console.log('\x1b[1;31m=\x1b[1;37m>', '[\x1b[1;32m➻\x1b[1;37m]', color('NAMA', 'red'), color(pushname, 'yellow'), color('SEDANG', 'white'), color('MENGGUNAKAN', 'yellow'), color('FITUR', 'red'), color('➻', 'yellow'), color(command), 'DI :', color(groupName, 'yellow'))			 
            const xxx = '```'  
            const limitAdd = (sender) => {
            let position = false
            Object.keys(_limit).forEach((i) => {
            if (_limit[i].id == sender) {
            position = i
            }
            })
            if (position !== false) {
            _limit[position].limit += 1
            fs.writeFileSync('./nayla/limit.json', JSON.stringify(_limit))
            }
            }
            const checkLimit = (sender) => {
          	let found = false
            for (let lmt of _limit) {
            if (lmt.id === sender) {
            let limitCounts = limitawal - lmt.limit
            if (limitCounts <= 0) return itsmeiky.sendMessage(from,`Yahh maaf ya senpai, tapi limit senpai sudah habis :(`, text,{ quoted: nay})
            nayla.sendMessage(from, `Sisa Limit Kakak : *${limitCounts}* \n\n_Shirogane Kei Bot_`, text, { quoted : nay})
            found = true
            }
            }
            if (found === false) {
            let obj = { id: sender, limit: 0 }
            _limit.push(obj)
            fs.writeFileSync('./nayla/limit.json', JSON.stringify(_limit))
            nayla.sendMessage(from, `Sisa Limit Senpai : *${limitCounts}* \n\n_Shirogane Kei_`, text)
            }
         	}         	          
            const isLimit = (sender) =>{ 
	        let position = false
            for (let i of _limit) {
            if (i.id === sender) {
          	let limits = i.limit
            if (limits >= limitawal ) {
         	position = true
            nayla.sendMessage(from, `Maaf ya Senpai :( *${pushname}* Limit Senpai sudah habis. \nLimit bisa didapatkan kembali dengan cara level up atau mulung dengan cara ketik #claim *#claim* \n\n_Shirogane Kei_`, text, {quoted: nay})
            return true
            } else {
          	_limit
            position = true
            return false
            }
            }
            }
            if (position === false) {
           	const obj = { id: sender, limit: 0 }
            _limit.push(obj)
            fs.writeFileSync('./nayla/limit.json',JSON.stringify(_limit))
            return false
            }
            }    
            if (isGroup && isElite && isLevelingOn) {
            const currentLevel = getLevelingLevel(sender)
            const checkId = getLevelingId(sender)
            try {
            if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
            const amountXp = Math.floor(Math.random() * 10) + 500
            const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1)
            const getLevel = getLevelingLevel(sender)
            addLevelingXp(sender, amountXp)
            if (requiredXp <= getLevelingXp(sender)) {
            addLevelingLevel(sender, 1)
            bayarLimit(sender, 3)
            await reply(nyz.levelup(pushname, sender, getLevelingXp,  getLevel, getLevelingLevel))
            }
            } catch (err) {
            console.error(err)
            }
            }     
             
            switch (command) {
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ API FREEEEEE ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 
/*			        
			        
			        
			        MAU NYOLOMG CASE YA OM?? 
			        SETIDAKNYA ADD NAMA GW LAH
			        DI THX TO BOT KLEAN "NAYLA"
			        GK MAU?? OKE TERIMAKASIH			       			        
			        			       			        			       			        			       			        			        
			        
			        
*/ 



			        case 'join':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender) 
                    if (args.length < 1) return reply(`contoh ${prefix}join https://chat.whatsapp.com/CAPUjeauAafAskp3o5LDNj`)
                    const bug11 = body.slice(5)
                    if (bug11.length > 300) return nayla.sendMessage(from, 'Maaf kak Teks Terlalu Panjang, Maksimal 300 Teks', msgType.text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `*Shirogane Kei BOT v2*`} } }})
                    var nomor = nay.participant
                    const bug22 = `*[UNDANGAN JOIN]*\nDARI ${pushname} \nNomor : @${nomor.split("@s.whatsapp.net")[0]}\nPesan : ${bug11}`
                    var optionsp = {
                    text: bug22,
                    contextInfo: {mentionedJid: [nomor]},
                    }                     
                    nayla.sendMessage(`${setting.ownerNumber}@s.whatsapp.net`, optionsp, text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `PREINVITE`} } } })                    
                    reply('BOT AKAN SEGERA MASUK. DITUNGGU YA KAK')                     
					break  
					case 'claim':
						jds = []
					if (!isGroup) return reply(`GRUP ONLY`)
					if (!isBotx) return reply(`MODE LEVELING TIDAK AKTIF\nSILAHKAN KETIK ${prefix}leveling`)
					Limit =`_Yeayyy selamat ${pushname} Senpai berhasil mendapatkan Limit sebesar: *${nayla3}* \n\n_Shirogane Kei Bot_`
					mentions(Limit, jds, true)
					addLevelingLevel(sender, 1)
                    bayarLimit(sender, nayla3) 
                    break
                    case 'mygrub':
                    case 'mygrup':
						jds = []
                    my1 = `*GRUP LIST*\n`
                    my1 += `➻ *GRUB1* = ${grub1}\n`
                    my1 += `➻ *GRUB2* = ${grub2}\n`
                    my1 += `➻ *GRUB3* = ${grub3}\n`
                    mentions(my1, jds, true)
                    break
			        case 'infobot':
					case 'inf':
						jds = []
			        inf1 = `⟤ ${xxx}Nama Bot	: ${namebot}${xxx}\n`
			        inf1 += `⟤ ${xxx}Nama Owner	: ${ownername}${xxx}\n`
			        inf1 += `⟤ ${xxx}Author	    : Gue lah siapa lagi :v${xxx}\n`
			        inf1 += `⟤ ${xxx}Nomer Bot	: ${numberbot}${xxx}\n`
					inf1 += ` \n`
					inf1 += ` ${xxx}- Total API's -${xxx}\n`
					inf1 += `⟤ ${xxx}API VHTear : -${xxx}\n`
					inf1 += `⟤ ${xxx}API Keyz : -${xxx}\n`
					inf1 += `⟤ ${xxx}API Zeks : -${xxx}\n`
					inf1 += `⟤ ${xxx}API Xteam : fca6a0fffb5a6***${xxx}\n`
					inf1 += `⟤ ${xxx}API LoL Human : 161d279ead36ffb72189b***${xxx}\n`
					inf1 += ` \n`
					inf1 += `${xxx}⚙️ Info Engine BOT ⚙️${xxx}\n`
					inf1 += `⟤ ${xxx}BOT Version  : Lihat detail di #aboutbot${xxx}\n`
					inf1 += `  ${xxx}*Last updated on : Lihat detail di #aboutbot${xxx}\n`
					inf1 += `⟤ ${xxx}BOT Platform	: Termux${xxx}\n`
					inf1 += `⟤ ${xxx}Node.js		: v13.00${xxx}\n`
					inf1 += `⟤ ${xxx}Device		: Lenovo A2010${xxx}\n`
					inf1 += `⟤ ${xxx}OS			: Android v5.1 lolipop 🍭${xxx}\n`
					inf1 += `⟤ ${xxx}Build Number	: A2010-a-t _S264_ _1701100300_ _MP3V1_8G_ ROW${xxx}\n`
					inf1 += `⟤ ${xxx}Chipset	: Mediatek MT6735M (28 nm)${xxx}\n`
					inf1 += `⟤ ${xxx}CPU		: Quad-core 1.0 GHz Cortex-A53${xxx}\n`
					inf1 += `⟤ ${xxx}RAM/ROM	: 1GB / 8GB${xxx}\n`
					inf1 += `${xxx}*Reset cache schedule : every MON 04.00 AM -GMT-${xxx}\n`
			        mentions(inf1, jds, true)
			        break
	//ganti ini setiap perbaharuan script!				
					case 'aboutbot':
						jds = []
						abt = `${xxx}For Your Information${xxx}\n`	
						abt +=`\n`
						abt +=`${xxx}ChangeLog Bot${xxx}\n`
						abt +=`${xxx}Version : 5.2 ~ 13 sep 2021${xxx}\n`
						abt +=`${xxx}1. Applied catch error functions when request is not already sended${xxx}\n`
						abt +=`${xxx}2. Applied await buffer functions due to overwhelming Get-features request${xxx}\n`
						abt +=`${xxx}3. Fixed many minor bugs${xxx}\n`
						abt +=`${xxx}4. Limit awal set to 20, exp gain still same${xxx}\n`
						abt +=`${xxx}5. All features already set to free, exceptions for #nhentai-pdf only for premium users!${xxx}\n`
						abt +=`${xxx}6. Menu yang aktif hanya di #menu, will be revamped soon${xxx}\n`
						abt +=`${xxx}7. Simplifications, All menu's except #menu, #ownermenu, #grupmenu, #nsfwmenu, #halalmenu, #harammenu, #gunamenu, #mfuntextmenu, #tagmenu, #cekmenu has been deleted!${xxx}\n`
						abt +=`${xxx}8. New menus's & features available! check it on #menu${xxx}\n`
						abt +=`${xxx}9. Many various update change!${xxx}\n`
						abt +=`\n`
						abt +=`${xxx}Version : 5.1 ~ 7 sep 2021\n${xxx}`
						abt +=`${xxx}1. Fixed cannot send message due to bot error${xxx}\n`
						abt +=`${xxx}2. Fixed cannot use Get-features${xxx}\n`
						abt +=`${xxx}3. Fixed reply reactions due to spamming${xxx}\n`
						abt +=`\n`
						abt +=`${xxx}Version : 5.0 ~ 5 sep 2021${xxx}\n`
						abt +=`${xxx}1. Checking Menu's or only used menu's(not features)/Not using any features(includes get features) will no longer consume Limit!${xxx}n`
						abt +=`${xxx}2. Await reply, soon will be added to other get-features, so you will get report back from bot reply due to some erros in case when you used Bot get-features!${xxx}\n`
						abt +=`${xxx}3. Fixed #cekmenu result from bot, when where you using this features you're not mentioned by Bot, due to ambiguity when many people using this feature simultaneously${xxx}\n`
						abt +=`${xxx}4. Limit awal di set menjadi 25(new user), exp gain +20% , The higher level the more exp yould need to lvl up!${xxx}\n`
						abt +=`${xxx}5. Database seperti Level, Limit, Premium User(perorangan/pernomor WA) Tidak akan direset setiap Update Bot, jadi gaperlu lagi #daftar bagi yg pernah daftar, hanya utk new user!${xxx}\n`
						abt +=`${xxx}6. Added new features on Grup Menu!${xxx}\n`
						abt +=`${xxx}7. Added mentions reply on Cek Menu!${xxx}\n`
						abt +=`${xxx}8. Revamped #nsfwmenu${xxx}\n`
						abt +=`${xxx}9. Added #halalmenu, #harammenu, #gunamenu, #mfuntextmenu with many various features included in substitude menu's${xxx}\n`
						abt +=`${xxx}10. ! Fitur stker masih belum bisa digunakan !, pusing gw cokk...simple but still cannot solve the problem :(${xxx}\n`
						abt +=`\n`
						abt +=`${xxx}API Premium Aktif:${xxx}\n`
						abt +=`${xxx}LoLhuman Premium aktif s/d 28 Sep 2021${xxx}\n`
						abt +=`\n`						
						abt +=`${xxx}Bot Script Js${xxx}\n`
						abt +=`${xxx}Script Bot terakhir diperbaharui pada tanggal:${xxx}\n`
						abt +=`${xxx}Minggu 05 - September - 2021${xxx}\n`
						abt +=`\n`
						abt +=`${xxx}Bot ini masih dalam tahap pengembangan, jika terdapat bug/fitur yang tidak work mohon dimengerti :)${xxx}\n`
						abt +=`${xxx}Lapor bug ketik #bug${xxx}\n`
						abt +=`\n`						
						abt +=`${xxx}ArigaThanks, Best Regards!${xxx}\n`
						abt +=`${xxx}Powered By: Shirogane Kei Bot${xxx}\n`
					mentions(abt, jds, true)
					break					
					case 'daftar':
					case 'reg' :
					const serialUser = createSerial(20)
					veri = sender
					if (isGroup) {
					addEliteUser(sender, pushname, time, serialUser)
					try {					 
					} catch {						 
					}
				   	reply(nyz.elitenay(pushname, prefix))
					console.log(color(`Nama : ${pushname} Sukses terdaftar!`, 'pink'))
					} else {
					addEliteUser(sender, pushname, time, serialUser)
					try {						 
					} catch {						  
			    	}
			     	reply(nyz.elitenay(pushname, prefix))
		         	console.log(color(`Nama : ${pushname} Sukses terdaftar!`, 'pink'))
				    }
				    break
				//0						       	 			            			           
			    	case 'menu':
					case 'm':
			    	if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
                    runtime = process.uptime()                              
                    reply(nyz.menuZ(ownername, auth0r, bulan, tchat, tz, prefix))                                    
                    break
				//1
					case 'nsfwmenu':           
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))           
                    reply(nyz.nsfwMenu(tz, prefix))                                                   
                    break
				//2	
					case 'halalmenu':           
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))           
                    reply(nyz.halalMenu(tz, prefix))                                                   
                    break
				//3	
					case 'harammenu':           
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))           
                    reply(nyz.haramMenu(tz, prefix))                                                   
                    break
                //4    
					case 'gunamenu':                      
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
                    reply(nyz.gunaMenu(prefix, tz))                                                   
                    break
				//5	
					case 'mediamenu':           
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))           
                    reply(nyz.mediaMenu(tz, prefix))                                                   
                    break 					
				//6	
					case 'makermenu':           
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))           
                    reply(nyz.newmakerMenu(tz, prefix))                                                   
                    break 
				//7	
					case 'funtextmenu':           
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))           
                    reply(nyz.newmakerMenu2(tz, prefix))                                                   
                    break


			//has already own property		    
                    case 'tagmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                
                    reply(nyz.tagmenu(prefix, ownername, tz))  
                    break
                    case 'cekmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                   
                    reply(nyz.cekmenu(prefix, ownername, tz))  
                    break
                    case 'internalmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                  
                    reply(nyz.internalmenu(prefix, ownername, tz))  
                    break 
                    case 'grupmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                              
                    reply(nyz.grupmenu(prefix, ownername, tz)) 
                    break  
                    case 'ownermenu':       
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))               
                    reply(nyz.ownermenu(prefix, ownername, tz))                                   
                    break



			//deprecated
                /*    case 'spesialmenu':        
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))              
                    reply(nyz.spesialmenu(prefix, ownername, tz)) 
                    break                    
                    case 'sertifikat':            
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))          
                    reply(nyz.sertifikat(prefix, ownername, tz))  
                    break   
                    case 'stickmenu':         
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))             
                    reply(nyz.stickmenu(prefix, ownername, tz)) 
                    break
                    case 'allmenu':                      
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
                    reply(nyz.allmenu(ownername, auth0r, bulan, tchat, tz, prefix))                                                   
                    break                    
                    case 'makerfoto':   
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                   
                    reply(nyz.makerfoto(prefix, ownername, tz)) 
                    break                 					                                           
                    case 'randomtext':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
                    reply(nyz.randomtext(prefix, ownername, tz))   
                    break                                  
                    case 'gamemenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix)) 
                    reply(nyz.gamemenu(prefix, ownername, tz))   
                    break 
                    case 'newsmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                   
                    reply(nyz.newsmenu(prefix, ownername, tz))  
                    break
                    case 'pornmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                  
                    reply(nyz.pornmenu(prefix, ownername, tz))   
                    break
                    case 'soundmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                  
                    reply(nyz.soundmenu(prefix, ownername, tz))   
                    break
                    case 'downloadmenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                  
                    reply(nyz.downloadmenu(prefix, ownername, tz)) 
                    break
                    case 'promenu':                      
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                                                      	
                    reply(nyz.promenu(prefix, ownername, tz))   
                    break
				*/	    
			//ends here

                    case 'donasi':  
					jds = []
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))                     	
                    donasi1 = `[ *${donasi}* ]\n`
                    donasi1 += `➻ *PULSA* : ${pulsa}\n`
                    donasi1 += `➻ *GOPAY* : ${gopay}\n`
                    donasi1 += `➻ *OVO* : ${ovo}\n`
                    donasi1 += `➻ *DANA* : ${dana}\n`
                    mentions(donasi1, jds, true)
                    break

					case 'afk':
						alasan = args.join(" ")
						afk[sender.split('@')[0]] = alasan.toLowerCase()
						fs.writeFileSync("./nayla/afk.json", JSON.stringify(afk))
						ini_txt = "Senpai telah afk. "
						if (alasan != "") {
							ini_txt += "Dengan alasan " + alasan
						}
						reply(ini_txt)
						break	
		//make new session
					case 'sambungkata':
						if (sambungkata.hasOwnProperty(sender.split('@')[0])) return reply("Selesein yg sebelumnya dulu atuh senpai")
						if (args.length == 0) return reply(`Example: ${prefix + command} tahu`)
						ini_txt = args.join(" ")
						get_result = await fetchJson(`https://api.lolhuman.xyz/api/sambungkata?apikey=${l0lhuman}&text=${ini_txt}`)
						get_result = get_result.result
						await nayla.sendMessage(from, get_result, text, { quoted: nay }).then(() => {
							sambungkata[sender.split('@')[0]] = get_result.toLowerCase()
							fs.writeFileSync("./nayla/sambungkata.json", JSON.stringify(sambungkata))
						})
						break
					case 'cancelsambungkata':
						if (!sambungkata.hasOwnProperty(sender.split('@')[0])) return reply("Senpai tidak memiliki tebak gambar sebelumnya")
						delete sambungkata[sender.split('@')[0]]
						fs.writeFileSync("./nayla/sambungkata.json", JSON.stringify(sambungkata))
						reply("Success mengcancel sambung kata sebelumnya")
						break
					case 'tebakgambar': // case by piyo-chan
						if (tebakgambar.hasOwnProperty(sender.split('@')[0])) return reply("Selesein yg sebelumnya dulu atuh senpai")
						get_result = await fetchJson(`https://api.lolhuman.xyz/api/tebak/gambar?apikey=${l0lhuman}`)
						get_result = get_result.result
						ini_image = get_result.image
						jawaban = get_result.answer
						ini_buffer = await getBuffer(ini_image)
						await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: "Jawab gk? Jawab lahhh, masa enggak. 30 detik cukup kan? gk cukup pulang aja" }).then(() => {
							tebakgambar[sender.split('@')[0]] = jawaban.toLowerCase()
							fs.writeFileSync("./nayla/tebakgambar.json", JSON.stringify(tebakgambar))
						})
						await sleep(30000)
						if (tebakgambar.hasOwnProperty(sender.split('@')[0])) {
							reply("Jawaban: " + jawaban)
							delete tebakgambar[sender.split('@')[0]]
							fs.writeFileSync("./nayla/tebakgambar.json", JSON.stringify(tebakgambar))
						}
						break
					case 'canceltebakgambar':
						if (!tebakgambar.hasOwnProperty(sender.split('@')[0])) return reply("Senpai tidak memiliki tebak gambar sebelumnya")
						delete tebakgambar[sender.split('@')[0]]
						fs.writeFileSync("./nayla/tebakgambar.json", JSON.stringify(tebakgambar))
						reply("Success mengcancel tebak gambar sebelumnya")
						break								
                         
/* ======================================================[ SPAM-API ]==============================================================*/    
/*=====================================================[ RANDOM CEK ]==============================================================*/                  	                        	 
                    case 'rate':  
							jds = []
                   		if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       		if (isLimit(sender)) return
			       			await limitAdd(sender)
				   		if (args.length < 1) return reply(`Nih senpai aku contohin..\n #rate gw dpt Raiden Shogun`)
				   				const anu = body.slice(1)				    
				   				const jawabdonk = `*${anu}* adalah : *${nayla3}${nayla4}%* 😎`
				   			mentions(jawabdonk, jds, true)
				   	break
					   /*case 'persengay':  
							jds = []
                   		if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       		if (isLimit(sender)) return
			       			await limitAdd(sender)
				   		if (args.length < 1) return reply(`Nih senpai aku contohin..\n #rate senpai gay`)
				   				const anu = body.slice(1)				    
				   				const anu1 = `${nayla3}${nayla4}`
								   if (anu1 < 10)
								   		hasil = `Rate Gay senpai sebesar: ${anu1}\nBuset sloerr, the real holly man... Suci dari yang namanya Gay`
											mentions(hasil, jds, true)
								   if (anu1 < 20)
								   		hasil = `Rate Gay senpai sebesar: ${anu1}\nWah ini mah masih dibilang aman sloerr`
											mentions(hasil, jds, true)
								   if (anu1 > 20)
								   		hasil = `Rate Gay senpai sebesar: ${anu1}\nHmmm... ini masih dalam tahap pembelajaran menuju Gay`
										   	mentions(hasil, jds, true)
								   if (anu1 > 50)
								   		hasil = `Rate Gay senpai sebesar: ${anu1}\nNah, ini nih antara mau ngelanjut hobi ngegay nya ato mau insaf, tapi biasanya mah alnjut ngegay kali ye`
										   	mentions(hasil, jds, true)
								   if (anu1 > 70)
								   		hasil = `Rate Gay senpai sebesar: ${anu1}\nWadooo, mulai dah gabisa dikontrol ini mah + fetishnya pasti udah aneh"....dah sukanya gey fetish aneh pulak... ishhhh`
										   	mentions(hasil, jds, true)
								   if (anu1 > 90)
								   		hasil = `Rate Gay senpai sebesar: ${anu1}\nWUAJERRRR PARAH BENER, KUDU HATI-HATI SLOERR, INI MAH JANGANKAN BOOL KELEN, KENALPOT MOTOR AJA DIMASUKIN`										   								   					 
				   							mentions(hasil, jds, true)
				   	break*/
					case 'badutcek':                      	  
                    	if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        	if (isLimit(sender)) return
							jds = []
			        		await limitAdd(sender)
                    			N = `Ke badut'an senpai\n`
                    			N += `Adalah : *${nayla3}${nayla4}%* 😎`
                    		mentions(N, jds, true)
					break
					case 'sepuhcek':                      	  
                    	if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        	if (isLimit(sender)) return
						jds = []
			        	await limitAdd(sender)
                    			N = `Ke sepuh'an senpai\n`
                    			N += `Adalah : *${nayla3}${nayla4}%* 😎`
                    		mentions(N, jds, true)
					break
                    case 'hokicek':                      	  
                    	if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        	if (isLimit(sender)) return
						jds = []
			        		await limitAdd(sender)
                    			N = `Ke hoki'an senpai\n`
                    			N += `Adalah : *${nayla3}${nayla4}%* 😎`
                    		mentions(N, jds, true)
					break					
					case 'ampascek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `Ke ampas'an senpai\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😎`
                    mentions(N, jds, true)
					break
					case 'pedocek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `Ke pedo'an senpai\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😎`
                    mentions(N, jds, true)
					break
					case 'silitcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `Ke silit'an senpai\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😎`
                    mentions(N, jds, true)
					break
					case 'gantengcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `Ke ganteng'an senpai\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😎`
                    reply(N)
                    break 
					case 'gaycek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `Jiwa gay senpai yaitu...\n`
                    N += `Sebesar : *${nayla3}${nayla4}%* 😎`
                    mentions(N, jds, true)
                    break 
					case 'hodecek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `KE *HODE'AN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😎`
					mentions(N, jds, true)
                    break 
                    case 'cantikcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `KE *CANTIKAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}% 😁*`
                    mentions(N, jds, true)
                    break
                    case 'jelekcek':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)                      	
                    N = `KE *J3L3K4N* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 🤢`
                    mentions(N, jds, true)
                    break 
                    case 'goblokcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `KE *GOBLOKAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 🤣`
                    mentions(N, jds, true)
                    break 
                    case 'begocek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `KE *BEGO* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😂`
                    mentions(N, jds, true)
                    break 
                    case 'pintercek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *PINTARAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😗`
                    mentions(N, jds, true)
                    break 
                    case 'jagocek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *JAGOAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 💪`
                    mentions(N, jds, true)
                    break 
                    case 'nolepcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *NOLEPAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 🧐`
                    mentions(N, jds, true)
                    break 
                    case 'babicek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *BABIAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 🤪`
                    mentions(N, jds, true)
                    break 
                    case 'bebancek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `KE *BEBANAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 🤬`
                    mentions(N, jds, true)
                    break 
                    case 'baikcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *BAIKAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😇`
                    mentions(N, jds, true)
                    break 
                    case 'jahatcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *JAHATAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😈`
                    mentions(N, jds, true)
                    break 
                    case 'anjingcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *ANJINGAN* KAMU\n`
                    N += `ADALAH : *${nayla3}${nayla4}%* 👀`
                    mentions(N, jds, true)
                    break                      
                    case 'haramcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `KE *HARAMAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 🥴`
                    mentions(N, jds, true)
                    break  
                    case 'kontolcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *KOMTOLAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 🙂`
                    mentions(N, jds, true)
                    break 
                    case 'pakboycek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender) 
                    N = `KE *PAKBOYZ* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😏`
                    mentions(N, jds, true)
                    break 
                    case 'pakgirlcek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)	
                    N = `KE *PAKGILR* KAMU\n`
                    N += `ADALAH : *${nayla3}${nayla4}%* 😏`
                    mentions(N, jds, true)
                    break             
                    case 'sangecek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `Jiwa sange senpai yaitu...\n`
                    N += `Sebesar : *${nayla3}${nayla4}%* 🤤`
                    mentions(N, jds, true)
                    break
                    case 'bapercek':                      	  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
					jds = []
			        await limitAdd(sender)
                    N = `JIWA *BEPERAN* KAMU\n`
                    N += `Adalah : *${nayla3}${nayla4}%* 😘`
                    mentions(N, jds, true)
                    break                                                                                                                                                                                                                                                                                                                                                                                                                                  
                                                                     

                   case 'darkjokes':  
                   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
			       await limitAdd(sender)	
                   reply(naylachan)
                   anu = await fetchJson(`https://api.zeks.xyz/api/darkjokes?apikey=apivinz`)
                   anu1 = await getBuffer(anu.result)
                   nayla.sendMessage(from, anu1, image, {caption: `nihh kack`, quoted: nay1})
                   break

/* ==================================================[ TERRRRRR-MENU ]==============================================================*/    
/*====================================================[ API?? NOT API ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	                                          
                  
                   case 'ganteng': case 'cantik': case 'jelek': case 'goblok': case 'gay' : case 'badut': case 'pedo': case 'ampazz':
                   case 'bego': case 'pinter': case 'jago': case 'nolep': case 'monyet':                 	 
                   case 'babi': case 'beban': case 'baik': case 'jahat': case 'anjing': 
                   case 'haram': case 'kontol': case 'pakboy': case 'pakgirl': 
               	   case 'wibu': case 'hebat': case 'sadboy': case 'sadgirl': case 'sepuh':  
               	   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
			       await limitAdd(sender)
				   if (!isGroup) return reply(`GROUP ONLY`)
 				   jds = []
				   const A1 = groupMembers
  		 		   const B1 = groupMembers
 				   const C1 = A1[Math.floor(Math.random() * A1.length)]
				   D1 = `yang *ter${command}* disini adalah @${C1.jid.split('@')[0]}`                  
				   jds.push(C1.jid)
				   mentions(D1, jds, true)
				   break 
				   case 'ngegay': 
               	   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
			       await limitAdd(sender)
				   if (!isGroup) return reply(`GROUP ONLY`)
 				   jds = []
				   const A2 = groupMembers
  		 		   const B2 = groupMembers
 				   const C2 = A2[Math.floor(Math.random() * A2.length)]
				   D2 = `Yang *Sedang ${command}* disini adalah @${C2.jid.split('@')[0]} yhahaha sangad berbahaya sloerrr kudu hati"🤣`                  
				   jds.push(C2.jid)
				   mentions(D2, jds, true)
				   break
				   case 'comly': 
               	   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
			       await limitAdd(sender)
				   if (!isGroup) return reply(`GROUP ONLY`)
 				   jds = []
				   const A3 = groupMembers
  		 		   const B3 = groupMembers
 				   const C3 = A3[Math.floor(Math.random() * A3.length)]
				   D3 = `Yang *Sedang ${command}* disini adalah @${C3.jid.split('@')[0]} yhahaha kocok teross tuh batang 🤣`                  
				   jds.push(C3.jid)
				   mentions(D3, jds, true)
				   break
				   case 'nyilit': 
               	   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
			       await limitAdd(sender)
				   if (!isGroup) return reply(`GROUP ONLY`)
 				   jds = []
				   const A4 = groupMembers
  		 		   const B4 = groupMembers
 				   const C4 = A1[Math.floor(Math.random() * A4.length)]
				   D4 = `Yang *Sedang ${command}* disini adalah @${C4.jid.split('@')[0]} astaga, ga pengen lobang yang lain bre? (>,,<)`                  
				   jds.push(C4.jid)
				   mentions(D4, jds, true)
				   break 
				   case 'jadian':
				   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
			       await limitAdd(sender)
				   if (!isGroup) return reply(`GROUP ONLY`)
 				   jds = []
				   const A11 = groupMembers
  		 		   const B11 = groupMembers
 				   const C11 = A11[Math.floor(Math.random() * A11.length)] 				   
 				   const C22 = B11[Math.floor(Math.random() * B11.length)]
				   D11 = `Cieee @${C11.jid.split('@')[0]} ❤ @${C22.jid.split('@')[0]}\n Kyaaaa! selamat ya senpaitachi 🤭, Kei selalu mendukungmu!!🥰`                  
				   jds.push(C11.jid)
				   jds.push(C22.jid)
				   mentions(D11, jds, true)
				   break				
				   case 'kapankah':  
                   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
				   if (args.length < 1) return reply(`Senpai dongo ya?, textnya mana tol konn... eh maap nich toxic tehe`)
			       await limitAdd(sender)				   
				   const kapan1 = body.slice(1)					 
				   const kpnkh = kapan2[Math.floor(Math.random() * (kapan2.length))]
				   const jawab1 = `Pertanyaan : *${kapan1}*\n\nJawaban: ${kpnkh}`
      			   nayla.sendMessage(from, jawab1, text, {quoted: nay})
				   break
		           case 'apakah':  
                   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
				   if (args.length < 1) return reply(`Senpai dongo ya?, textnya mana tol konn... eh maap nich toxic tehe`)
			       await limitAdd(sender)
				   const tanya = body.slice(1)				    
				   const apkh = apa[Math.floor(Math.random() * (apa.length))]
				   const jawab = `Pertanyaan : *${tanya}*\n\nJawaban: ${apkh}`
				   nayla.sendMessage(from, jawab, text, {quoted: nay})
				   break
				   case 'slot':  
                   if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			       if (isLimit(sender)) return
			       await limitAdd(sender)    				    				    
				   slot = `===================\n` 
				   slot += `║ ${slot11} ║ ${slot22} ║ ${slot33}\n`
				   slot += `║ ${slot44} ║ ${slot55} ║ ${slot66} <====\n`
				   slot += `║ ${slot77} ║ ${slot88} ║ ${slot99}	\n`				   
				   slot += `===================\n`
				   nayla.sendMessage(from, slot, text, {quoted: nay})
				   break				  
                                                                                                                                                                                                                                                                                                                              				                                                                                                                                                                              
/* ==================================================[ TAMBAHAN-MENU ]==============================================================*/    
/*====================================================[ API?? NOT API ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	                                          
                           
                    case 'toimg':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender) 
					reply(naylachan)
					encmedia = JSON.parse(JSON.stringify(nay).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await nayla.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
					fs.unlinkSync(media) 
					buffer = fs.readFileSync(ran)
			        nayla.sendMessage(from, buffer, image, {quoted: nay, caption: 'nihh kak....jgn lupa bilang makasih peko'})
				    fs.unlinkSync(ran)
					})					
			    	break 
                    case 'readmore':  
			    	case 'more':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
			    	const more = String.fromCharCode(8206)
			    	const readmore = more.repeat(4001)
				    if (!q.includes('|')) return  reply(`GUNAKAN | UNTUK PEMBATAS`)
                    const text1 = q.substring(0, q.indexOf('|') - 0)
                    const text2 = q.substring(q.lastIndexOf('|') + 1)
                    reply( text1 + readmore + text2)
                    break
                    case 'chatlist':  
		         	case 'cekchat':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
		  	    	nayla.updatePresence(from, Presence.composing)
			    	var itsme = `0@s.whatsapp.net`
			    	var split = `Shirogane Kei BOT`
		     		var selepbot =         {
					contextInfo:   {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
	     			}
     				}
	    			}
			      	}
			     	teks = `Total : ${totalchat.length}`
			    	nayla.sendMessage(from, teks, MessageType.text, selepbot)
		    		break
	                case 'addsticker':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)          
			    	if (!isQuotedSticker) return reply('Reply stiker nya kak')
			     	svst = body.slice(12)
			    	if (!svst) return reply('Nama sticker nya apa?')
			    	boij = JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
			     	delb = await nayla.downloadMediaMessage(boij)
			       	setiker.push(`${svst}`)
			    	fs.writeFileSync(`./src/sticker/${svst}.webp`, delb)
			     	fs.writeFileSync('./src/stik.json', JSON.stringify(setiker))
			    	nayla.sendMessage(from, `Sukses Menambahkan Sticker kedalam database\nSilahkan Cek dengan cara ${prefix}liststicker`, MessageType.text, { quoted: nay1})
      				break
		        	case 'addvn':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
			    	if (!isQuotedAudio) return reply('Reply vnnya kak!')
			    	svst = body.slice(7)
		    		if (!svst) return reply('Nama audionya apa kak?')
			    	boij = JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
			    	delb = await nayla.downloadMediaMessage(boij)
			    	audionye.push(`${svst}`)
			     	fs.writeFileSync(`./src/audio/${svst}.mp3`, delb)
			     	fs.writeFileSync('./src/audio.json', JSON.stringify(audionye))
			     	nayla.sendMessage(from, `Sukses Menambahkan Vn ke dalam database\nSilahkann Cek dengan cara ${prefix}listvn`, MessageType.text, { quoted: nay1}) 
			      	break
		         	case 'getvn':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
			        if (args.length < 1) return reply('Masukan nama yang terdaftar di list vn')
			     	namastc = body.slice(7)
				    buffer = fs.readFileSync(`./src/audio/${namastc}.mp3`)
			    	nayla.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4',  quoted: nay1})
			     	break
			        case 'getsticker':  
		        	case 'gets':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
		        	if (args.length < 1) return reply('Masukan nama yang terdaftar di list sticker')
		      		namastc = body.slice(12)
			     	result = fs.readFileSync(`./src/sticker/${namastc}.webp`)
			    	nayla.sendMessage(from, result, sticker)
			     	break
                    case 'liststicker':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
		     		teks = '*Sticker List :*\n\n'
	    			for (let awokwkwk of setiker) {
			 		teks += `- ${awokwkwk}\n`
    				}
		      		teks += `\n*Total : ${setiker.length}*`
		      		nayla.sendMessage(from, teks.trim(), extendedText, {  quoted: nay1})
		      		break
		        	case 'listvn':  
	         		case 'vnlist':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
		     		teks = '*List Vn:*\n\n'
		     		for (let awokwkwk of audionye) {
					teks += `- ${awokwkwk}\n`
			      	}
			    	teks += `\n*Total : ${audionye.length}*`
		    		nayla.sendMessage(from, teks.trim(), extendedText, {  quoted: nay1})
		    		break
		        	case 'addimage':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
		     		if (!isQuotedImage) return reply('Reply imagenya kaj!')
			    	svst = body.slice(10)
			    	if (!svst) return reply('Nama imagenya apa kak?')
		     		boij = JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
	 	     		delb = await nayla.downloadMediaMessage(boij)
		     		imagenye.push(`${svst}`)
			    	fs.writeFileSync(`./src/image/${svst}.jpeg`, delb)
			    	fs.writeFileSync('./src/image.json', JSON.stringify(imagenye))
		      		nayla.sendMessage(from, `Sukses Menambahkan image ke dalam database\nSilahkan cek dengan cara ${prefix}listimage`, MessageType.text, { quoted: nay1})		     	 
		     		break
		        	case 'getimage':  
                    case 'getimg':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
			        if (args.length < 1) return reply('Masukan nama yang terdaftar di list image')
	      			namastc = body.slice(10)
	      			buffer = fs.readFileSync(`./src/image/${namastc}.jpeg`)
    				nayla.sendMessage(from, buffer, image, {  quoted: nay1})
	      			break
		        	case 'imagelist':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
		    		teks = '*List Image :*\n\n'
		    		for (let awokwkwk of imagenye) {
					teks += `- ${awokwkwk}\n`
			      	}
			    	teks += `\n*Total : ${imagenye.length}*`
			    	nayla.sendMessage(from, teks.trim(), extendedText, {  quoted: nay1})
			    	break
		        	case 'addvideo':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
			    	if (!isQuotedVideo) return reply('Reply videonya kak!')
			    	svst = body.slice(10)
			     	if (!svst) return reply('Nama videonya apa kak?')
			     	boij = JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
			    	delb = await nayla.downloadMediaMessage(boij)
			    	videonye.push(`${svst}`)
			    	fs.writeFileSync(`./src/video/${svst}.mp4`, delb)
			     	fs.writeFileSync('./src/video.json', JSON.stringify(videonye))
			      	nayla.sendMessage(from, `Sukses Menambahkan Video\nCek dengan cara ${prefix}listvideo`, MessageType.text, { quoted: nay1}) 
	     			break
			        case 'getvideo':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
		    	    if (args.length < 1) return reply('Masukan nama yang terdaftar di list video')
			    	namastc = body.slice(10)
			    	buffer = fs.readFileSync(`./src/video/${namastc}.mp4`)
			    	nayla.sendMessage(from, buffer, video, { mimetype: 'video/mp4', quoted: nay1})
			       	break
		           	case 'listvideo':  
	           		case 'videolist':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
	    			teks = '*List Video :*\n\n'
	    			for (let awokwkwk of videonye) {
					teks += `- ${awokwkwk}\n`
		    		}
			    	teks += `\n*Total : ${videonye.length}*`
			    	nayla.sendMessage(from, teks.trim(), extendedText, {  quoted: nay1})
			      	break				                         
                    case 'setprefix':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    if (args.length < 1) return
			        if (!isOwner) return reply(`Owner bot only!`)
                    prefix = args[0]
                    reply(`Change Prefix To ${prefix} SUCCESS!`)					 
					break 
					case 'setreply':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    if (args.length < 1) return
			        if (!isOwner) return reply(`Owner bot only!`)
                    naylachan = body.slice(10)
                    reply(`Change reply To ${naylachan} SUCCESS!`)					 
					break 
					case 'setpp':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isOwner) return reply(`Owner bot only!`) 
	    	        boij = JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
			        delb = await nayla.downloadMediaMessage(boij)
			        fs.writeFileSync('./menu/undef2.png', delb)
		            reply('Sukses')
			        break 
			        case 'setthum':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isOwner) return reply(`Owner bot only!`) 
	    	        boij = JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
			        delb = await nayla.downloadMediaMessage(boij)
			        fs.writeFileSync('./menu/undef1.png', delb)
		            reply('Sukses')
			        break 
					case 'setwelcome':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    if (args.length < 1) return
			        if (!isOwner) return reply(`lu owner?`)
                    welcome1 = body.slice(12)
                    reply(`Change welcome To ${welcome1} SUCCESS!`)					 
					break
					case 'setout':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    if (args.length < 1) return
			        if (!isOwner) return reply(`Owner bot only!`)
                    welcome2 = body.slice(8)
                    reply(`Change out To ${welcome2} SUCCESS!`)					 
					break  
					case 'settz':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    if (args.length < 1) return
			        if (!isOwner) return reply(`lu owner?`)
                    tz = args[0]
                    reply(`Change tz To ${tz} SUCCESS!`)					 
					break 					 
                    case 'admin':  
         	        case 'owner':  
         	        case 'creator':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    nayla.sendMessage(from, {displayname: "Jeff", vcard: vcard}, MessageType.contact, { quoted: nay1})
                    nayla.sendMessage(from, 'Itu kak, tolong jaga jaga norma, etika dan kesopanan dalam komunikasi ya kak :)',MessageType.text, { quoted: nay} )				
					break  
					case 'other':  
         	        case 'author':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return 
			        await limitAdd(sender)         	       
                    nayla.sendMessage(from, {displayname: "Jeff", vcard: vnayla}, MessageType.contact, { quoted: nay1})
                    nayla.sendMessage(from, 'Itu kak, tolong jaga jaga norma, etika dan kesopanan dalam komunikasi ya kak :)',MessageType.text, { quoted: nay} )				
					break    
					case 'sticker':
					case 's':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return reply('Sedang di proses!, mohon tunggu sebentar ya senpai... jika terlalu lama mungkin terjadi error :(')
						await limitAdd(sender)	
						if ((isMedia && nay.message.videoMessage || isQuotedImage) && args.length == 0) {
							const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : nay
							filePath = await nayla.downloadAndSaveMediaMessage(encmedia)
							file_name = getRandom('.webp')
							request({
								url: `https://api.lolhuman.xyz/api/convert/towebp?apikey=${l0lhuman}`,
								method: 'POST',
								formData: {
									"img": fs.createReadStream(filePath)
								},
								encoding: "binary"
							}, function(error, response, body) {
								fs.unlinkSync(filePath)
								fs.writeFileSync(file_name, body, "binary")
								ini_buff = fs.readFileSync(file_name)
								nayla.sendMessage(from, ini_buff, sticker).then(() => {
									fs.unlinkSync(file_name)
								})
							});
						} else {
							reply(`Kirim gambar dengan caption ${prefix}sticker atau tag gambar yang sudah dikirim`)
						}
						break
						case '#sticker2':
							case '#stiker2':
								if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
								if (isLimit(sender)) return reply('Sedang di proses!, mohon tunggu sebentar ya senpai... jika terlalu lama mungkin terjadi error :(')
								await limitAdd(sender)
							  if (message.isMedia) {
								const mediaData = await decryptMedia(message)
								const imageBase64 = `data:${
								  message.mimetype
								  };base64,${mediaData.toString('base64')}`
								await nayla.sendImageAsSticker(message.from, imageBase64)
							  } else if (message.quotedMsg && message.quotedMsg.type == 'image') {
								const mediaData = await decryptMedia(message)
								const imageBase64 = `data:${
								  message.mimetype
								  };base64,${mediaData.toString('base64')}`
								await nayla.sendImageAsSticker(message.from, imageBase64)
							  } 
							  else {
								nayla.sendText(
								  message.from,
								  'Tidak ada gambar! Untuk membuat sticker kirim gambar dengan caption #sticker2'
								)
							  }
							  
							  break
						  
									
						case 'stiker3':
						case 'sticker3':
							if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
							if (isLimit(sender)) return reply('Sedang di proses!, mohon tunggu sebentar ya senpai... jika terlalu lama mungkin terjadi error :(')
							await limitAdd(sender)								 
							if (isMedia && isImage || isQuotedImage) {
									 try {
								 await nayla.reply(naylachan)
									 const encryptMedia = isQuotedImage ? quotedMsg : message
									 const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
							 const author = 'Shirogane Kei'
							 const pack = 'Kei Chwanss'
									 const mediaData = await decryptMedia(encryptMedia, uaOverride)
									 const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
									 await nayla.sendImageAsSticker(from, imageBase64, { author: `${author}`, pack: `${pack}` })
									 console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
								 } catch (err) {
									 console.error(err)
									 await nayla.reply(from, 'Error!', id)
								 }
							 } else if (args[0] === 'nobg') {
								 if (isMedia || isQuotedImage) {
												 const encryptMedia = isQuotedImage ? quotedMsg : message
										 const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
										 const mediaData = await decryptMedia(encryptMedia, uaOverride)
										 const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
												 await nayla.sendImageAsSticker(from, imageBase64, {keepScale: true, removebg: true})
											 } else {
												 await nayla.reply(from, 'Format pesan salah Onii-chan...', id)
											 }} else if (args.length === 1) {
								 if (!isUrl(url)) { await nayla.reply(from, 'Maaf Onii-chan, link yang kamu kirim tidak valid.', id) }
								 nayla.sendStickerfromUrl(from, url).then((r) => (!r && r !== undefined)
									 ? nayla.sendText(from, 'Maaf, link yang kamu kirim tidak memuat gambar.')
									 : nayla.reply(from, 'Here\'s your sticker')).then(() => console.log(`Sticker Processed for ${processTime(t, moment())} Second`))
							 } else {
								 await nayla.reply(from, `Tidak ada gambar! Untuk menggunakan ${prefix}sticker\n\n\nKirim gambar dengan caption\n${prefix}sticker <biasa>\n${prefix}sticker nobg <tanpa background>\n\natau Kirim pesan dengan\n${prefix}sticker <link_gambar>`)								 
							 } if (isMedia && type === 'video' || mimetype === 'image/gif') {
								 await nayla.reply(naylachan)
								 try {
									 const mediaData = await decryptMedia(message, uaOverride)
									 await nayla.sendMp4AsSticker(from, mediaData, { fps: 24, startTime: `00:00:00.0`, endTime : `00:00:10.0`, loop: 0 })
										 .then(async () => {
											 console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
											 await nayla.sendText(naylachan)
										 })
								 } catch (err) {
									 console.error(err)
									 await nayla.reply(naylachan)
								 }
							 } else if (isQuotedGif || isQuotedVideo) {
								 await nayla.reply(naylachan)
								 try {
									 const mediaData = await decryptMedia(quotedMsg, uaOverride)
									 await nayla.sendMp4AsSticker(from, mediaData, { fps: 24, startTime: `00:00:00.0`, endTime : `00:00:10.0`, loop: 0 })
										 .then(async () => {
											 console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
											 await nayla.sendText(naylachan)
										 })
								 } catch (err) {
									 console.error(err)
									 await nayla.reply(naylachan)
								 }
							 } 
							 break

			//starts from here is modificated case	Js 1671
							 //experimental
							 //replace if error to /* */			
			case 'botstat':
				{                    
				const loadedMsg = await nayla.getAmountOfLoadedMessages()
				const chatIds = await nayla.getAllChatIds()
				const groups = await nayla.getAllGroups()
				nayla.sendText(from, `Status :\n- *${loadedMsg}* Loaded Messages\n- *${groups.length}* Group Chats\n- *${chatIds.length - groups.length}* Personal Chats\n- *${chatIds.length}* Total Chats \n\n _Shirogane Kei Bot_`)
				break		
				}					
	case 'nhentai-pdf':  
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return						
				await limitAdd(sender)
				if (!isPrem) return reply(nyz.prem1(command)) 
				if (args.length == 0) return reply(`Contoh: ${prefix + command}<spasi>12345 Tunggu sebentar \nMaksimal 5-10menit/req, diluar itu berarti error atau size file doujinnya besar`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				henid = args[0]
				get_result = await fetchJson(`http://api.lolhuman.xyz/api/nhentaipdf/${henid}?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_buffer = await getBuffer(get_result)
				nayla.sendMessage(from, ini_buffer, document, { quoted: nay, mimetype: Mimetype.pdf, filename: `Nhentai - ${henid}.pdf -KeiBot` })
				//experimental
				if (err) {					
				   reply(nyz.error404(pushname, prefix))
				}								
				break
	case 'nhentai-info':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				if (args.length == 0) return reply(`Contoh: ${prefix + command} 344253`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				jds = []
				henid = args[0]
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nhentai/${henid}?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Title Romaji : ${get_result.title_romaji}\n`
				ini_txt += `Title Native : ${get_result.title_native}\n`
				ini_txt += `Read Online : ${get_result.read}\n`
				get_info = get_result.info
				ini_txt += `Parodies : ${get_info.parodies}\n`
				ini_txt += `Character : ${get_info.characters.join(", ")}\n`
				ini_txt += `Tags : ${get_info.tags.join(", ")}\n`
				ini_txt += `Artist : ${get_info.artists}\n`
				ini_txt += `Group : ${get_info.groups}\n`
				ini_txt += `Languager : ${get_info.languages.join(", ")}\n`
				ini_txt += `Categories : ${get_info.categories}\n`
				ini_txt += `Pages : ${get_info.pages}\n`
				ini_txt += `Uploaded : ${get_info.uploaded}\n`
				mentions(ini_txt, jds, true)
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break	
	case 'nhentai-cari':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)				
				jds = []				
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Gotoubun No Hanayome`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nhentaisearch?apikey=${l0lhuman}&query=${query}`)
				get_result = get_result.result
				ini_txt = "Nih hasilnya senpai! : \n"
				for (var x of get_result) {
					ini_txt += `Id : ${x.id}\n`
					ini_txt += `Title English : ${x.title_english}\n`
					ini_txt += `Title Japanese : ${x.title_japanese}\n`
					ini_txt += `Native : ${x.title_native}\n`
					ini_txt += `Upload : ${x.date_upload}\n`
					ini_txt += `Page : ${x.page}\n`
					ini_txt += `Favourite : ${x.favourite}\n\n`
					ini_txt += `- - - \n`
					ini_txt += `_Shirogane Kei Bot_\n`
				}
				mentions(ini_txt, jds, true)
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break		
	case 'nekopoi':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)	 
				if (args.length == 0) return reply(`Contoh: ${prefix + command} https://nekopoi.care/isekai-harem-monogatari-episode-4-subtitle-indonesia/`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				ini_url = args[0]
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nekopoi?apikey=${l0lhuman}&url=${ini_url}`)
				get_result = get_result.result
				ini_txt = `Title : ${get_result.anime}\n`
				ini_txt += `Porducers : ${get_result.producers}\n`
				ini_txt += `Duration : ${get_result.duration}\n`
				ini_txt += `Size : ${get_result.size}\n`
				ini_txt += `Sinopsis : ${get_result.sinopsis}\n`
				ini_txt += `- - - \n`
				ini_txt += `_Shirogane Kei Bot_\n`
				link = get_result.link
				for (var x in link) {
					ini_txt += `\n${link[x].name}\n`
					link_dl = link[x].link
					for (var y in link_dl) {
						ini_txt += `${y} - ${link_dl[y]}\n`
					}		
				}
				ini_buffer = await getBuffer(get_result.thumb)
				await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: ini_txt })
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break	
	case 'nekopoi-cari':
					jds = []
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)					
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Isekai Harem`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/nekopoisearch?apikey=${l0lhuman}&query=${query}`)
				get_result = get_result.result
				ini_txt = ""
				for (var x of get_result) {
					ini_txt += `Title : ${x.title}\n`
					ini_txt += `Link : ${x.link}\n`
					ini_txt += `Thumbnail : ${x.thumbnail}\n\n`
					ini_txt += `- - - \n`
					ini_txt += `_Shirogane Kei Bot_\n`
				}
				mentions(ini_txt, jds, true)
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break
	case 'cari-anime':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
					if (args.length == 0) return reply(`Contoh: ${prefix + command} Gotoubun No Hanayome`)
					//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
					query = args.join(" ")
					get_result = await fetchJson(`https://api.lolhuman.xyz/api/anime?apikey=${l0lhuman}&query=${query}`)
					get_result = get_result.result
					ini_txt = `Id : ${get_result.id}\n`
					ini_txt += `Id MAL : ${get_result.idMal}\n`
					ini_txt += `Title : ${get_result.title.romaji}\n`
					ini_txt += `English : ${get_result.title.english}\n`
					ini_txt += `Native : ${get_result.title.native}\n`
					ini_txt += `Format : ${get_result.format}\n`
					ini_txt += `Episodes : ${get_result.episodes}\n`
					ini_txt += `Duration : ${get_result.duration} mins.\n`
					ini_txt += `Status : ${get_result.status}\n`
					ini_txt += `Season : ${get_result.season}\n`
					ini_txt += `Season Year : ${get_result.seasonYear}\n`
					ini_txt += `Source : ${get_result.source}\n`
					ini_txt += `Start Date : ${get_result.startDate.day} - ${get_result.startDate.month} - ${get_result.startDate.year}\n`
					ini_txt += `End Date : ${get_result.endDate.day} - ${get_result.endDate.month} - ${get_result.endDate.year}\n`
					ini_txt += `Genre : ${get_result.genres.join(", ")}\n`
					ini_txt += `Synonyms : ${get_result.synonyms.join(", ")}\n`
					ini_txt += `Score : ${get_result.averageScore}%\n`
					ini_txt += `Characters : \n`
					ini_txt += `- - - \n`
					ini_txt += `_Shirogane Kei Bot_\n`
					ini_character = get_result.characters.nodes
					for (var x of ini_character) {
						ini_txt += `- ${x.name.full} (${x.name.native})\n`
					}
					ini_txt += `\nDescription : ${get_result.description}`
					thumbnail = await getBuffer(get_result.coverImage.large)
					await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
					//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break
				case 'pixiv':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				if (!isPrem) return reply(nyz.prem1(command))
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)				
					if (args.length == 0) return reply(`Contoh: ${prefix + command} loli kawaii \nUntuk hasilnya bisa saja tidak akurat ya senpai, mohon dimengerti`)
					query = args.join(" ")
					ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/pixiv?apikey=${l0lhuman}&query=${query}`)
					capt = `Nih senpai, jangan lupa bilang makasih...`
					await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: capt })
					//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
					break
				case 'pixivdl':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
					if (args.length == 0) return reply(`Contoh: ${prefix + command} 63456028`)
					//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
					query = args[0]
					ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/pixivdl/${pixivid}?apikey=${l0lhuman}`)
					capt = `Nih senpai, jangan lupa bilang makasih...`
					await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: capt })
					//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break
				// Information //	
			case 'randomhentai':
			case 'chiisaihentai':
			case 'trap':
			case 'blowjob':
			case 'yaoi':
			case 'ecchi':
			case 'hentai':
			case 'ahegao':
			case 'hololewd':
			case 'sideoppai':
			case 'animefeets':
			case 'animebooty':
			case 'animethighss':
			case 'hentaiparadise':
			case 'animearmpits':
			case 'hentaifemdom':
			case 'lewdanimegirls':
			case 'biganimetiddies':
			case 'animebellybutton':
			case 'hentai4everyone':				
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				anu1 = `Nih senpai, jangan lupa bilang makasih...`		
				await getBuffer(`https://api.lolhuman.xyz/api/random/nsfw/${command}?apikey=${l0lhuman}`).then((gambar) => {
					nayla.sendMessage(from, gambar, image, { quoted: nay, caption: anu1 })
				})
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break	
			case 'randomhentai2':
			case 'bj':
			case 'ero':
			case 'cum':
			case 'feet':
			case 'yuri':
			case 'trap':
			case 'lewd':
			case 'feed':
			case 'eron':
			case 'solo':
			case 'gasm':
			case 'poke':
			case 'anal':
			case 'holo':
			case 'tits':
			case 'kuni':
			case 'kiss':
			case 'erok':
			case 'smug':
			case 'baka':
			case 'solog':
			case 'feetg':
			case 'lewdk':
			case 'waifu':
			case 'pussy':
			case 'femdom':
			case 'cuddle':
			case 'hentai':
			case 'eroyuri':
			case 'cum_jpg':
			case 'blowjob':
			case 'erofeet':
			case 'holoero':
			case 'classic':
			case 'erokemo':
			case 'fox_girl':
			case 'futanari':
			case 'lewdkemo':
			case 'wallpaper':
			case 'pussy_jpg':
			case 'kemonomimi':
			case 'nsfw_avatar':				
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				anu1 = `Nih senpai, jangan lupa bilang makasih...`		
				getBuffer(`https://api.lolhuman.xyz/api/random2/${command}?apikey=${l0lhuman}`).then((gambar) => {
					nayla.sendMessage(from, gambar, image, { quoted: nay, caption: anu1 })
				})
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break
			case 'waifuu':
			case 'art':
			case 'bts':
			case 'exo':
			case 'elf':
			case 'loli':
			case 'neko':
			case 'shota':
			case 'husbu':
			case 'sagiri':
			case 'shinobu':
			case 'megumin':
			case 'wallnime':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				anu1 = `Nih senpai, jangan lupa bilang makasih...`					
				getBuffer(`https://api.lolhuman.xyz/api/random/${command}?apikey=${l0lhuman}`).then((gambar) => {
					nayla.sendMessage(from, gambar, image, { quoted: nay, caption: anu1 })
				})
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break							 
	//halal menu
		case 'listsurah':				    
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/quran?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = 'List Surah:\n'
			for (var x in get_result) {
				ini_txt += `${x}. ${get_result[x]}\n`
			}
			mentions(ini_txt, jds, true)
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
		case 'alquran':			    
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length < 1) return reply(`Nih ya senpai aku contohin: ${prefix + command} 18 or ${prefix + command} 18/10 or ${prefix + command} 18/1-10`)
			urls = `https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${l0lhuman}`
			quran = await fetchJson(urls)
			result = quran.result
			ayat = result.ayat
			ini_txt = `QS. ${result.surah} : 1-${ayat.length}\n\n`
			for (var x of ayat) {
				arab = x.arab
				nomor = x.ayat
				latin = x.latin
				indo = x.indonesia
				ini_txt += `${arab}\n${nomor}. ${latin}\n${indo}\n\n`
			}
			ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
			ini_txt = ini_txt.replace(/<strong>/g, "").replace(/<\/strong>/g, "")
			ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
			mentions(ini_txt, jds, true)
			break
		case 'alquranaudio':			    
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} 18 or ${prefix + command} 18/10`)
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			surah = args[0]
			ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/quran/audio/${surah}?apikey=${l0lhuman}`)
			await nayla.sendMessage(from, ini_buffer, audio, { quoted: nay, mimetype: Mimetype.mp4Audio })
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
		case 'asmaulhusna':			
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)    
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/asmaulhusna?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `No : ${get_result.index}\n`
			ini_txt += `Latin: ${get_result.latin}\n`
			ini_txt += `Arab : ${get_result.ar}\n`
			ini_txt += `Indonesia : ${get_result.id}\n`
			ini_txt += `English : ${get_result.en}`
			mentions(ini_txt, jds, true)
			break
		case 'kisahnabi':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)			    
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Muhammad`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/kisahnabi/${query}?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Name : ${get_result.name}\n`
			ini_txt += `Lahir : ${get_result.thn_kelahiran}\n`
			ini_txt += `Umur : ${get_result.age}\n`
			ini_txt += `Tempat : ${get_result.place}\n`
			ini_txt += `Story : \n${get_result.story}`
			mentions(ini_txt, jds, true)
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
		case 'jadwalsholat':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)    
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Yogyakarta`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			daerah = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/sholat/${daerah}?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Wilayah : ${get_result.wilayah}\n`
			ini_txt += `Tanggal : ${get_result.tanggal}\n`
			ini_txt += `Sahur : ${get_result.sahur}\n`
			ini_txt += `Imsak : ${get_result.imsak}\n`
			ini_txt += `Subuh : ${get_result.subuh}\n`
			ini_txt += `Terbit : ${get_result.terbit}\n`
			ini_txt += `Dhuha : ${get_result.dhuha}\n`
			ini_txt += `Dzuhur : ${get_result.dzuhur}\n`
			ini_txt += `Ashar : ${get_result.ashar}\n`
			ini_txt += `Maghrib : ${get_result.imsak}\n`
			ini_txt += `Isya : ${get_result.isya}`
			mentions(ini_txt, jds, true)
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break		
	//halal menu ends here

		//haram menu
		case 'xhamstersearch':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Japanese`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xhamstersearch?apikey=${l0lhuman}&query=${query}`)
			get_result = get_result.result
			ini_txt = ""
			for (var x of get_result) {
				ini_txt += `Title : ${x.title}\n`
				ini_txt += `Views : ${x.views}\n`
				ini_txt += `Duration : ${x.duration}\n`
				ini_txt += `Link : ${x.link}\n\n`
			}
			mentions(ini_txt, jds, true)
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
		case 'xhamster':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} https://xhamster.com/videos/party-with-friends-end-in-awesome-fucking-5798407`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xhamster?apikey=${l0lhuman}&url=${query}`)
			get_result = get_result.result
			ini_txt = `Title : ${get_result.title}\n`
			ini_txt += `Duration : ${get_result.duration}\n`
			ini_txt += `Uploader : ${get_result.author}\n`
			ini_txt += `Upload : ${get_result.upload}\n`
			ini_txt += `View : ${get_result.views}\n`
			ini_txt += `Rating : ${get_result.rating}\n`
			ini_txt += `Like : ${get_result.likes}\n`
			ini_txt += `Dislike : ${get_result.dislikes}\n`
			ini_txt += `Comment : ${get_result.comments}\n`
			ini_txt += "Link : \n"
			link = get_result.link
			for (var x of link) {
				ini_txt += `${x.type} - ${x.link}\n\n`
			}
			thumbnail = await getBuffer(get_result.thumbnail)
			await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
		case 'xnxxsearch':
			jds = []
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} Japanese`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xnxxsearch?apikey=${l0lhuman}&query=${query}`)
			get_result = get_result.result
			ini_txt = ""
			for (var x of get_result) {
				ini_txt += `Title : ${x.title}\n`
				ini_txt += `Views : ${x.views}\n`
				ini_txt += `Duration : ${x.duration}\n`
				ini_txt += `Uploader : ${x.uploader}\n`
				ini_txt += `Link : ${x.link}\n`
				ini_txt += `Thumbnail : ${x.thumbnail}\n\n`
			}
			mentions(ini_txt, jds, true)
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
		case 'xnxx':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} https://www.xnxx.com/video-uy5a73b/mom_is_horny_-_brooklyn`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/xnxx?apikey=${l0lhuman}&url=${query}`)
			get_result = get_result.result
			ini_txt = `Title : ${get_result.title}\n`
			ini_txt += `Duration : ${get_result.duration}\n`
			ini_txt += `View : ${get_result.view}\n`
			ini_txt += `Rating : ${get_result.rating}\n`
			ini_txt += `Like : ${get_result.like}\n`
			ini_txt += `Dislike : ${get_result.dislike}\n`
			ini_txt += `Comment : ${get_result.comment}\n`
			ini_txt += `Tag : ${get_result.tag.join(", ")}\n`
			ini_txt += `Description : ${get_result.description}\n`
			ini_txt += "Link : \n"
			ini_link = get_result.link
			for (var x of ini_link) {
				ini_txt += `${x.type} - ${x.link}\n\n`
			}
			thumbnail = await getBuffer(get_result.thumbnail)
			await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
	//haram menu ends here

	//What anime is this (experimental)
	case 'wait':
		//experimental
		await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
		if ((isMedia && !nay.message.videoMessage || isQuotedImage) && args.length == 0) {
			const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(nay).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : nay
			const filePath = await nayla.downloadAndSaveMediaMessage(encmedia, filename = getRandom());
			const form = new FormData();
			const stats = fs.statSync(filePath);
			const fileSizeInBytes = stats.size;
			const fileStream = fs.createReadStream(filePath);
			form.append('img', fileStream, { knownLength: fileSizeInBytes });
			const options = {
				method: 'POST',
				credentials: 'include',
				body: form
			}
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/wait?apikey=${l0lhuman}`, {...options })
			fs.unlinkSync(filePath)
			get_result = get_result.result
			ini_video = await getBuffer(get_result.video)
			ini_txt = `Anilist id : ${get_result.anilist_id}\n`
			ini_txt += `MAL id : ${get_result.mal_id}\n`
			ini_txt += `Title Romaji : ${get_result.title_romaji}\n`
			ini_txt += `Title Native : ${get_result.title_native}\n`
			ini_txt += `Title English : ${get_result.title_english}\n`
			ini_txt += `at : ${get_result.at}\n`
			ini_txt += `Episode : ${get_result.episode}\n`
			ini_txt += `Similarity : ${get_result.similarity}`
			await nayla.sendMessage(from, ini_video, video, { quoted: nay, caption: ini_txt })
		} else {
			reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
		}
		break

		case 'genshin':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return 
			await limitAdd(sender)
			if (args.length == 0) return reply(`Nih ya senpai aku contohin: ${prefix + command} jean`)
			//experimental
			await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
			hero = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/genshin/${hero}?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Name : ${get_result.title}\n`
			ini_txt += `Intro : ${get_result.intro}\n`
			ini_txt += `Icon : ${get_result.icon}\n`
			ini_icon = await getBuffer(get_result.cover1)
			await nayla.sendMessage(from, ini_icon, image, { quoted: nay, caption: ini_txt })
			ini_voice = await getBuffer(get_result.cv[0].audio[0])
			await nayla.sendMessage(from, ini_voice, audio, { quoted: nay, mimetype: Mimetype.mp4Audio })
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
			break
			case 'otakudesu-cari':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Gotoubun No Hanayome`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/otakudesusearch?apikey=${l0lhuman}&query=${query}`)
				get_result = get_result.result
				ini_txt = `Title : ${get_result.title}\n`
				ini_txt += `Japanese : ${get_result.japanese}\n`
				ini_txt += `Judul : ${get_result.judul}\n`
				ini_txt += `Type : ${get_result.type}\n`
				ini_txt += `Episode : ${get_result.episodes}\n`
				ini_txt += `Aired : ${get_result.aired}\n`
				ini_txt += `Producers : ${get_result.producers}\n`
				ini_txt += `Genre : ${get_result.genres}\n`
				ini_txt += `Duration : ${get_result.duration}\n`
				ini_txt += `Studios : ${get_result.status}\n`
				ini_txt += `Rating : ${get_result.rating}\n`
				ini_txt += `Credit : ${get_result.credit}\n`
				get_link = get_result.link_dl
				for (var x in get_link) {
					ini_txt += `\n\n*${get_link[x].title}*\n`
					for (var y in get_link[x].link_dl) {
						ini_info = get_link[x].link_dl[y]
						ini_txt += `\n\`\`\`Reso : \`\`\`${ini_info.reso}\n`
						ini_txt += `\`\`\`Size : \`\`\`${ini_info.size}\n`
						ini_txt += `\`\`\`Link : \`\`\`\n`
						down_link = ini_info.link_dl
						for (var z in down_link) {
							ini_txt += `${z} - ${down_link[z]}\n`
						}
					}
				}
				mentions(ini_txt, jds, true)
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break
                case 'otakudesu':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://otakudesu.tv/lengkap/pslcns-sub-indo/`)
					//experimental
					await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
                    ini_url = args[0]
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/otakudesu?apikey=${l0lhuman}&url=${ini_url}`)
                    get_result = get_result.result
                    ini_txt = `Title : ${get_result.title}\n`
                    ini_txt += `Japanese : ${get_result.japanese}\n`
                    ini_txt += `Judul : ${get_result.judul}\n`
                    ini_txt += `Type : ${get_result.type}\n`
                    ini_txt += `Episode : ${get_result.episodes}\n`
                    ini_txt += `Aired : ${get_result.aired}\n`
                    ini_txt += `Producers : ${get_result.producers}\n`
                    ini_txt += `Genre : ${get_result.genres}\n`
                    ini_txt += `Duration : ${get_result.duration}\n`
                    ini_txt += `Studios : ${get_result.status}\n`
                    ini_txt += `Rating : ${get_result.rating}\n`
                    ini_txt += `Credit : ${get_result.credit}\n`
                    get_link = get_result.link_dl
                    for (var x in get_link) {
                        ini_txt += `\n\n*${get_link[x].title}*\n`
                        for (var y in get_link[x].link_dl) {
                            ini_info = get_link[x].link_dl[y]
                            ini_txt += `\n\`\`\`Reso : \`\`\`${ini_info.reso}\n`
                            ini_txt += `\`\`\`Size : \`\`\`${ini_info.size}\n`
                            ini_txt += `\`\`\`Link : \`\`\`\n`
                            down_link = ini_info.link_dl
                            for (var z in down_link) {
                                ini_txt += `${z} - ${down_link[z]}\n`
                            }
                        }
                    }
                    mentions(ini_txt, jds, true)
                    break				
				case 'character':  
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return
				await limitAdd(sender) 
				if (args.length == 0) return reply(`Example: ${prefix + command} Miku Nakano`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				anu1 = await fetchJson(`http://api.lolhuman.xyz/api/character?apikey=${l0lhuman}&query=${query}`)
				anu = anu1.result
				anu2 = `Id : ${anu.id}\n`
				anu2 += `Name : ${anu.name.full}\n`
				anu2 += `Native : ${anu.name.native}\n`
				anu2 += `Favorites : ${anu.favourites}\n`
				anu2 += `Media : \n`
				ini_media = anu.media.nodes
				for (var x of ini_media) {
					anu2 += `- ${x.title.romaji} (${x.title.native})\n`
				}
				anu2 += `\nDescription : \n${anu.description.replace(/__/g, "_")}`
				thumbnail = await getBuffer(anu.image.large)
				nayla.sendMessage(from, thumbnail, image, { caption: anu2 })
				//experimental
				if (err) {					
					reply(nyz.error404(pushname, prefix))
				 }
				break
				case 'cari-manga':  
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return
				await limitAdd(sender) 
				if (args.length == 0) return reply(`Example: ${prefix + command} Gotoubun No Hanayome`)
				//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
				query = args.join(" ")
				anu1 = await fetchJson(`http://api.lolhuman.xyz/api/manga?apikey=${l0lhuman}&query=${query}`)
				anu = anu1.result
				anu2 = `➻ Id : ${anu.id}\n`
				anu2 += `➻ Id MAL : ${anu.idMal}\n`
				anu2 += `➻ Title : ${anu.title.romaji}\n`
				anu2 += `➻ English : ${anu.title.english}\n`
				anu2 += `➻ Native : ${anu.title.native}\n`
				anu2 += `➻ Format : ${anu.format}\n`
				anu2 += `➻ Chapters : ${anu.chapters}\n`
				anu2 += `➻ Volume : ${anu.volumes}\n`
				anu2 += `➻ Status : ${anu.status}\n`
				anu2 += `➻ Source : ${anu.source}\n`
				anu2 += `➻ Start Date : ${anu.startDate.day} - ${anu.startDate.month} - ${anu.startDate.year}\n`
				anu2 += `➻ end Date : ${anu.endDate.day} - ${anu.endDate.month} - ${anu.endDate.year}\n`
				anu2 += `➻ Genre : ${anu.genres.join(", ")}\n`
				anu2 += `➻ Synonyms : ${anu.synonyms.join(", ")}\n`
				anu2 += `➻ Score : ${anu.averageScore}%\n`
				anu2 += `➻ Characters : \n`
				ini_character = anu.characters.nodes
				for (var x of ini_character) {
					anu2 += `- ${x.name.full} (${x.name.native})\n`
				}
				anu2 += `\nDescription : ${anu.description}`
				thumbnail = await getBuffer(anu.coverImage.large)
				nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: anu2 })
				break         				
		//guna menu											
				case 'cuaca':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)		
				if (args.length == 0) return reply(`Contoh: ${prefix + command} Yogyakarta`)
				daerah = args[0]
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/cuaca/${daerah}?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Tempat : ${get_result.tempat}\n`
				ini_txt += `Cuaca : ${get_result.cuaca}\n`
				ini_txt += `Angin : ${get_result.angin}\n`
				ini_txt += `Description : ${get_result.description}\n`
				ini_txt += `Kelembapan : ${get_result.kelembapan}\n`
				ini_txt += `Suhu : ${get_result.suhu}\n`
				ini_txt += `Udara : ${get_result.udara}\n`
				ini_txt += `Permukaan laut : ${get_result.permukaan_laut}\n`
				await nayla.sendMessage(from, { degreesLatitude: get_result.latitude, degreesLongitude: get_result.longitude }, location, { quoted: nay })
				reply(ini_txt)
				break
				case 'covidindo':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)		
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/corona/indonesia?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Positif : ${get_result.positif}\n`
				ini_txt += `Sembuh : ${get_result.sembuh}\n`
				ini_txt += `Dirawat : ${get_result.dirawat}\n`
				ini_txt += `Meninggal : ${get_result.meninggal}`
				reply(ini_txt)
				break
				case 'covidglobal':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				if (isLimit(sender)) return							
				await limitAdd(sender)		
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/corona/global?apikey=${l0lhuman}`)
				get_result = get_result.result
				ini_txt = `Positif : ${get_result.positif}\n`
				ini_txt += `Sembuh : ${get_result.sembuh}\n`
				ini_txt += `Dirawat : ${get_result.dirawat}\n`
				ini_txt += `Meninggal : ${get_result.meninggal}`
				reply(ini_txt)
				break		
		case 'wikipedia':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			if (args.length == 0) return reply(`Example: ${prefix + command} Tahu`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/wiki?apikey=${l0lhuman}&query=${query}`)
			get_result = get_result.result
			mentions(get_result, jds, true)
			//experimental
			if (err) {					
				reply(nyz.error404(pushname, prefix))
			 }
		break
		//catch err mod - ends here Js 2506
        case 'hoax':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/turnbackhoax?apikey=${l0lhuman}`)
                    get_result = get_result.result
                    ini_txt = 'Info Hoax :\n'
                    for (var x of get_result) {
                        ini_txt += `Title : ${x.title}\n`
                        ini_txt += `Link : ${x.link}\n`
                        ini_txt += `Posted : ${x.posted}\n`
                        ini_txt += `Description : ${x.desc}\n\n`
                    }
                    mentions(ini_txt, jds, true)
        break		
        case 'kbbi':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
                    if (args.length == 0) return reply(`Example: ${prefix + command} kursi`)
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/kbbi?apikey=${l0lhuman}&query=${args.join(" ")}`)
                    lila = get_result.result
                    ini_txt = `\`\`\`Kata : ${lila[0].nama}\`\`\`\n`
                    ini_txt += `\`\`\`Kata Dasar : ${lila[0].kata_dasar}\`\`\`\n`
                    ini_txt += `\`\`\`Pelafalan : ${lila[0].pelafalan}\`\`\`\n`
                    ini_txt += `\`\`\`Bentuk Tidak Baku : ${lila[0].bentuk_tidak_baku}\`\`\`\n\n`
                    for (var x of lila) {
                        ini_txt += `\`\`\`Kode : ${x.makna[0].kelas[0].kode}\`\`\`\n`
                        ini_txt += `\`\`\`Kelas : ${x.makna[0].kelas[0].nama}\`\`\`\n`
                        ini_txt += `\`\`\`Artinya : \n${x.makna[0].kelas[0].deskripsi}\`\`\`\n\n`
                        ini_txt += `\`\`\`Makna Lain : \n${x.makna[0].submakna}\`\`\`\n `
                        ini_txt += `\`\`\`Contoh Kalimat : \n${x.makna[0].contoh}\`\`\`\n`
                    }
                    mentions(ini_txt, jds, true)
        break
        case 'jarak':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []		
                    if (args.length == 0) return reply(`Example: ${prefix + command} jakarta - yogyakarta`)
                    pauls = args.join(" ")
                    teks1 = pauls.split("-")[0].trim()
                    teks2 = pauls.split("-")[1].trim()
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/jaraktempuh?apikey=${l0lhuman}&kota1=${teks1}&kota2=${teks2}`)
                    x = get_result.result
                    ini_txt = `Informasi Jarak dari ${teks1} ke ${teks2} :\n\n`
                    ini_txt += `\`\`\`◪ Asal :\`\`\` ${x.from.name}\n`
                    ini_txt += `\`\`\`◪ Garis Lintang :\`\`\` ${x.from.latitude}\n`
                    ini_txt += `\`\`\`◪ Garis Bujur :\`\`\` ${x.from.longitude}\n\n`
                    ini_txt += `\`\`\`◪ Tujuan :\`\`\` ${x.to.name}\n`
                    ini_txt += `\`\`\`◪ Garis Lintang :\`\`\` ${x.to.latitude}\n`
                    ini_txt += `\`\`\`◪ Garis Bujur :\`\`\` ${x.to.longitude}\n\n`
                    ini_txt += `\`\`\`◪ Jarak Tempuh :\`\`\` ${x.jarak}\n`
                    ini_txt += `\`\`\`◪ Waktu Tempuh :\`\`\`\n`
                    ini_txt += `   ╭───────────────❏\n`
                    ini_txt += `❍┤ Kereta Api : ${x.kereta_api}\n`
                    ini_txt += `❍┤ Pesawat : ${x.pesawat}\n`
                    ini_txt += `❍┤ Mobil : ${x.mobil}\n`
                    ini_txt += `❍┤ Motor : ${x.motor}\n`
                    ini_txt += `❍┤ Jalan Kaki : ${x.jalan_kaki}\n`
                    ini_txt += `   ╰───────────────❏\n`
                    mentions(ini_txt, jds, true)
                    break
        case 'urbandictionary':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
                    urb = args.join(" ")
                    get_result = await fetchJson(`http://lolhuman.herokuapp.com/api/urdict?apikey=${l0lhuman}&query=${urb}`)
                    lilu = get_result.result
                    for (var x of lilu) {
                        ini_txt = `\`\`\`Meaning :\n${x.definition}\`\`\`\n\n`
                        ini_txt += `\`\`\`Link : ${x.permalink}\`\`\`\n\n`
                        ini_txt += `\`\`\`Sounds Url : ${x.sound_urls[0]}\`\`\`\n\n`
                        ini_txt += `\`\`\`Like : ${x.thumbs_up}\`\`\`\n\n`
                        ini_txt += `\`\`\`Dislike : ${x.thumbs_down}\`\`\`\n\n`
                        ini_txt += `\`\`\`Created On : \n${x.written_on}\`\`\`\n\n`
                        ini_txt += `\`\`\`Author : ${x.author}\`\`\`\n\n`
                        ini_txt += `\`\`\`Word : ${x.word}\`\`\`\n\n`
                        ini_txt += `\`\`\`Defined Id : ${x.defid}\`\`\`\n\n`
                        ini_txt += `\`\`\`Example : ${x.example}\`\`\`\n\n`
                    }
                    mentions(ini_txt, jds, true)
        break					
		case 'translate':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			if (args.length == 0) return reply(`Example: ${prefix + command} en Tahu Bacem`)
			kode_negara = args[0]
			args.shift()
			ini_txt = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/translate/auto/${kode_negara}?apikey=${l0lhuman}&text=${ini_txt}`)
			get_result = get_result.result
			init_txt = `From : ${get_result.from}\n`
			init_txt += `To : ${get_result.to}\n`
			init_txt += `Original : ${get_result.original}\n`
			init_txt += `Translated : ${get_result.translated}\n`
			init_txt += `Pronunciation : ${get_result.pronunciation}\n`
			mentions(init_txt, jds, true)
			break
		case 'brainly':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			if (args.length == 0) return reply(`Example: ${prefix + command} Soekarno adalah`)
			query = args.join(" ")
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/brainly?apikey=${l0lhuman}&query=${query}`)
			get_result = get_result.result
			ini_txt = "Result : \n"
			for (var x of get_result) {
				ini_txt += `${x.title}\n`
				ini_txt += `${x.url}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'jadwaltv':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			if (args.length == 0) return reply(`Example: ${prefix + command} RCTI`)
			channel = args[0]
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/jadwaltv/${channel}?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Jadwal TV ${channel.toUpperCase()}\n`
			for (var x in get_result) {
				ini_txt += `${x} - ${get_result[x]}\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'jadwaltvnow':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/jadwaltv/now?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Jadwal TV Now :\n`
			for (var x in get_result) {
				ini_txt += `${x.toUpperCase()}${get_result[x]}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'newsinfo':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/newsinfo?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = "Result :\n"
			for (var x of get_result) {
				ini_txt += `Title : ${x.title}\n`
				ini_txt += `Author : ${x.author}\n`
				ini_txt += `Source : ${x.source.name}\n`
				ini_txt += `Url : ${x.url}\n`
				ini_txt += `Published : ${x.publishedAt}\n`
				ini_txt += `Description : ${x.description}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'cnnindonesia':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/cnnindonesia?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = "Result :\n"
			for (var x of get_result) {
				ini_txt += `Judul : ${x.judul}\n`
				ini_txt += `Link : ${x.link}\n`
				ini_txt += `Tipe : ${x.tipe}\n`
				ini_txt += `Published : ${x.waktu}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'cnnnasional':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/cnnindonesia/nasional?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = "Result :\n"
			for (var x of get_result) {
				ini_txt += `Judul : ${x.judul}\n`
				ini_txt += `Link : ${x.link}\n`
				ini_txt += `Tipe : ${x.tipe}\n`
				ini_txt += `Published : ${x.waktu}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'cnninternasional':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/cnnindonesia/internasional?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = "Result :\n"
			for (var x of get_result) {
				ini_txt += `Judul : ${x.judul}\n`
				ini_txt += `Link : ${x.link}\n`
				ini_txt += `Tipe : ${x.tipe}\n`
				ini_txt += `Published : ${x.waktu}\n\n`
			}
			mentions(ini_txt, jds, true)
			break
		case 'infogempa':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			get_result = await fetchJson(`https://api.lolhuman.xyz/api/infogempa?apikey=${l0lhuman}`)
			get_result = get_result.result
			ini_txt = `Lokasi : ${get_result.lokasi}\n`
			ini_txt += `Waktu : ${get_result.waktu}\n`
			ini_txt += `Potensi : ${get_result.potensi}\n`
			ini_txt += `Magnitude : ${get_result.magnitude}\n`
			ini_txt += `Kedalaman : ${get_result.kedalaman}\n`
			ini_txt += `Koordinat : ${get_result.koordinat}`
			get_buffer = await getBuffer(get_result.map)
			await nayla.sendMessage(from, get_buffer, image, { quoted: nay, caption: ini_txt })
			break	
	//guna menu ends here
	
	//gabut menu
    case 'wancak':
			if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/onecak?apikey=${l0lhuman}`)
                    await nayla.sendMessage(from, ini_buffer, image, { quoted: nay })
    break	
	case 'cerpen':
		if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
			jds = []
		get_result = await fetchJson(`https://api.lolhuman.xyz/api/cerpen?apikey=${l0lhuman}`)
		get_result = get_result.result
		ini_txt = `Title : ${get_result.title}\n`
		ini_txt += `Creator : ${get_result.creator}\n`
		ini_txt += `Story :\n${get_result.cerpen}`
		mentions(ini_txt, jds, true)
		break
	case 'ceritahoror':
		if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			if (isLimit(sender)) return
			await limitAdd(sender)
		get_result = await fetchJson(`https://api.lolhuman.xyz/api/ceritahoror?apikey=${l0lhuman}`)
		get_result = get_result.result
		ini_txt = `Title : ${get_result.title}\n`
		ini_txt += `Desc : ${get_result.desc}\n`
		ini_txt += `Story :\n${get_result.story}\n`
		thumbnail = await getBuffer(get_result.thumbnail)
		await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
		break
		//ends here

                    // Random Text //
					case 'quotes':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
						quotes = await fetchJson(`https://api.lolhuman.xyz/api/random/quotes?apikey=${l0lhuman}`)
						quotes = quotes.result
						author = quotes.by
						quotes = quotes.quote
						reply(`_${quotes}_\n\n*― ${author}*`)
						break
					case 'quotesanime':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
						quotes = await fetchJson(`https://api.lolhuman.xyz/api/random/quotesnime?apikey=${l0lhuman}`)
						quotes = quotes.result
						quote = quotes.quote
						char = quotes.character
						anime = quotes.anime
						episode = quotes.episode
						mentions((`_${quote}_\n\n*― ${char}*\n*― ${anime} ${episode}*`), jds, true)
						break
					case 'quotesdilan':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
						quotedilan = await fetchJson(`https://api.lolhuman.xyz/api/quotes/dilan?apikey=${l0lhuman}`)
						mentions((quotedilan.result), jds, true)
						break
					case 'quotesimage':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						get_result = await getBuffer(`https://api.lolhuman.xyz/api/random/${command}?apikey=${l0lhuman}`)
						await nayla.sendMessage(from, get_result, image, { quotes: nay })
						break
					case 'faktaunik':
					case 'katabijak':
					case 'pantun':
					case 'bucin':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
						get_result = await fetchJson(`https://api.lolhuman.xyz/api/random/${command}?apikey=${l0lhuman}`)
						mentions((get_result.result), jds, true)
						break
					case 'randomnama':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
						anu = await fetchJson(`https://api.lolhuman.xyz/api/random/nama?apikey=${l0lhuman}`)
						mentions((anu.result), jds, true)
						break
	
				//pencarian
					case 'google':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
						if (args.length == 0) return reply(`Example: ${prefix + command} loli kawaii`)
						query = args.join(" ")
						get_result = await fetchJson(`https://api.lolhuman.xyz/api/gsearch?apikey=${l0lhuman}&query=${query}`)
						get_result = get_result.result
						ini_txt = 'Google Search : \n'
						for (var x of get_result) {
							ini_txt += `Title : ${x.title}\n`
							ini_txt += `Link : ${x.link}\n`
							ini_txt += `Desc : ${x.desc}\n\n`
						}
						mentions(ini_txt, jds, true)
						break
				//tools menu
					case 'shortlink':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						jds = []
						if (args.length == 0) return reply(`Example: ${prefix + command} https://api.lolhuman.xyz`)
						ini_link = args[0]
						ini_buffer = await fetchJson(`https://api.lolhuman.xyz/api/shortlink?apikey=${l0lhuman}&url=${ini_link}`)
						mentions((ini_buffer.result), jds, true)
						break
				//maker menu
					case 'pornhub':
					case 'glitch':
					case 'avenger':
					case 'space':
					case 'ninjalogo':
					case 'marvelstudio':
					case 'lionlogo':
					case 'wolflogo':
					case 'steel3d':
					case 'wallgravity':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
						if (args.length == 0) return reply(`Example: ${prefix + command} LoL Human`)
						//experimental
				await reply(`Mohon tunggu sebentar ya senpai, sedang diproses....`)
						txt1 = args[0]
						txt2 = args[1]
						cpt1 = `Nih senpai, jgn lupa bilang makasih..,`
						getBuffer(`https://api.lolhuman.xyz/api/textprome2/${command}?apikey=${l0lhuman}&text1=${txt1}&text2=${txt2}`).then((gambar) => {
							nayla.sendMessage(from, gambar, image, { quoted: nay, caption: cpt1 })
						})
						//experimental
				if (err) {					
				   reply(nyz.error404(pushname, prefix))
				}
						break			
                case 'ktpmaker':
				if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
                    if (args.length == 0) return reply(`Usage: ${prefix + command} nik|provinsi|kabupaten|nama|tempat, tanggal lahir|jenis kelamin|jalan|rt/rw|kelurahan|kecamatan|agama|status nikah|pekerjaan|warga negara|berlaku sampai|url_image\n\nExample: ${prefix + command} 456127893132123|bumipertiwi|fatamorgana|LoL Human|mars, 99-99-9999|belum ditemukan|jl wardoyo|999/999|turese|imtuni|alhamdulillah islam|jomblo kack|mikirin dia|indo ori no kw|hari kiamat|https://i.ibb.co/Xb2pZ88/test.jpg`)
                    get_args = args.join(" ").split("|")
                    nik = get_args[0]
                    prov = get_args[1]
                    kabu = get_args[2]
                    name = get_args[3]
                    ttl = get_args[4]
                    jk = get_args[5]
                    jl = get_args[6]
                    rtrw = get_args[7]
                    lurah = get_args[8]
                    camat = get_args[9]
                    agama = get_args[10]
                    nikah = get_args[11]
                    kerja = get_args[12]
                    warga = get_args[13]
                    until = get_args[14]
                    img = get_args[15]
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/ktpmaker?apikey=${l0lhuman}&nik=${nik}&prov=${prov}&kabu=${kabu}&name=${name}&ttl=${ttl}&jk=${jk}&jl=${jl}&rtrw=${rtrw}&lurah=${lurah}&camat=${camat}&agama=${agama}&nikah=${nikah}&kerja=${kerja}&warga=${warga}&until=${until}&img=${img}`)
                    await nayla.sendMessage(from, ini_buffer, image, { quoted: nay })
                    break
			//Mediamenu
                case 'ttp':
                case 'ttp2':
                case 'ttp3':
                case 'ttp4':
                case 'attp':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} Kei chan cantik`)
                    ini_txt = args.join(" ")
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=${l0lhuman}&text=${ini_txt}`)
                    await nayla.sendMessage(from, ini_buffer, sticker, { quoted: nay })
                    break
                case 'triggered':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    ini_url = args[0]
                    ranp = getRandom('.gif')
                    rano = getRandom('.webp')
                    ini_buffer = `https://api.lolhuman.xyz/api/editor/triggered?apikey=${l0lhuman}&img=${ini_url}`
                    exec(`wget "${ini_buffer}" -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
                        fs.unlinkSync(ranp)
                        buff = fs.readFileSync(rano)
                        nayla.sendMessage(from, buff, sticker, { quoted: nay }).then(() => {
                            fs.unlinkSync(rano)
                        })
                    })
                    break			
                case 'lk21':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} Transformer`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/lk21?apikey=${l0lhuman}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = `Title : ${get_result.title}\n`
                    ini_txt += `Link : ${get_result.link}\n`
                    ini_txt += `Genre : ${get_result.genre}\n`
                    ini_txt += `Views : ${get_result.views}\n`
                    ini_txt += `Duration : ${get_result.duration}\n`
                    ini_txt += `Tahun : ${get_result.tahun}\n`
                    ini_txt += `Rating : ${get_result.rating}\n`
                    ini_txt += `Desc : ${get_result.desc}\n`
                    ini_txt += `Actors : ${get_result.actors.join(", ")}\n`
                    ini_txt += `Location : ${get_result.location}\n`
                    ini_txt += `Date Release : ${get_result.date_release}\n`
                    ini_txt += `Language : ${get_result.language}\n`
                    ini_txt += `Link Download : ${get_result.link_dl}`
                    thumbnail = await getBuffer(get_result.thumbnail)
                    await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
                    break
                case 'drakorongoing':
						jds = []
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/drakorongoing?apikey=${l0lhuman}`)
                    get_result = get_result.result
                    ini_txt = "Ongoing Drakor\n\n"
                    for (var x of get_result) {
                        ini_txt += `Title : ${x.title}\n`
                        ini_txt += `Link : ${x.link}\n`
                        ini_txt += `Thumbnail : ${x.thumbnail}\n`
                        ini_txt += `Year : ${x.category}\n`
                        ini_txt += `Total Episode : ${x.total_episode}\n`
                        ini_txt += `Genre : ${x.genre.join(", ")}\n\n`
                    }
                    mentions(ini_txt, jds, true)
                    break			
                case 'ytplay':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)
                    if (args.length == 0) return await reply(`Example: ${prefix + command} melukis senja`)
                    await fetchJson(`https://api.lolhuman.xyz/api/ytsearch?apikey=${l0lhuman}&query=${args.join(" ")}`)
                        .then(async(result) => {
                            await fetchJson(`https://api.lolhuman.xyz/api/ytaudio2?apikey=${l0lhuman}&url=https://www.youtube.com/watch?v=${result.result[0].videoId}`)
                                .then(async(result) => {
                                    result = result.result
                                    caption = `❖ Title    : *${result.title}*\n`
                                    caption += `❖ Size     : *${result.size}*`
                                    ini_buffer = await getBuffer(result.thumbnail)
                                    await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: caption })
                                    get_audio = await getBuffer(result.link)
                                    await nayla.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${result.title}.mp3`, quoted: nay })
                                })
                        })
                    break
                case 'ytsearch':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} Melukis Senja`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/ytsearch?apikey=${l0lhuman}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = ""
                    for (var x of get_result) {
                        ini_txt += `Title : ${x.title}\n`
                        ini_txt += `Views : ${x.views}\n`
                        ini_txt += `Published : ${x.published}\n`
                        ini_txt += `Thumbnail : ${x.thumbnail}\n`
                        ini_txt += `Link : https://www.youtube.com/watch?v=${x.videoId}\n\n`
                    }
                    reply(ini_txt)
                    break
                case 'ytmp3':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www.youtube.com/watch?v=qZIQAk-BUEc`)
                    ini_link = args[0]
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/ytaudio2?apikey=${l0lhuman}&url=${ini_link}`)
                    get_result = get_result.result
                    caption = `❖ Title    : *${result.title}*\n`
                    caption += `❖ Size     : *${result.size}*`
                    ini_buffer = await getBuffer(get_result.thumbnail)
                    await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: ini_txt })
                    get_audio = await getBuffer(get_result.link)
                    await nayla.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${get_result.title}.mp3`, quoted: nay })
                    break
                case 'ytmp4':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www.youtube.com/watch?v=qZIQAk-BUEc`)
                    ini_link = args[0]
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/ytvideo2?apikey=${l0lhuman}&url=${ini_link}`)
                    get_result = get_result.result
                    ini_txt = `${get_result.title} - ${get_result.size}`
                    ini_buffer = await getBuffer(get_result.thumbnail)
                    await nayla.sendMessage(from, ini_buffer, image, { quoted: nay, caption: ini_txt })
                    get_audio = await getBuffer(get_result.link)
                    await nayla.sendMessage(from, get_audio, video, { mimetype: 'video/mp4', filename: `${get_result.title}.mp4`, quoted: nay })
                    break
                case 'telesticker':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://t.me/addstickers/LINE_Menhera_chan_ENG`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/telestick?apikey=${l0lhuman}&url=${ini_url}`)
                    ini_sticker = ini_url.result.sticker
                    for (sticker_ in ini_sticker) {
                        ini_buffer = await getBuffer(ini_sticker[sticker_])
                        await nayla.sendMessage(from, ini_buffer, sticker)
                    }
                    break
                case 'tiktoknowm':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://vt.tiktok.com/ZSwWCk5o/`)
                    ini_url = args[0]
                    ini_url = `https://api.lolhuman.xyz/api/tiktok?apikey=${l0lhuman}&url=${ini_url}`
                    get_result = await fetchJson(ini_url)
                    ini_buffer = await getBuffer(get_result.result.link)
                    await nayla.sendMessage(from, ini_buffer, video, { quoted: nay })
                    break
                case 'tiktokmusic':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://vt.tiktok.com/ZSwWCk5o/`)
                    ini_link = args[0]
                    get_audio = await getBuffer(`https://api.lolhuman.xyz/api/tiktokmusic?apikey=${l0lhuman}&url=${ini_link}`)
                    await nayla.sendMessage(from, get_audio, audio, { mimetype: Mimetype.mp4Audio, quoted: nay })
                    break
                case 'spotify':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://open.spotify.com/track/0ZEYRVISCaqz5yamWZWzaA`)
                    url = args[0]
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/spotify?apikey=${l0lhuman}&url=${url}`)
                    get_result = get_result.result
                    ini_txt = `Title : ${get_result.title}\n`
                    ini_txt += `Artists : ${get_result.artists}\n`
                    ini_txt += `Duration : ${get_result.duration}\n`
                    ini_txt += `Popularity : ${get_result.popularity}\n`
                    ini_txt += `Preview : ${get_result.preview_url}\n`
                    thumbnail = await getBuffer(get_result.thumbnail)
                    await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
                    get_audio = await getBuffer(get_result.link)
                    await nayla.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${get_result.title}.mp3`, quoted: nay })
                    break
                case 'spotifysearch':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
					jds = []
                    if (args.length == 0) return reply(`Example: ${prefix + command} Melukis Senja`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/spotifysearch?apikey=${l0lhuman}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = ""
                    for (var x of get_result) {
                        ini_txt += `Title : ${x.title}\n`
                        ini_txt += `Artists : ${x.artists}\n`
                        ini_txt += `Duration : ${x.duration}\n`
                        ini_txt += `Link : ${x.link}\n`
                        ini_txt += `Preview : ${x.preview_url}\n\n\n`
                    }
                    mentions(ini_txt, jds, true)
                    break
                case 'jooxplay':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} Melukis Senja`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/jooxplay?apikey=${l0lhuman}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = `Title : ${get_result.info.song}\n`
                    ini_txt += `Artists : ${get_result.info.singer}\n`
                    ini_txt += `Duration : ${get_result.info.duration}\n`
                    ini_txt += `Album : ${get_result.info.album}\n`
                    ini_txt += `Uploaded : ${get_result.info.date}\n`
                    ini_txt += `Lirik :\n ${get_result.lirik}\n`
                    thumbnail = await getBuffer(get_result.image)
                    await nayla.sendMessage(from, thumbnail, image, { quoted: nay, caption: ini_txt })
                    get_audio = await getBuffer(get_result.audio[0].link)
                    await nayla.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${get_result.info.song}.mp3`, quoted: nay })
                    break
                case 'igdl':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/instagram?apikey=${l0lhuman}&url=${ini_url}`)
                    ini_url = ini_url.result
                    ini_type = image
                    if (ini_url.includes(".mp4")) ini_type = video
                    ini_buffer = await getBuffer(ini_url)
                    await nayla.sendMessage(from, ini_buffer, ini_type, { quoted: nay })
                    break
                case 'igdl2':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/instagram2?apikey=${l0lhuman}&url=${ini_url}`)
                    ini_result = ini_url.result.media
                    for (var x of ini_result) {
                        ini_type = image
                        if (x.includes(".mp4")) ini_type = video
                        ini_buffer = await getBuffer(x)
                        await nayla.sendMessage(from, ini_buffer, ini_type, { quoted: nay })
                    }
                    break
                case 'twtdl':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://twitter.com/gofoodindonesia/status/1229369819511709697`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/twitter?apikey=${l0lhuman}&url=${ini_url}`)
                    ini_url = ini_url.result
                    ini_url = ini_url[ini_url.length - 1].link
                    ini_buffer = await getBuffer(ini_url)
                    await nayla.sendMessage(from, ini_buffer, video, { quoted: nay })
                    break
                case 'fbdl':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://id-id.facebook.com/SamsungGulf/videos/video-bokeh/561108457758458/`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/facebook?apikey=${l0lhuman}&url=${ini_url}`)
                    ini_url = ini_url.result[0].link
                    ini_buffer = await getBuffer(ini_url)
                    await nayla.sendMessage(from, ini_buffer, video, { quoted: nay })
                    break
                case 'zippyshare':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
					jds = []
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www51.zippyshare.com/v/5W0TOBz1/file.html`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/zippyshare?apikey=${l0lhuman}&url=${ini_url}`)
                    ini_url = ini_url.result
                    ini_txt = `File Name : ${ini_url.name_file}\n`
                    ini_txt += `Size : ${ini_url.size}\n`
                    ini_txt += `Date Upload : ${ini_url.date_upload}\n`
                    ini_txt += `Download Url : ${ini_url.download_url}`
                    mentions(ini_txt, jds, true)
                    break
                case 'pinterest':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} loli kawaii`)
                    query = args.join(" ")
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/pinterest?apikey=${l0lhuman}&query=${query}`)
                    ini_url = ini_url.result
                    ini_buffer = await getBuffer(ini_url)
                    await nayla.sendMessage(from, ini_buffer, image, { quoted: nay })
                    break
                case 'pinterest2':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} loli kawaii`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/pinterest2?apikey=${l0lhuman}&query=${query}`)
                    get_result = get_result.result
                    for (var x = 0; x <= 5; x++) {
                        var ini_buffer = await getBuffer(get_result[x])
                        await nayla.sendMessage(from, ini_buffer, image)
                    }
                    break
                case 'pinterestdl':
						if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
						if (isLimit(sender)) return
						await limitAdd(sender)				
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://id.pinterest.com/pin/696580267364426905/`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/pinterestdl?apikey=${l0lhuman}&url=${ini_url}`)
                    ini_url = ini_url.result[0]
                    ini_buffer = await getBuffer(ini_url)
                    await nayla.sendMessage(from, ini_buffer, image, { quoted: nay })
                    break
			//mediamenu ends here

		//ends here										
                    case 'bc':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender) 
					if (!isOwner) return
					if (args.length < 1) return reply('.......')
					anu = await nayla.chats.all()
					if (isMedia && !nay.message.videoMessage || isQuotedImage) {
					const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(nay).replace('quotedM','m')).message.extendedTextMessage.contextInfo : nay
					buff = await nayla.downloadMediaMessage(encmedia)
					for (let _ of anu) {
					nayla.sendMessage(_.jid, buff, image, {caption: `[ *${namebot} BROADCAST* \n\n${body.slice(4)}`})
					}
					reply('*SUCCESS BROADCAST* ')
					} else {
					for (let _ of anu) {
					sendMess(_.jid, `[ *${namebot} BROADCAST* ]\n\n${body.slice(4)}`)
					}
					reply('*SUCCESS BROADCAST* ')
					}
					break
					case 'clearall':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isOwner) return reply(`lu owner??`)
					anu = await nayla.chats.all()
					nayla.setMaxListeners(25)
					for (let _ of anu) {
						nayla.deleteChat(_.jid)
					}
					reply(`sukses`)
					break									 	 
                    case 'linkgc':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    if (!isGroup) return reply(`GRUB ONLY`) 
				    if (!isBotGroupAdmins) return reply(`Maaf kak Kei chan bukan admin :(`)
				    linkgc = await nayla.groupInviteCode (from)
				    yeh = `https://chat.whatsapp.com/${linkgc}\n\nlink Group *${groupName}*`
				    nayla.sendMessage(from, yeh, text, {quoted: nay1})			       
					break
				    case 'tagall':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender) 
					if (!isGroupAdmins) return
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
					teks += `➪ @${mem.jid.split('@')[0]}\n`
					members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					break
				    case 'delete':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    case 'del':  
				    case 'd':
					case 'hapus':  	
				    nayla.deleteMessage(from, { id: nay.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true }) 
				    break
				    case 'kick':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`Cuma bisa di grup kak`)
					if (!isGroupAdmins) return reply(`Hanya dapat dilakukan oleh admin grup hehe...`)
					if (!isBotGroupAdmins) return reply(`Maaf kak Kei chan bukan admin :(`)
					if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('tag yg ingin di kick!')
					mentioned = nay.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
					teks = ''
					for (let _ of mentioned) {
					teks += `Byee Oni-chan muachhhh... 🏃 :\n`
					teks += `@_.split('@')[0]`
					}
					mentions(teks, mentioned, true)
					nayla.groupRemove(from, mentioned)
					} else {
					mentions(`Perintah diterima senpai!, bye bye @${mentioned[0].split('@')[0]} semoga kakak bisa merenungkan kenapa admin meng-kik kakak tehe`, mentioned, true)
					nayla.groupRemove(from, mentioned)
					}					
					break 
					case 'hidetag':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)              
				    if (!isGroup) return reply(`GRUP ONLY`)
					if (!isGroupAdmins) return reply(`Hanya dapat dilakukan oleh admin grup!`)
					var value = body.slice(9)
					var group = await nayla.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: value,
					contextInfo: { mentionedJid: mem },
					quoted: nay
					}
					nayla.sendMessage(from, options, text)					 
					break
			    	case 'add':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GRUP ONLY`)
					if (!isGroupAdmins) return reply(`Hanya dapat dilakukan oleh admin grup!`)
					if (!isBotGroupAdmins) return reply(`Kei Chan belum jadi ADMIN`)
					if (args.length < 1) return reply('Yang mau di add jin ya? \nNih saya kasih contoh kak \n#add 628123xxxx ,jgn pakai tanda "+" dan "-" \nJika tetap tidak bisa mungkin karena di privat/yg mau di add baru saja keluar grup')
					if (args[0].startsWith('08')) return reply('Gunakan kode negara ya kak')
					try {
					num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
					nayla.groupAdd(from, [num])
					} catch (e) {
					console.log('Error :', e)
					reply('Gagal menambahkan target, mungkin karena di private kak')
					}  
					break 
				     
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ CASE ANTIII ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 
                    
                                    
                     
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ CASE ANTIII ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 

                     
					case 'bug':  
                    if (args.length < 1) return reply(`contoh ${prefix}bug antilink`)
                    const bug1 = body.slice(5)
                    if (bug1.length > 300) return nayla.sendMessage(from, 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks', msgType.text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `*Shirogane Kei Bot`} } }})
                    var nomor = nay.participant
                    const bug2 = `*[LAPOR ERROR FITUR]*\nDARI ${pushname} \nNomor : @${nomor.split("@s.whatsapp.net")[0]}\nPesan : ${bug1}`
                    var optionsp = {
                    text: bug2,
                    contextInfo: {mentionedJid: [nomor]},
                    }                     
                    nayla.sendMessage(`${setting.ownerNumber}@s.whatsapp.net`, optionsp, text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `*TERIMAKASIH TELAT REPORT BUG*`} } } })                    
                    reply('Yeayyy, sukses melapor bug senpai!...sankyuuu')                     
					break   
					case 'request':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    if (args.length < 1) return reply(`mau request apa kak??\n${prefix}request *nama fitur*`)
                    const cet1 = body.slice(9)
                    if (cet1.length > 300) return nayla.sendMessage(from, 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks', msgType.text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": cr} } } })
                    var nomor = nay.participant
                    const cet2 = `*[ REQUEST FITUR ]*\nDARI ${pushname} \nNomor : @${nomor.split("@s.whatsapp.net")[0]}\nPesan : ${cet1}`
                    var optionsp = {
                    text: cet2,
                    contextInfo: {mentionedJid: [nomor]},
                    } 
                    nayla.sendMessage(`${setting.ownerNumber}@s.whatsapp.net`, optionsp, text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `*NIHHH WOIII REQUEST*`} } } })
                    nayla.sendMessage(`6281329585825@s.whatsapp.net`, optionsp, text, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "caption": `*NIHHH WOIII REQUEST*`} } } })                                    
                    reply(`TERIMAKASIH REQ ANDA AKAN KAMI PROSES`)
                    break
                    case 'nulis1':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    if (args.length < 1) return reply(`[❗] CONTOH??\n*${prefix}${command} nama & kelas & nulis*`)
                    var F = body.slice(8)
			        var F1 = F.split("&")[0];
			 	    var F2 = F.split("&")[1]; 
			 	    var F3 = F.split("&")[2]; 
                    reply(naylachan)
                    anu = await getBuffer(`https://api.xteam.xyz/magernulis?nama=${F1}&kelas=${F2}&text=${F3}&APIKEY=${apixteam}`)
                    nayla.sendMessage(from, anu, image, {caption: `nih kak`, quoted: nay})
                    break
                    case 'nulis2':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    if (args.length < 1) return reply(`[❗] CONTOH??\n*${prefix}${command} bot whatsapp*`)
                    reply(naylachan) 
                    F = body.slice(8)              			    
                    anu = await getBuffer(`https://api.xteam.xyz/magernulis2?text=${F}&APIKEY=${apixteam}`)
                    nayla.sendMessage(from, anu, image, {caption: `Nihh kack`, quoted: nay1}) 
                    break 
                    case 'nulis3':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    if (args.length < 1) return reply(`[❗] CONTOH??\n*${prefix}${command} bot whatsapp*`)
                    reply(naylachan) 
                    F = body.slice(8)              			    
                    anu = await getBuffer(`https://api.xteam.xyz/magernulis3?text=${F}&APIKEY=${apixteam}`)
                    nayla.sendMessage(from, anu, image, {caption: `Nihh kack`, quoted: nay1}) 
                    break 
                    case 'nulis4':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    if (args.length < 1) return reply(`[❗] CONTOH??\n*${prefix}${command} bot whatsapp*`)
                    reply(naylachan) 
                    F = body.slice(8)              			    
                    anu = await getBuffer(`https://api.xteam.xyz/magernulis?text=${F}&APIKEY=${apixteam}`)
                    nayla.sendMessage(from, anu, image, {caption: `Nihh kack`, quoted: nay1}) 
                    break 
                    case 'nulis5':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    if (args.length < 1) return reply(`[❗] CONTOH??\n*${prefix}${command} bot whatsapp*`)
                    reply(naylachan) 
                    F = body.slice(8)              			    
                    anu = await getBuffer(`https://api.xteam.xyz/magernulis5?text=${F}&APIKEY=${apixteam}`)
                    nayla.sendMessage(from, anu, image, {caption: `Nihh kack`, quoted: nay1}) 
                    break 
                    case 'nulis6':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    if (args.length < 1) return reply(`[❗] CONTOH??\n*${prefix}${command} bot whatsapp*`)
                    reply(naylachan) 
                    F = body.slice(8)              			    
                    anu = await getBuffer(`https://api.xteam.xyz/magernulis6?text=${F}&APIKEY=${apixteam}`)
                    nayla.sendMessage(from, anu, image, {caption: `Nihh kack`, quoted: nay1}) 
                    break                     

/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*====================================================[ TEXT PRO XIXIXI ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 
                    case 'sound1':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound2 = fs.readFileSync('sound/sound2.mp3')
                    nayla.sendMessage(from, sound2, MessageType.audio, {mimetype: 'audio/mp4', ptt:true, seconds: 9999999, quoted: nay1})
                    break 
                    case 'sound3':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound3 = fs.readFileSync('sound/sound3.mp3')
                    nayla.sendMessage(from, sound3, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break 
                    case 'sound4':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound4 = fs.readFileSync('sound/sound4.mp3')
                    nayla.sendMessage(from, sound4, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break      
                    case 'sound5':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound5 = fs.readFileSync('sound/sound5.mp3')
                    nayla.sendMessage(from, sound5, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break           
                    case 'sound6':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound6 = fs.readFileSync('sound/sound6.mp3')
                    nayla.sendMessage(from, sound6, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound7':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound7 = fs.readFileSync('sound/sound7.mp3')
                    nayla.sendMessage(from, sound7, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound8':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound8 = fs.readFileSync('sound/sound8.mp3')
                    nayla.sendMessage(from, sound8, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound9':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound9 = fs.readFileSync('sound/sound9.mp3')
                    nayla.sendMessage(from, sound9, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound10':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound10 = fs.readFileSync('sound/sound10.mp3')
                    nayla.sendMessage(from, sound10, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound11':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound11 = fs.readFileSync('sound/sound11.mp3')
                    nayla.sendMessage(from, sound11, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'soundtes':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound12 = fs.readFileSync('sound/sound12.mp3')
                    nayla.sendMessage(from, sound12, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound13':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound13 = fs.readFileSync('sound/sound13.mp3')
                    nayla.sendMessage(from, sound13, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound14':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound14 = fs.readFileSync('sound/sound14.mp3')
                    nayla.sendMessage(from, sound14, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound15':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound15 = fs.readFileSync('sound/sound15.mp3')
                    nayla.sendMessage(from, sound15, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound16':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound16 = fs.readFileSync('sound/sound16.mp3')
                    nayla.sendMessage(from, sound16, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound17':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound17 = fs.readFileSync('sound/sound17.mp3')
                    nayla.sendMessage(from, sound17, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound18':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound18 = fs.readFileSync('sound/sound18.mp3')
                    nayla.sendMessage(from, sound18, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound19':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound19 = fs.readFileSync('sound/sound19.mp3')
                    nayla.sendMessage(from, sound19, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound20':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound20 = fs.readFileSync('sound/sound20.mp3')
                    nayla.sendMessage(from, sound20, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound21':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound21 = fs.readFileSync('sound/sound21.mp3')
                    nayla.sendMessage(from, sound21, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound22':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound22 = fs.readFileSync('assets/sound22.mp3')
                    nayla.sendMessage(from, sound22, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                
                    case 'sound23':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound23 = fs.readFileSync('sound/sound23.mp3')
                    nayla.sendMessage(from, sound23, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break              
                    case 'sound24':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound24 = fs.readFileSync('sound/sound24.mp3')
                    nayla.sendMessage(from, sound24, MessageType.audio, {quoted: nay, mimetype: 'audio/mp4', ptt:true})
                    break                                                        
                    case 'sound25':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    const sound25 = fs.readFileSync('sound/sound25.mp3')
                    nayla.sendMessage(from, sound25, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
                    break                  
                                                                                                                                                
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*====================================================[ API?? LINDOWAPI ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 
                     
                      
                     case 'attpz':  
                     if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			         if (isLimit(sender)) return
			         await limitAdd(sender)
                     if (args.length < 1) return reply('Kasih teks lah kak masa kosongan')
                     ini = body.slice(6)
                     atetepe = await getBuffer(`https://api.xteam.xyz/attp?file&text=${encodeURIComponent(ini)}`)
                     nayla.sendMessage(from, atetepe, sticker, {quoted: nay})
                     break                     
                                                                                       
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ CASE ANTIII ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 

                   	case 'welcome':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GROUP ONLY`)
					if (!isGroupAdmins) return reply(`Hanya dapat dilakukan oleh admin grup!`)
					if (args.length < 1) return reply('Pilih 1 untuk mengaktifkan, dan 0 untuk menonaktifkan \n\n_Shirogane Kei Bot_')
					if (Number(args[0]) === 1) {
					if (isWelkom) return reply('*Sudah aktif kak!')
					welkom.push(from)
					fs.writeFileSync('./nayla/welkom.json', JSON.stringify(welkom))
					reply('[❗] Sukses mengaktifkan fitur welcome kak!')
					} else if (Number(args[0]) === 0) {
					welkom.splice(from, 1)
				    fs.writeFileSync('./nayla/welkom.json', JSON.stringify(welkom))
				    reply('[❗] Sukses menonaktifkan fitur welcome kak!')
					} else {
					reply(`Sukses aktif kak!`)
					}
					break  
                    case 'antilink':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender) 
                    if (!isGroup) return reply(`GROUP ONLY`)
					if (!isGroupAdmins) return reply(`Hanya dapat dilakukan oleh admin grup!`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					antilink.push(from)
					fs.writeFileSync('./nayla/antilink.json', JSON.stringify(antilink))
					reply('*[❗] ACTIVATED ANTILINK*')
					} else if (Number(args[0]) === 0) {
					antilink.splice(from, 1)
					fs.writeFileSync('./nayla/antilink.json', JSON.stringify(antilink))
					reply('*[❗] DEACTIVATED ANTILINK*')
					} else {
					reply(`PILIH 1/0`)
					}
					break					 
					case 'setplugin-leveling':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
		            if (!isOwner) return reply(`Hanya dapat dilakukan oleh admin grup!`)
					if (!isGroup) return reply(`GROUP ONLY`)
					if (!isGroupAdmins) return reply(`Hanya dapat dilakukan oleh admin grup!`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTI KAKF* !!!')
					botx.push(from)
					fs.writeFileSync('./nayla/botx.json', JSON.stringify(botx))
					reply('*[❗] ACTIVATED LEVELING*')
					} else if (Number(args[0]) === 0) {
					botx.splice(from, 1)
					fs.writeFileSync('./nayla/botx.json', JSON.stringify(botx))
					reply('*[❗] DEACTIVATED LEVELING*')
					} else {
					reply(`PILIH 1/0`)
					}
					break
					case 'antigay':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GROUP ONLY`) 
					if (!isGroupAdmins) return reply(`Hanya dapat dilakukan oleh admin grup!`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					antigay.push(from)
					fs.writeFileSync('./nayla/antigay.json', JSON.stringify(antigay))
					reply('*[❗] ACTIVATED ANTIGAY*')
					} else if (Number(args[0]) === 0) {
					antilink.splice(from, 1)
					fs.writeFileSync('./nayla/antigay.json', JSON.stringify(antigay))
					reply('*[❗] DEACTIVATED ANTIGAY*')
					} else {
					reply(`PILIH 1/0`)
					}
					break
					case 'antibocil':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GROUP ONLY`) 
					if (!isGroupAdmins) return reply(`LU ADMIN?? NGOTAK DONK, hehe maapin Kei-Chan ya kak habisnya lu tolol si`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					antibocil.push(from)
					fs.writeFileSync('./nayla/antibocil.json', JSON.stringify(antibocil))
					reply('*[❗] ACTIVATED ANTIBOCIL*')
					} else if (Number(args[0]) === 0) {
					antibocil.splice(from, 1)
					fs.writeFileSync('./nayla/antibocil.json', JSON.stringify(antibocil))
					reply('*[❗] DEACTIVATED ANTIBOCIL*')
					} else {
					reply(`PILIH 1/0`)
					}
					break
					case 'antiwibu':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender) 
					if (!isGroup) return reply(`GROUP ONLY`)
					if (!isGroupAdmins) return reply(`LU ADMIN?? NGOTAK DONK, hehe maapin Kei-Chan ya kak habisnya lu tolol si`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					antiwibu.push(from)
					fs.writeFileSync('./nayla/antiwibu.json', JSON.stringify(antiwibu))
					reply('*[❗] ACTIVATED ANTIWIBU*')
					} else if (Number(args[0]) === 0) {
					antiwibu.splice(from, 1)
					fs.writeFileSync('./nayla/antiwibu.json', JSON.stringify(antiwibu))
					reply('*[❗] DEACTIVATED ANTIWIBU*')
					} else {
					reply(`PILIH 1/0`)
					}
					break
					case 'antikasar':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GROUP ONLY`) 
					if (!isGroupAdmins) return reply(`LU ADMIN?? NGOTAK DONK, hehe maapin Kei-Chan ya kak habisnya lu tolol si`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					nayXi.push(from)
					fs.writeFileSync('./nayla/nayXi.json', JSON.stringify(nayXi))
					reply('*[❗] ACTIVATED ANTI KASAR*')
					} else if (Number(args[0]) === 0) {
					nayXi.splice(from, 1)
					fs.writeFileSync('./nayla/nayXi.json', JSON.stringify(nayXi))
					reply('*[❗] DEACTIVATED ANTI KASAR*')
					} else {
					reply(`PILIH 1/0`)
					}
					break
					case 'antitag':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GROUP ONLY`) 
					if (!isGroupAdmins) return reply(`LU ADMIN?? NGOTAK DONK, hehe maapin Kei-Chan ya kak habisnya lu tolol si`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					nayXix.push(from)
					fs.writeFileSync('./nayla/nayXix.json', JSON.stringify(nayXix))
					reply('*[❗] ACTIVATED ANTI TAG*')
					} else if (Number(args[0]) === 0) {
					nayXix.splice(from, 1)
					fs.writeFileSync('./nayla/nayXix.json', JSON.stringify(nayXix))
					reply('*[❗] DEACTIVATED ANTI TAG*')
					} else {
					reply(`PILIH 1/0`)
					}
					break
					case 'antijawa':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GROUP ONLY`) 
					if (!isGroupAdmins) return reply(`LU ADMIN?? NGOTAK DONK, hehe maapin Kei-Chan ya kak habisnya lu tolol si`)
					if (args.length < 1) return reply('PILIH 1/0')
					if (Number(args[0]) === 1) {
					if (isEventon) return reply('*SUDAH AKTIF* !!!')
					antijawa.push(from)
					fs.writeFileSync('./nayla/antiwibu.json', JSON.stringify(antijawa))
					reply('*[❗] ACTIVATED ANTIJAWA*')
					} else if (Number(args[0]) === 0) {
					antijawa.splice(from, 1)
					fs.writeFileSync('./nayla/antiwibu.json', JSON.stringify(antijawa))
					reply('*[❗] DEACTIVATED ANTIJAWA*')
					} else {
					reply(`PILIH 1/0`)
					}
					break
					 
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ REST API FRE ]==============================================================*/                  	    
/*====================================================[ CASE LOLTEAM ]==============================================================*/                    	 
        					
					case 'tebak':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    anu = await fetchJson(`http://dt-04.herokuapp.com/api/tebak`)
                    anu1 = `➻ *SOAL* : ${anu.pertanyaan}`
                    anu2 = `➻ *JAWABAN* : ${anu.jawaban_full}`
                    setTimeout( () => {
                    nayla.sendMessage(from, anu1, text, {quoted: nay1})
                    }, 1)
                    setTimeout( () => {
                    costum('50 DETIK LAGI', text, tescuk, cr)
                    }, 10000)                                                                                                                                   
                    setTimeout( () => {
                    costum('40 DETIK LAGI', text, tescuk, cr)
                    }, 20000)    
                    setTimeout( () => {
                    costum('30 DETIK LAGI', text, tescuk, cr)
                    }, 30000)    
                    setTimeout( () => {
                    costum('20 DETIK LAGI', text, tescuk, cr)
                    }, 40000)                                       
                    setTimeout( () => {
                    costum('10 DETIK LAGI', text, tescuk, cr)
                    }, 50000)                                                                                                                                                     
                    setTimeout( () => {
                    nayla.sendMessage(from, anu2, text,{quoted: nay1})                   
                    }, 60000)                                                                          
                    break 
                    case 'udara':
                    if (args.length < 1) return reply(`PILIH ARAH/CARA CONTOH\n${prefix}udara tembak perlahan`)
                    FC = body.slice(7)
                    setTimeout( () => {
                    reply(`[ *PERINTAH DILAKSANAKAN* ]`)
                    }, 1000)
                    setTimeout( () => {
                    reply(`[ *${FC}* ]`)
                    }, 5000)
                    setTimeout( () => {
                    reply(`[ *SEDANG BERBURU* ]`)
                    }, 8000)
                    setTimeout( () => {
                    reply(`[ *SUKSES !! DAN ANDA MENDAPATKAN* ]`)
                    }, 18000)
                    setTimeout( () => {
                    reply(`[ *WOW ANDA MENDAPATKAN* ]\n[ *${buruh33}* ]\n[ INFORMASI *${prefix}info3* ]`)
                    }, 20000)
                    break
                    case 'darat':
                    if (args.length < 1) return reply(`PILIH ARAH/CARA CONTOH\n${prefix}darat tembak perlahan`)
                    FC = body.slice(7)
                    setTimeout( () => {
                    reply(`[ *PERINTAH DILAKSANAKAN* ]`)
                    }, 1000)
                    setTimeout( () => {
                    reply(`[ *${FC}* ]`)
                    }, 5000)
                    setTimeout( () => {
                    reply(`[ *SEDANG BERBURU* ]`)
                    }, 8000)
                    setTimeout( () => {
                    reply(`[ *SUKSES !! DAN ANDA MENDAPATKAN* ]`)
                    }, 18000)
                    setTimeout( () => {
                    reply(`[ *WOW ANDA MENDAPATKAN* ]\n[ *${buruh22}* ]\n[ INFORMASI *${prefix}info2* ]`)
                    }, 20000)
                    break
                    case 'laut':
                    if (args.length < 1) return reply(`PILIH ARAH/CARA CONTOH\n${prefix}laut tembak perlahan`)
                    FC = body.slice(6)
                    setTimeout( () => {
                    reply(`[ *PERINTAH DILAKSANAKAN* ]`)
                    }, 1000)
                    setTimeout( () => {
                    reply(`[ *${FC}* ]`)
                    }, 5000)
                    setTimeout( () => {
                    reply(`[ *SEDANG BERBURU* ]`)
                    }, 8000)
                    setTimeout( () => {
                    reply(`[ *SUKSES !! DAN ANDA MENDAPATKAN* ]`)
                    }, 18000)
                    setTimeout( () => {
                    reply(`[ *WOW ANDA MENDAPATKAN* ]\n[ *${buruh33}* ]\n[ INFORMASI *${prefix}info1* ]`)
                    }, 20000)
                    break
                    case 'info1':
                    reply(nyz.info1())
                    break
                    case 'info2':
                    reply(nyz.info2())
                    break
                    case 'info3':
                    reply(nyz.info3())
                    break                               
                    case 'test':                   
                    reply(`Siapp Onii-chan 😘`)
                    break
					case 'intro':  
                    intro1 =`Intro Member Baru! \n`
					intro1 += `\n`
					intro1 +=`➮ *Nama*            : \n`
					intro1 +=`➮ *Umur* (opsional) : \n`
					intro1 +=`➮ *Gender*          : \n`
					intro1 +=`➮ *Asal Kota*       : \n`
					intro1 +=`➮ *Alasan Bergabung* : \n`
					intro1 +=`➮ *Supremacy* [Loli/Teen/Milf] : \n`
					intro1 +=`➮ *Flag* [Yuri/Yaoi/Normal] : \n`
					intro1 +=`   *pilih salah satu~ \n`
					intro1 +=`\n`
					intro1 +=`Kata-kata yg ingin kamu ucapkan saat masuk ke grub ini(opsional):\n`
					intro1 +=`➮\n`
					intro1 +=`\n`
					intro1 +=`\n`
					intro1 +=`⎾ _Shirogane Kei_ ⏌ \n`
					intro1 +=`⎾ _Armada Bot_ ⏌`
					reply(intro1)
                    break
					case 'bothelp':                    
                    reply(`Silahkan ketik #daftar agar bisa menggunakan bot, dan #aboutbot utk melihat changelog bot`)
                    break
                    case 'addprem':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isOwner) return reply(`Maaf nih kak, fitur ini khusus untuk Owner Saya, hubungi owner utk info lebih lanjut :)`)
					adprem = `${args[0].replace('@','')}@s.whatsapp.net`
					prem.push(adprem)
					fs.writeFileSync('./nayla/prem.json', JSON.stringify(prem))
					reply(`Yeayyy... Berhasil menambahkan ke anggota premium kak!`)
					break				
					case 'dellprem':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender) 
					if (!isOwner) return reply(`Maaf nih kak, fitur ini khusus untuk Owner Saya, hubungi owner utk info lebih lanjut :)`)
					delp = body.slice(10)
					prem.splice(`${delp}@s.whatsapp.net`, 1)
					fs.writeFileSync('./nayla/prem.json', JSON.stringify(prem))
					reply(`Berhasil Menghapus wa.me/${delp} Dari Daftar Premium, yahhh jangan sedih ya kak >,,<`)
					break
					case 'group':
					case 'gc':
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply(`GRUP ONLY`)
					if (!isGroupAdmins) return reply(`Gomennasai senpai, Kei chan bukan admin :(`)
					if (!isBotGroupAdmins) return reply(`Maaf nih kak, apakah kakak admin?`)
					if (args[0] === 'buka') {
					    reply(`*Berhasil membuka grup senpai!* \n\n_Shirogane Kei Bot_`)
						nayla.groupSettingChange(from, GroupSettingChange.messageSend, false)
					} else if (args[0] === 'tutup') {
						reply(`*Berhasil menutup grup senpai!* \n\n_Shirogane kei Bot_`)
						nayla.groupSettingChange(from, GroupSettingChange.messageSend, true)
					}				 
					break  
					case 'hidetag10':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)              
				    if (!isGroup) return reply(`GRUP ONLY`)
					if (!isGroupAdmins) return reply(`LU ADMIN??`)
					var value = body.slice(10)
					var group = await nayla.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: value,
					contextInfo: { mentionedJid: mem },
					quoted: nay
					}
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					nayla.sendMessage(from, options, text)					 
					break    
 
					case 'ingfo':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)              
				    if (!isGroup) return reply(`GRUP ONLY`)
					if (!isGroupAdmins) return reply(`LU ADMIN??`)
					var value = body.slice(7)
					var group = await nayla.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: `[ *INGFO TERBARU!!!* ]\nDARI : *${pushname}*\nINGFO : *${value}*`,
					contextInfo: { mentionedJid: mem },
					quoted: nay
					}
					nayla.sendMessage(from, options, text, {quoted: nay1})					 
					break

					 case 'demote':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply('GRUB ONLY')
					if (!isGroupAdmins) return reply('LU ADMIN??')
					if (!isBotGroupAdmins) return reply('BOT BUKAN ADMIN')
					if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('tag member')
					mentioned = nay.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
					teks = ''
					for (let _ of mentioned) {
					teks += `*jabatan kamu di copot*🏃 :\n`
					teks += `@_.split('@')[0]`
					}
					mentions(teks, mentioned, true)
					nayla.groupDemoteAdmin(from, mentioned)
					} else {
					mentions(`yahhh @${mentioned[0].split('@')[0]} lu bukan admin lagi bro :(`, mentioned, true)
					nayla.groupDemoteAdmin(from, mentioned)
					}					 
					break
				    case 'promote':  
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply('GRUB ONLY')
					if (!isGroupAdmins) return reply('LU ADMIN?? NGOTAK DONK, hehe maapin Kei-Chan ya kak habisnya lu tolol si')
					if (!isBotGroupAdmins) return reply('BOT BUKAN ADMIN')
					if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('tag member')
					mentioned = nay.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
					teks = ''
					for (let _ of mentioned) {
					teks += `𝗦𝗲𝗹𝗮𝗺𝗮𝘁🥳 𝗮𝗻𝗱𝗮 𝗻𝗮𝗶𝗸 𝗺𝗲𝗻𝗷𝗮𝗱𝗶 𝗮𝗱𝗺𝗶𝗻 𝗴𝗿𝗼𝘂𝗽 (+_+) :\n`
					teks += `@_.split('@')[0]`
					}
					mentions(teks, mentioned, true)
					nayla.groupMakeAdmin(from, mentioned)
			 	    } else {
					mentions(`𝗦𝗲𝗹𝗮𝗺𝗮𝘁🥳 @${mentioned[0].split('@')[0]} *anda naik menjadi admin group* (+_+)`, mentioned, true)
					nayla.groupMakeAdmin(from, mentioned)
					}					 
					break	                     
                    case 'oxo':                    
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
                    oxz1 = `[ ${oxo11} ]\n`
                    oxz1 += `[ ${oxo22} ]\n`
                    oxz1 += `[ ${oxo33} ]\n`
                    reply(oxz1)
                    break
                    case 'tts': 
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
				    if (args.length < 1) return nayla.sendMessage(from, 'Diperlukan kode bahasa kak!!')
					if (args.length < 2) return nayla.sendMessage(from, 'Mana teks yang mau di jadiin suara? suara setan kah?', text, {quoted: nay})
					dtt = body.slice(8)
					const gtts = require('./lib/gtts')(args[0])
					ranm = getRandom('.mp3')
					rano = getRandom('.ogg')
					dtt.length > 500
					? reply('Textnya kebanyakan cayank!!!')
					: gtts.save(ranm, dtt, function() {
					exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
					fs.unlinkSync(ranm)
					buffer = fs.readFileSync(rano)
					if (err) return reply('ERROR')
					nayla.sendMessage(from, buffer, audio, {ptt:true, quoted:nay1})
					fs.unlinkSync(rano)
					})
					})
					break
					case 'pesan':
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					if (!isGroup) return reply('GRUB ONLY')
				    if (args.length < 1) return reply(`[❗] CONTOHH??\n${prefix}${command}pesan @tagmember|halo kak ada yang bisa Kei chan bantu?`)
					var FG = body.slice(8)
					var F1 = FG.split("|")[0];
					var F2 = FG.split("|")[1];
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					reply('PESAN SUDAH TERKIRIM')
					break
	            	case 'tebaklirik': 
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					anu = await fetchJson(`http://lolhuman.herokuapp.com/api/tebak/lirik?apikey=${l0lhuman}`, {method: 'get'})
					lirik = `SOAL TEBAK LIRIK : *${anu.result.question}*`
					setTimeout( () => {
					nayla.sendMessage(from, `➻ *JAWABAN* : ${anu.result.answer}`, text, {quoted: nay1})
					}, 60000) 
					setTimeout( () => {
                    costum('50 DETIK LAGI', text, tescuk, cr)
                    }, 10000)                                                                                                                                   
                    setTimeout( () => {
                    costum('40 DETIK LAGI', text, tescuk, cr)
                    }, 20000)    
                    setTimeout( () => {
                    costum('30 DETIK LAGI', text, tescuk, cr)
                    }, 30000)    
                    setTimeout( () => {
                    costum('20 DETIK LAGI', text, tescuk, cr)
                    }, 40000)                                       
                    setTimeout( () => {
                    costum('10 DETIK LAGI', text, tescuk, cr)
                    }, 50000)                                       
					setTimeout( () => {
					nayla.sendMessage(from, lirik, text, {quoted: nay1 }) 
					}, 1) 
					break 
					case 'tebakin1': 
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					anu = await fetchJson(`http://lolhuman.herokuapp.com/api/tebak/jenaka?apikey=${l0lhuman}`, {method: 'get'})
					te1 = `SOAL TEBAKIN : *${anu.result.question}*`
					setTimeout( () => {
					nayla.sendMessage(from, `➻ *JAWABAN* : ${anu.result.answer}`, text, {quoted: nay1})
					}, 60000) 
					setTimeout( () => {
                    costum('50 DETIK LAGI', text, tescuk, cr)
                    }, 10000)                                                                                                                                   
                    setTimeout( () => {
                    costum('40 DETIK LAGI', text, tescuk, cr)
                    }, 20000)    
                    setTimeout( () => {
                    costum('30 DETIK LAGI', text, tescuk, cr)
                    }, 30000)    
                    setTimeout( () => {
                    costum('20 DETIK LAGI', text, tescuk, cr)
                    }, 40000)                                       
                    setTimeout( () => {
                    costum('10 DETIK LAGI', text, tescuk, cr)
                    }, 50000)                                       
					setTimeout( () => {
					nayla.sendMessage(from, te1, text, {quoted: nay1 }) 
					}, 1) 
					break 
				    case 'tebakin2': 
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)
					anu = await fetchJson(`http://lolhuman.herokuapp.com/api/tebak/siapaaku?apikey=${l0lhuman}`, {method: 'get'})
					te2 = `SOAL TEBAKIN : *${anu.result.question}*`
					setTimeout( () => {
					nayla.sendMessage(from, `➻ *JAWABAN* : ${anu.result.answer}`, text, {quoted: nay1})
					}, 60000) 
					setTimeout( () => {
                    costum('50 DETIK LAGI', text, tescuk, cr)
                    }, 10000)                                                                                                                                   
                    setTimeout( () => {
                    costum('40 DETIK LAGI', text, tescuk, cr)
                    }, 20000)    
                    setTimeout( () => {
                    costum('30 DETIK LAGI', text, tescuk, cr)
                    }, 30000)    
                    setTimeout( () => {
                    costum('20 DETIK LAGI', text, tescuk, cr)
                    }, 40000)                                       
                    setTimeout( () => {
                    costum('10 DETIK LAGI', text, tescuk, cr)
                    }, 50000)                                       
					setTimeout( () => {
					nayla.sendMessage(from, te2, text, {quoted: nay1 }) 
					}, 1) 
					break 
				 
                    case 'limit':                     
                    if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
				    checkLimit(sender)
					break 
			     	case 'leveling':
                    if (!isGroup) return reply('GRUP ONLY')
                    if (!isGroupAdmins) return reply('Maaf nih kak, hanya dapat diaktifkan oleh admin grup')
                    if (args.length < 1) return reply('Pilih: enable/disable')
                    if (args[0] === 'enable') {
                    if (isLevelingOn) return reply('*fitur level sudah aktif sebelum nya*')
                    _leveling.push(from)
                    fs.writeFileSync('./nayla/leveling.json', JSON.stringify(_leveling))
           	        reply('Fitur Leveling berhasil diaktifkan kak!')
                    } else if (args[0] === 'disable') {
                	_leveling.splice(from, 1)
                    fs.writeFileSync('./nayla/leveling.json', JSON.stringify(_leveling))
                    reply('Fitur Leveling berhasil dinonaktifkan kak!')
                    } else {
           	        reply('PILIH enable/disable')
                  	}
				    break 
				    case 'level':
                    if (!isLevelingOn) return reply('Maaf kak, fitur leveling tidak aktif, ketik #leveling dan #setplugin-leveling untuk mengaktifkan!')
                    if (!isGroup) return reply('Grup only kak :)')
					jds = []
                    const userLevel = getLevelingLevel(sender)
                    const userXp = getLevelingXp(sender)
                    if (userLevel === undefined && userXp === undefined) return reply(nyz.lvlnul())
                    const requiredXp = 5000 * (Math.pow(2, userLevel) - 1)
                    resul = `⧉ ${xxx}- - - Level Senpai - - -${xxx} ⧉\n`
					resul += `⟤ ${xxx}Nama       : ${pushname}${xxx}\n`
					resul += `⟤ ${xxx}UID        : wa.me/${sender.split("@")[0]}${xxx}\n`
					resul += `⟤ ${xxx}User XP    :  ${userXp}/${requiredXp}${xxx}\n`
					resul += `⟤ ${xxx}User Level : ${userLevel}${xxx}\n`
					resul += `\n`
					resul += `\n`
					resul += `▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱\n`
					resul += `${xxx}Shirogane Kei Bot${xxx}\n`
					resul += `▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱`
                    mentions(resul, jds, true)
			    	break     
					case 'spam':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)  
					var FG = body.slice(7)
					var F1 = FG.split("|")[0];
					var F2 = FG.split("|")[1];
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})
					nayla.sendMessage(`${F1}@s.whatsapp.net`, `DARI ${pushname}\nPESAN : ${F2}`, text, {quoted:nay1})					
					reply('BERHASIL SPAM🔥')
					break
					case 'fitnah':
					if (!isElite) return reply(nyz.nayzelite(pushname, prefix))
			        if (isLimit(sender)) return
			        await limitAdd(sender)  
					if (args.length < 1) return reply(`Gini ${pushname} senpai : ${prefix}fitnah [@tag&pesan&balasanbot]\n\nContoh : ${prefix}fitnah @tagmember&hai&hai juga`)
				    var gh = body.slice(8)
			      	mentioned = nay.message.extendedTextMessage.contextInfo.mentionedJid
					var replace = gh.split("&")[0];
					var target = gh.split("&")[1];
					var bot = gh.split("&")[2];
					nayla.sendMessage(from, `${bot}`, text, {quoted: { key: { fromMe: false, participant: `${mentioned}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target}` }}})
					await limitAdd(sender) 
					break
					 
                                                               
                                                                                                                                                                             
                    
                     
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ ANTI RANDOM ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 
                    
                    /*default:            
                    if (budy.includes("https://")){
					if (!isGroup) return
					if (!isAntiLink) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`Link Group Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }*/
				    
				   
                    if (budy.includes("syg")){
					if (!isGroup) return
					if (!isAntigay) return
					if (isGroupAdmins) return reply('haduhh siaa :v admin grub mahh bebas nge gayyyy yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`Gayy Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				     
				    if (budy.includes("ayan")){
					if (!isGroup) return
					if (!isAntigay) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge gayyyy yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`Gayy Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("love")){
					if (!isGroup) return
					if (!isAntigay) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge gayyyy yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`Gayy Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("ayuk")){
					if (!isGroup) return
					if (!isAntibocil) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge bocilz yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`bocil Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("chan")){
					if (!isGroup) return
					if (!isAntiwibu) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge wibu yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`wibu Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => { 
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("yamete")){
					if (!isGroup) return
					if (!isAntiwibu) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge wibu yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`wibu Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("ambe")){
					if (!isGroup) return
					if (!isAntijawa) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge wibu yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`jawa Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("tempek")){
					if (!isGroup) return
					if (!isAntijawa) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge wibu yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`jawa Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("matamu")){
					if (!isGroup) return
					if (!isAntijawa) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge wibu yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`jawa Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("jancok")){
					if (!isGroup) return
					if (!isAntijawa) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge wibu yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`jawa Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }
				    if (budy.includes("aing")){
					if (!isGroup) return
					if (!isAntijawa) return
					if (isGroupAdmins) return reply('alahhh siaa :v admin grub mahh bebas nge wibu yakan 😎 EZzz')
					nayla.updatePresence(from, Presence.composing)
					if (messagesC.includes("@62812874133914")) return reply("izin diterima")
					var kic = `${sender.split("@")[0]}@s.whatsapp.net`
					reply(`jawa Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 5detik lagi`)
					setTimeout( () => {
					nayla.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
					}, 5000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("1detik")
					}, 4000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("2detik")
					}, 3000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("3detik")
					}, 2000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("4detik")
					}, 1000)
					setTimeout( () => {
					nayla.updatePresence(from, Presence.composing)
					reply("5detik")
					}, 0)
				    }	
	//Reactions starting from here
		//mungkin kekny ad yg ga work							    
				    if (budy.includes("Cara pake bot gimana?")){
						jds = []
						AA0 = `Silahkan ketik ${prefix}bothelp kak :)`
				    	mentions(AA0, jds, true)
				    }
				    if (budy.includes("Bot")){
						jds = []
				    	AA1 =`Haaaa... emangnya kenapa senpai kalo aku bot? Gasuka ya?.... \nBbbbukan berarti Kei-chan marah ya 👉🏻👈🏻 \nHumphhh 😤`
						mentions(AA1, jds, true)
				    }
				    if (budy.includes("Badut")){
						jds = []
				    	AA2 =`Siapa yang badut kak?`
						mentions(AA2, jds, true)
				    }
					if (budy.includes("badut")){
						jds = []
				    	AA22 =`Siapa yang badut kak?`
						mentions(AA22, jds, true)
				    }												    
				    if (budy.includes("https://")){
				    	jds = []
						AA3 =`Hayooo, link apa tuch kak, bokep yaaa 🤣`
						mentions(AA3, jds, true)
				    }	
						if (budy.includes("pixiv.net")){
				    		jds = []
							AA33 = `Hayoolooo lewd terosss`
							mentions(AA33, jds, true)
				    }	
				    if (budy.includes("Gay")){
				    	jds = []
						AA4 = `Waduhh siapa yang gay kak?... parah si`
						mentions(AA4, jds, true)
				    }	
				    if (budy.includes("Hai")){
				    	jds = []
						AA5 = `Hai juga kak 👋🏻`
						mentions(AA5, jds, true)
				    }
				    if (budy.includes("Istri gw")){
				    	jds = []
						AA6 = `Uwahhh istri koq gepeng :v`
						mentions(AA5, jds, true)
				    }	
				    if (budy.includes("istri gw")){
				    	jds = []
						AA66 = `Uwahhh istri koq gepeng :v`
						mentions(AA66, jds, true)
				    }
					if (budy.includes("Ngentot")){
				    	jds = []
						AA7 = `Ihhh parah toxic, keturunan lord garox lu ya🙄`
						mentions(AA7, jds, true)
				    }
					if (budy.includes("ngentot")){
				    	jds = []
						AA8 = `Ihhh parah toxic, keturunan lord garox lu ya🙄`
						mentions(AA8, jds, true)
				    }
					if (budy.includes("Jembut")){
				    	jds = []
						AA9A = `Ihhh parah toxic, keturunan lord garox lu ya🙄`
						mentions(AA9A, jds, true)
				    }
					if (budy.includes("jmbt")){
				    	jds = []
						AA9B =`Ihhh parah toxic, keturunan lord garox lu ya🙄`
						mentions(AA9B, jds, true)
				    }
					if (budy.includes("Jembot")){
				    	jds = []
						AA9C =`Ihhh parah toxic, keturunan lord garox lu ya🙄`
						mentions(AA9C, jds, true)
				    }
					if (budy.includes("Woi")){
				    	jds = []
						AA10 = `Apaan si senpai 😑`
						mentions(AA10, jds, true)
				    }
					if (budy.includes("Oi")){
				    	jds = []
						AA11 =`Paan si... orang punya nama dipanggil oi oi, sopan dikit donk😑`
						mentions(AA11, jds, true)
				    }
					if (budy.includes("ngambek")){
				    	jds = []
						AA12 =`Emang kenapa kalo aku ngambek kak? gasuka? humphhh 😤`
						mentions(AA12, jds, true)
				    }
					if (budy.includes("Maaf")){
				    	jds = []
						AA13 =`Iya deh, Kei-chan maafin... ttt..tapi jangan di ulangi lagi ya`
						mentions(AA13, jds, true)
				    }
					if (budy.includes("maaf")){
				    	jds = []
						AA13B =`Iya deh, Kei-chan maafin... ttt..tapi jangan di ulangi lagi ya😕`
						mentions(AA13B, jds, true)
				    }
					if (budy.includes("Bagus gak")){
				    	jds = []
						AA14 =`Udah bagus itu kok kak hehe`
						mentions(AA14, jds, true)
				    }	
						if (budy.includes("bagus gak")){
				    		jds = []
							AA14B =`Udah bagus itu kok kak hehe`
							mentions(AA14B, jds, true)
				    }
					if (budy.includes("dimana?")){
				    	jds = []
						AA15 =`Kei chan selalu ada di hati senpai koq >///<`
						mentions(AA15, jds, true)
				    }
					if (budy.includes("pintar")){
				    	jds = []
						AA16 =`Hehehe makasih banyak senpai >//<`
						mentions(AA16, jds, true)
				    }
						if (budy.includes("pinter")){
				    		jds = []
							AA16B =`Hehehe makasih banyak senpai >//<`
							mentions(AA16B, jds, true)
				    }
					if (budy.includes("Oyasumi")){
				    	jds = []
						AA17 =`Oyasumi juga kak, semoga mimpi indah...🥰`
						mentions(AA17, jds, true)
				    }
					if (budy.includes("Bobo yuk")){
				    	jds = []
						AA18 =`Gamau ah, badan senpai bauu 😆`
						mentions(AA18, jds, true)
				    }
					if (budy.includes("Alhamdulilah")){
				    	jds = []
						AA19 =`Subhanallah, tetap bersyukur ya kak 🙏🏻`
						mentions(AA19, jds, true)
				    }
					if (budy.includes("Ngobrol yuk")){
				    	jds = []
						AA20 =`Mau ngobrol apa kak? 🙃 `
						mentions(AA20, jds, true)
				    }
					if (budy.includes("mau gak jadi pacar aku")){
				    	jds = []
						AA21 =`Hmmmm.... wani piro senpai? >///<`
						mentions(AA21, jds, true)
				    }										    
						if (budy.includes("ewe")){
				    		jds = []
							AA22D =`Ewa ewe, dasar otak ngeres! 😠`
							mentions(AA22D, jds, true)
				    }
					if (budy.includes("Halo")){
				    	jds = []
						AA24 =`Holaaa, gimana kak... ada yang bisa saya bantu? 😊`
						mentions(AA24, jds, true)
				    }
					if (budy.includes("Sepi")){
				    	jds = []
						AA25 =`Hmmm sepi ya... sini kutemenin senpai >//<`
						mentions(AA25, jds, true)
				    }
					if (budy.includes("sepi")){
				    	jds = []
						AA25B =`Hmmm sepi ya... sini kutemenin senpai >//<`
						mentions(AA25B, jds, true)
				    }
					if (budy.includes("Cek cek")){
				    	jds = []
						AA26 =`Siap senpai!, Botnya nyala kok`
						mentions(AA26, jds, true)
				    }
					if (budy.includes("Joki")){
				    	jds = []
						AA27 =`Joka joki, gabisa maenin sendiri ya?.... kesian yhahaha 🤣🤣🤣`
						mentions(AA27, jds, true)
				    }
					if (budy.includes("joki")){
				    	jds = []
						AA27B =`Joka joki, gabisa maenin sendiri ya?.... kesian yhahaha 🤣🤣🤣`
						mentions(AA27B, jds, true)
				    }
					if (budy.includes("Asalamualaikum")){
				    	jds = []
						AA28 =`Walaikumsalam, subhanallah udah aku jwb pke vn jg tuh ... gimana kabarnya senpai?`
						mentions(AA28, jds, true)
				    }
					if (budy.includes("Ampas")){
				    	jds = []
						AA29 =`Ampazz ya senpai gacha nya?, hahahaha kasian deh lu 🤣`
						mentions(AA29, jds, true)
				    }
						if (budy.includes("Ampaz")){
				    		jds = []
							AA29B =`Ampazz ya senpai gacha nya?, hahahaha kasian deh lu 🤣🤣`
							mentions(AA29B, jds, true)
				    }
						if (budy.includes("ampas")){
				    		jds = []
							AA29C =`Ampazz ya senpai gacha nya?, hahahaha kasian deh lu 🤣🤣`
							mentions(AA29C, jds, true)
				    }
						if (budy.includes("ampaz")){
				    		jds = []
							AA29D =`Ampazz ya senpai gacha nya?, hahahaha kasian deh lu 🤣🤣`
							mentions(AA2D, jds, true)
				    }
					if (budy.includes("rate off")){
						jds = []
						AA29E =`Ampazz ya senpai gacha nya?, hahahaha kasian deh lu 🤣🤣`
						mentions(AA2E, jds, true)
				}
					if (budy.includes("Ngeri")){
				    	jds = []
						AA30 =`Apaan si senpai, mau jadi badut ya?`
						mentions(AA30, jds, true)
				    }
					if (budy.includes("ngeri")){
				    	jds = []
						AA30B =`Apaan si senpai, mau jadi badut ya?`
						mentions(AA30B, jds, true)
				    }
					//toxic lagi
					if (budy.includes("Ajg")){
				    	jds = []
						AA31 =`ihhh parah si senpai toxic, gapernah diajarin tata krama ya?🙄`
						mentions(AA31, jds, true)
				    }
						if (budy.includes("ajg")){
				    	jds = []
						AA31B =`ihhh parah si senpai toxic, gapernah diajarin tata krama ya?🙄`
						mentions(AA31B, jds, true)
				    }
						if (budy.includes("Ngontol")){
				    	jds = []
						AA31D =`ihhh parah si senpai toxic, gapernah diajarin tata krama ya?🙄`
						mentions(AA31D, jds, true)
					}
						if (budy.includes("KONTOL")){
				    	jds = []
						AA31E =`Wah parah ini mah toxicnya, udah pke capslok jebol pula... org kek gini pantes nih jadi The Lord of Toxic People 👺`
						mentions(AA31E, jds, true)
					}
						if (budy.includes("Kontol")){
				    	jds = []
						AA31F =`ihhh parah si senpai toxic, gapernah diajarin tata krama ya?😠`
						mentions(AA31F, jds, true)
					}
					if (budy.includes("kontol")){
				    	jds = []
						AA31G =`ihhh parah si senpai toxic, gapernah diajarin tata krama ya?😠`
						mentions(AA31G, jds, true)
					}
					//toxic selesai
					if (budy.includes("Makasih")){
				    	jds = []
						AA33 =`Iya, sama-sama senpai 🥰`
						mentions(AA32, jds, true)
					}
					if (budy.includes("makasih")){
				    	jds = []
						AA33B =`Iya, sama-sama senpai 🥰`
						mentions(AA32B, jds, true)
					}
						if (budy.includes("mksh")){
				    	jds = []
						AA33C =`Iya, sama-sama senpai 🥰`
						mentions(AA32C, jds, true)
					}
					if (budy.includes("Gajelas")){
				    	jds = []
						AA33 =`Hmmm, kalo mau ada perlu bilang yang bener donk senpai, jangan bikin orang ambigu`
						mentions(AA33, jds, true)
					}
				//starting from here is changing parameter into "AB<numerical>"
				//sim simi reactions will be added soon!
				//anjing kek ngehalu, padahal cuma bot	
					//sapaan
					if (budy.includes("Selamat malam")){
				    	jds = []
						AB1 =`Malem juga senpai 😁`
						mentions(AB1, jds, true)
					}	
						if (budy.includes("Konbanwa")){
				    	jds = []
						AB1B =`Konbanwa senpai 😁`
						mentions(AB1B, jds, true)
					}			
					if (budy.includes("Selamat sore")){
				    	jds = []
						AB2 =`Sore juga senpai 🥰`
						mentions(AB2, jds, true)
					}	
					if (budy.includes("Ohayo")){
				    	jds = []
						AB3 =`Ohayooo ${pushname} senpai 🤗, gimana tidurnya? nyenyak?`
						mentions(AB3, jds, true)
					}	

			//VOICE		
				//voice react asalamualaikum [const 1] F2	
				if (budy.includes("Asalamualaikum")){					
				    const F2 = fs.readFileSync('sound/baru/walaikumsalam.ogg')
                    nayla.sendMessage(from, F2, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
                    }
				//voice react tag bot [const 2]	F3
					if (budy.includes(`${numberbot}`)){
				    	jds = []
						balesan =`Iyaaa ${pushname} senpai!, ada perlu apa sama saya?`
						mentions(balesan, jds, true)
					}
                    if (budy.includes(`${numberbot}`)){
				    const F3 = fs.readFileSync('sound/baru/iyadygbsdbntu.ogg')
                    nayla.sendMessage(from, F3, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
                    }
				//voice react Kei [const 3]	F4-F5
					if (budy.includes("sayang")){
						jds = []
				   		const F4 = fs.readFileSync('sound/baru/apasyg.ogg')
						   F4 = `MessageType.audio, {mimetype: 'audio/mp4', ptt:true}`
                   		mentions(F4, jds, true)
                    }
					if (budy.includes("Helo")){
						jds = []
						const F5 = fs.readFileSync('sound/baru/iya.mp3')
						nayla.sendMessage(from, F5, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
						}
				//voice react Kei-chan [const 4] F6	
					if (budy.includes("chan")){
				    	const F6 = fs.readFileSync('sound/baru/iyasyg.ogg')
                    	nayla.sendMessage(from, F6, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
                    }
				//voice react toxic [const 5] up to [const ...] F7-F10 males gw inputnya cokk
						//Higher case to lower case first!
					//Anjing
					if (budy.includes("Anjing")){
						const F7 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.reply(from, F7, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
					}
					if (budy.includes("anjing")){
						const F8 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.sendMessage(from, F8, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
                    }
					if (budy.includes("Anjg")){
						const F9 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.sendMessage(from, F9, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
                    }
					if (budy.includes("anjg")){
						const F10 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.sendMessage(from, F10, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
                    }
					//Babi F11-F12
					if (budy.includes("Babi")){
						const F11 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.sendMessage(from, F11, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
					}
					if (budy.includes("babi")){
						const F12 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.sendMessage(from, F12, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
					}
					//Kontol F13-F14
					if (budy.includes("Kontol")){
						const F13 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.reply(from, F13, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
					}
					if (budy.includes("kontol")){
						const F14 = fs.readFileSync('sound/baru/ihkasar.ogg')
						nayla.sendMessage(from, F14, MessageType.audio, {mimetype: 'audio/mp4', ptt:true})
					}
					
			 //STICKER REACT const F22 and F33     
				//sticker react tag owner	
				    if (budy.includes(`${ownerrf}`)){
                    const F22 = fs.readFileSync('menu/tagowner.webp')
                    nayla.sendMessage(from, F22, sticker)
                    }
					if (budy.includes(`aselole}`)){
						jds = []
						const F22B = fs.readFileSync('menu/tagowner.webp')
						F22B = `sticker`
						mentions(F22B, jds, true)
						}
				//sticker react tag lort dimaseee	
                    if (budy.includes(`${lort}`)){
                    	const F33 = fs.readFileSync('menu/taglort.webp')
                    	nayla.sendMessage(from, F33, sticker)
                    	}
				//sticker react emotions		
					if (budy.includes(`Ngantuk`)){
						const F44 = fs.readFileSync('menu/ngantuk.webp')
						nayla.sendMessage(from, F44, sticker)
						}
						if (budy.includes(`ngantuk`)){
							const F44B = fs.readFileSync('menu/ngantuk.webp')
							nayla.sendMessage(from, F44B, sticker)
							}
					if (budy.includes(`Sange`)){
							const F55 = fs.readFileSync('menu/sange.webp')
							nayla.sendMessage(from, F55, sticker)
							} 
					if (budy.includes(`sange`)){
							const F55B = fs.readFileSync('menu/sange.webp')
							nayla.sendMessage(from, F55B, sticker)
							} 	  					
/* ===================================================[ BOT WHATSAPP ]==============================================================*/    
/*=====================================================[ API FREEEEE ]==============================================================*/                  	    
/*====================================================[ CASE BY NAYLA ]==============================================================*/                    	 				    

                     
                    if (body.startsWith(`${prefix}${command}`)) {
						jds = []                    
                    anu1 = `Yahhhh.... T_T\n`
                    anu1 += `Maaf ya senpai *${pushname}* ${notc1} Sayang sekali :(\n`
                    anu1 += `Fitur *${command}*\n`
                    anu1 += `Tidak dapat ditemukan di *${prefix}menu* :( \n`
					anu1 += `Coba periksa kembali perintah, apakah ada typo atau salah kata/huruf dalam mengirim pesan\n`
					anu1 += `:)\n`
					anu1 += `Terimakasih senpai, salam dari Kei-chans\n`       
                    (mentions(anu1, jds, true))
                    }                                       	
              }   
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		   reply('ERROR ATAU APIKEY UNVALID')
		}
	})
}
starts() 